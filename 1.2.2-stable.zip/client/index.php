<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{GSP, SafeSQL, User, EventLog, Games, Machines};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delsubuser")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['subuser'] == true)
{
    // Prevent subusers from accessing certain calls
    if(in_array($_REQUEST['mode'], array("delsubuser", "savesubuser", "subusers", "subuserlist", "addsubuser", "editsubuser", "eventlog", "machinestatus", "machineinfo")))
    {
        header("Location: index.php");
        exit();
    }
}

// If a sid is specified make sure the user owns the machine
if(isset($_REQUEST['sid']) && !empty($_REQUEST['sid']))
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `machines` WHERE `id`='%i' AND `owner`='%i' LIMIT 1", array($_REQUEST['sid'], $_SESSION['uid'])));
    if(!$query || $query->num_rows != 1)
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    /*
     * Edit
     */
    if($_REQUEST['mode'] == "userprofile")
    {
        if($_SESSION['subuser'] == true)
        {
            $params = array("email" => $_REQUEST['email'],
                "password" => $_REQUEST['password'],
                "subid" => $_SESSION['subid'],
                "uid" => $_SESSION['uid']);
            $results = User::EditSubUser($params);
            if($results['error'] == 0)
            {
                $display->goodmessage = $lang['subusersaved'];
            }
            elseif($results['error'] == -1)
            {
                $display->errormessage = $lang['missinginformation'];
            }
            elseif($results['error'] == -2)
            {
                $display->errormessage = $lang['invalidemail'];
            }
            elseif($results['error'] == -3)
            {
                $display->errormessage = $lang['subusermissing'];
            }
        }
        else
        {
            $params = array('password' => $_REQUEST['password'],
                'email' => $_REQUEST['email'],
                'phone' => $_REQUEST['phone'],
                'firstname' => $_REQUEST['firstname'],
                'lastname' => $_REQUEST['lastname'],
                'address' => $_REQUEST['address'],
                'city' => $_REQUEST['city'],
                'state' => $_REQUEST['state'],
                'zipcode' => $_REQUEST['zipcode'],
                'country' => $_REQUEST['country'],
                'uid' => $_SESSION['uid']);
            $returnval = User::EditClient($params);
            if($returnval['error'] == 0)
            {
                $_SESSION['goodmessage'] = $lang['accountsettingssaved'];
                header("Location: index.php");
                exit();
            }
            elseif($returnval['error'] == -1)
            {
                $error = $lang['nouserspecified'];
            }
            elseif($returnval['error'] == -2)
            {
                $error = $lang['invalidemail'];
            }
            elseif($returnval['error'] == -3)
            {
                $error = $lang['nouserdatabase'];
            }
            elseif($returnval['error'] == -4)
            {
                $error = $lang['novalidemail'];
            }
            if(!empty($error))
            {
                $display->errormessage = $error;
            }
        }
    }

    /*
     * Save subuser
     */
    elseif($_REQUEST['mode'] == "savesubuser")
    {
        if(!empty($_REQUEST['subid']))
        {
            $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users_subusers` WHERE `subid`='%i' AND `mainid`='%i' LIMIT 1", array($_REQUEST['subid'], $_SESSION['uid'])));
            if(!$query || $query->num_rows != 1)
            {
                echo '<div id="error">'.$lang['subusermissing'].'</div>';
                exit();
            }
            $params = array("email" => $_REQUEST['email'],
                "password" => $_REQUEST['password'],
                "gameserver" => $_REQUEST['gameserver'],
                "subid" => $_REQUEST['subid'],
                "uid" => $_SESSION['uid']);
            $results = User::EditSubUser($params);
            if($results['error'] == 0)
            {
                echo '<div id="good">'.$lang['subusersaved'].'</div>';
            }
            elseif($results['error'] == -1)
            {
                echo '<div id="error">'.$lang['missinginformation'].'</div>';
            }
            elseif($results['error'] == -2)
            {
                echo '<div id="error">'.$lang['invalidemail'].'</div>';
            }
            elseif($results['error'] == -3)
            {
                echo '<div id="error">'.$lang['subusermissing'].'</div>';
            }
            exit();
        }
        else
        {
            $params = array("email" => $_REQUEST['email'],
                "password" => $_REQUEST['password'],
                "gameserver" => $_REQUEST['gameserver'],
                "uid" => $_SESSION['uid']);
            $results = User::AddSubUser($params);
            if($results['error'] == 0)
            {
                echo '<div id="good">'.$lang['subusersaved'].'</div>';
            }
            elseif($results['error'] == -1)
            {
                echo '<div id="error">'.$lang['novalidemail'].'</div>';
            }
            elseif($results['error'] == -2)
            {
                echo '<div id="error">'.$lang['invalidemail'].'</div>';
            }
            exit();
        }
    }
}
if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['overview'];

    if($_SESSION['subuser'] == true)
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users_subusers` WHERE `subid`=%i LIMIT 1", array($_SESSION['subid'])));
    }
    else
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` JOIN `users_profile` ON users_profile.uid=users.uid WHERE users.uid=%i AND `userlevel`='0' LIMIT 1", array($_SESSION['uid'])));
    }
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $display->info = $row;

        // Get the short eventlog
        if($_SESSION['subuser'] == true)
        {
            $eventlist = EventLog::ViewLog(array("orderby" => "`time` DESC", "limit" => 4, "runby" => $_SESSION['subid'], "type" => "!='debug'", "subuser" => "1"));
        }
        else
        {
            $eventlist = EventLog::ViewLog(array("limit" => "4", "orderby" => "time DESC", "userid" => $_SESSION['uid'], "runbyor" => $_SESSION['uid']));
        }
        if(count($eventlist) > 0)
        {
            $display->eventlist = $eventlist;
        }

        // Get the last login time
        if($_SESSION['subuser'] == true)
        {
            $lastlogin = EventLog::ViewLog(array("orderby" => "`time` DESC", "limit" => 1, "runby" => $_SESSION['subid'], "type" => "login", "subuser" => "1"));
        }
        else
        {
            $lastlogin = EventLog::ViewLog(array("userid" => $_SESSION['uid'], "type" => "login", "orderby" => "time DESC", "limit" => "1"));
        }
        if($lastlogin && count($lastlogin) == 1)
        {
            $display->lastlogin = $lastlogin[0]['time'];
        }

        // List all the game servers
        $services = array();
        $x = 0;

        if($_SESSION['subuser'] == true)
        {
            $querygames = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` JOIN `games` ON games.gid=usergames.gid JOIN `users_subusersperm` ON users_subusersperm.ugid=usergames.ugid WHERE `subid`=%i", array($_SESSION['subid'])));
            if($querygames && $querygames->num_rows > 0)
            {
                while($rowgames = $querygames->fetch_assoc())
                {
                    $services[$x] = $rowgames;
                    $services[$x]['ip'] = Machines::GetIP($rowgames['ipid'], true);
                    $services[$x]['name'] = $rowgames['name'];
                    $services[$x]['type'] = "game";
                    $services[$x]['status'] = $rowgames['status'];
                    $x++;
                }
            }
        }
        else
        {
            $gameservers = Games::ListGameServers(array("uid" => $_SESSION['uid']));
            foreach($gameservers as $gs)
            {
                $services[] = $gs;
            }
        }

        $machines = Machines::ListMachines(array("uid" => $_SESSION['uid']));
        $display->machines = array();

        if(count($machines) > 0)
        {
            $display->hasMachines = true;

            $x = 0;
            foreach($machines as $v)
            {
                if($v['os'] == "0")
                {
                    $v['os'] = "Linux";
                }
                elseif($v['os'] == "1")
                {
                    $v['os'] = "Windows";
                }

                if($v['slots'] == "-1")
                {
                    $v['slots'] = "N";
                }
                if($v['slots_quota'] == "-1")
                {
                    $v['slots_quota'] = "A";
                }

                if($v['servers'] == "-1")
                {
                    $v['servers'] = "N";
                }
                if($v['servers_quota'] == "-1")
                {
                    $v['servers_quota'] = "A";
                }

                $display->machines[$x] = $v;

                $x++;
            }
        }
        else
        {
            $display->hasMachines = false;
        }

        $display->services = $services;

        $display->DisplayType("client");
        $display->Output("client/index.tpl");
    }
    else
    {
        session_destroy();
        header("Location: ../index.php");
    }
}
elseif($_REQUEST['mode'] == "userprofile")
{
    $display->pagename = $lang['userprofile'];

    if($_SESSION['subuser'] == true)
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users_subusers` WHERE `subid`=%i LIMIT 1", array($_SESSION['subid'])));
        $row = $query->fetch_assoc();
        $display->info = $row;
    }
    else
    {
        $display->info = User::GetClientInfo($_SESSION['uid']);
    }
    $display->DisplayType("client");
    $display->Output("client/userprofile.tpl");
}
elseif($_REQUEST['mode'] == "eventlog")
{
    $display->pagename = $lang['eventlog'];
    $fulleventlist = EventLog::ViewLog(array("limit" => "150", "orderby" => "time DESC", "userid" => $_SESSION['uid'], "runbyor" => $_SESSION['uid']));
    if(count($fulleventlist) > 0)
    {
        $display->events = $fulleventlist;
    }
    $display->DisplayType("client");
    $display->Output("client/eventlog.tpl");
}
elseif($_REQUEST['mode'] == "subusers")
{
    $display->pagename = $lang['subusers'];

    $display->subusers = User::ListSubUsers($_SESSION['uid']);
    $display->DisplayType("client");
    $display->Output("client/subusers.tpl");
}
elseif($_REQUEST['mode'] == "subuserlist")
{
    $display->subusers = User::ListSubUsers($_SESSION['uid']);
    $display->DisplayType("ajax");
    $display->Output("client/ajax-subuserlist.tpl");
}
elseif($_REQUEST['mode'] == "delsubuser")
{
    if(!empty($_GET['subid']))
    {
        // Validate the subuser belongs to this user
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users_subusers` WHERE `subid`='%i' AND `mainid`='%i' LIMIT 1", array($_REQUEST['subid'], $_SESSION['uid'])));
        if(!$query || $query->num_rows != 1)
        {
            echo '<div id="error">'.$lang['unableremoveuser'].'</div>';
            exit();
        }
        $results = User::DeleteSubUser($_GET['subid']);
        if($results['error'] == 0)
        {
            echo '<div id="good">'.$lang['userremoved'].'</div>';
        }
        else
        {
            echo '<div id="error">'.$lang['unableremoveuser'].'</div>';
        }
        exit();
    }
}
elseif($_REQUEST['mode'] == "addsubuser")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT usergames.*, games.name FROM `usergames` JOIN `games` ON usergames.gid=games.gid WHERE `uid`=%i", array($_SESSION['uid'])));
    if($query && $query->num_rows > 0)
    {
        $gameserverarray = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $row['ip'] = Machines::GetIP($row['ipid'], true);
            $gameserverarray[$x] = $row;
            $x++;
        }
        $display->gameservers = $gameserverarray;
        $display->DisplayType("ajax");
        $display->Output("client/ajax-editsubuser.tpl");
    }
    else
    {
        echo "0";
    }
}
elseif($_REQUEST['mode'] == "editsubuser")
{
    if(!empty($_SESSION['uid']) && !empty($_REQUEST['subid']))
    {
        $info = User::GetSubUserInfo($_REQUEST['subid'], $_SESSION['uid']);
        if($info && count($info) != 0)
        {
            $display->subuser = $info['info'];
            $display->gameservers = $info['gameservers'];
            $display->uid = $_SESSION['uid'];
            $display->Output("client/ajax-editsubuser.tpl");
        }
        else
        {
            echo "0";
        }
    }
}
elseif($_REQUEST['mode'] == "serverinfo")
{
    // Image variables
    $online = '<div class="online"></div>';
    $offline = '<div class="offline"></div>';

    if(!empty($_REQUEST['ugid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            if($row['status'] == 1)
            {
                $params = array('ugid' => $row['ugid'],
                    'nomap' => true);
                $results = Games::QueryGame($params);
                if($results['error'] == 0)
                {
                    if($results['status'] == 1)
                    {
                        echo '<div id="status">'.$online.'</div>';
                        echo '<div id="players">'.$results['active']."/".$results['total'].'</div>';
                        if(strlen($results['hostname']) > 30)
                        {
                            $results['hostname'] = substr($results['hostname'], 0, 27)."...";
                        }
                        echo '<div id="hostname">'.$results['hostname'].'</div>';
                        exit();
                    }
                }
            }
        }
    }
    echo '<div id="status">'.$offline.'</div>';
    echo '<div id="players">'."N/A".'</div>';
    echo '<div id="hostname">'."N/A".'</div>';
    exit();
}
elseif($_REQUEST['mode'] == "machinestatus")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT game_server, debugging FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        if($row['game_server'] == "0")
        {
            echo "N/A";
            exit();
        }
        $results = Machines::VerifyConnection($_REQUEST['sid']);
        if($results == 1)
        {
            if($row['debugging'] == "1")
            {
                echo "<font style='color:green'>".$lang['online']."</font> - ".$lang['debugging'];
            }
            else
            {
                echo "<font style='color:green'>".$lang['online']."</font>";
            }
            exit();
        }
        elseif($results == 0)
        {
            if($row['debugging'] == "1")
            {
                echo "<font style='color:red'>".$lang['offline']."</font> - ".$lang['debugging'];
            }
            else
            {
                echo "<font style='color:red'>".$lang['offline']."</font>";
            }
            exit();
        }
        elseif($results == -1)
        {
            echo $lang['outdated'];
            exit();
        }
    }
}
elseif($_REQUEST['mode'] == "machineinfo")
{
    $display->DisplayType("ajax");
    $results = Machines::SystemInfo(array("sid" => $_REQUEST['sid']));
    if($results['error'] == 0)
    {
        $display->os = $results['os'];
        $display->memory = $results['memory'];
        $display->hd = $results['hd'];
        $display->version = $results['version'];
        $display->Output("client/ajax-machineinfo.tpl");
    }
    else
    {
        $display->errorcode = $results['error'];
        $display->Output("common/error.tpl");
    }
}

?>