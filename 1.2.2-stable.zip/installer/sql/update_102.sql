ALTER TABLE `emailtemplates` DROP `system` ;
DROP TABLE `messages` ;