ALTER TABLE `usergames_backups` CHANGE `size` `size` BIGINT(24) NOT NULL ;
ALTER TABLE `games_configoptions` ADD `illegalchars` VARCHAR(255) NOT NULL ;