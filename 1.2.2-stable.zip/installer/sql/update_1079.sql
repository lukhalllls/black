ALTER TABLE `machines` ADD `diskthrottle` VARCHAR(255) NOT NULL ;
ALTER TABLE `games_cache` ADD `quota` INT(10) NOT NULL DEFAULT '-1' AFTER `enabled` ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('advancedfeatures', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('loadbalancing', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('licensetimeout', '20') ;