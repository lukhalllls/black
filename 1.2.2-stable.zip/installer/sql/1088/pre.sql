ALTER TABLE `uservoice` ADD `queryport` INT(8) NOT NULL AFTER `port` ;

INSERT INTO `settings` (`name`, `value`) VALUES ('charset', 'auto') ;

ALTER TABLE `api_logs` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

ALTER TABLE `bans` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `count` `count` INT(2) UNSIGNED NOT NULL, CHANGE `lastattempt` `lastattempt` INT(16) UNSIGNED NOT NULL ;

ALTER TABLE `blacklist` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

ALTER TABLE `emails` CHANGE `templateid` `templateid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `emailtemplates` CHANGE `templateid` `templateid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

ALTER TABLE `events` CHANGE `eventid` `eventid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `userid` `userid` INT(10) UNSIGNED NOT NULL, CHANGE `runbyid` `runbyid` INT(10) UNSIGNED NOT NULL, CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL, CHANGE `uvid` `uvid` INT(10) UNSIGNED NOT NULL, CHANGE `time` `time` INT(16) UNSIGNED NOT NULL ;

ALTER TABLE `games` CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `graphs` `graphs` TINYINT(1) NOT NULL DEFAULT '1', CHANGE `fastdl` `fastdl` TINYINT(1) NOT NULL DEFAULT '0' ;

ALTER TABLE `games_addons` CHANGE `addonid` `addonid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `games_cache` CHANGE `cacheid` `cacheid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL, CHANGE `sid` `sid` INT(10) UNSIGNED NOT NULL, CHANGE `enabled` `enabled` TINYINT(1) NOT NULL DEFAULT '1', CHANGE `recheck` `recheck` TINYINT(1) NOT NULL, CHANGE `time` `time` INT(16) UNSIGNED NOT NULL ;

ALTER TABLE `games_configoptions` CHANGE `optionid` `optionid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL, CHANGE `control` `control` TINYINT(1) NOT NULL ;

ALTER TABLE `games_configs` CHANGE `cfid` `cfid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `games_scripts` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `games_updates` CHANGE `updateid` `updateid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `iplist` CHANGE `ipid` `ipid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `sid` `sid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `machines` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `cpucores` `cpucores` TINYINT(2) UNSIGNED NOT NULL DEFAULT '0', CHANGE `fileserver` `fileserver` INT(10) UNSIGNED NOT NULL, CHANGE `owner` `owner` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `news` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

ALTER TABLE `scheduler` CHANGE `id` `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `syscontrolid` `syscontrolid` INT(10) UNSIGNED NOT NULL, CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL, CHANGE `uvid` `uvid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `servermon_log` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `time` `time` INT(16) UNSIGNED NOT NULL ;

ALTER TABLE `syscontrol` CHANGE `controlid` `controlid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

ALTER TABLE `tasklist` CHANGE `taskid` `taskid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `usergames` CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `uid` `uid` INT(10) UNSIGNED NOT NULL, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL, CHANGE `ipid` `ipid` INT(10) UNSIGNED NOT NULL, CHANGE `private` `private` TINYINT(1) NOT NULL, CHANGE `status` `status` TINYINT(1) NOT NULL, CHANGE `servermon_disklimit` `servermon_disklimit` TINYINT(1) NOT NULL DEFAULT '0', CHANGE `dedicatedip` `dedicatedip` TINYINT(1) NOT NULL DEFAULT '0', CHANGE `locked` `locked` TINYINT(1) NOT NULL, CHANGE `servermon_offline` `servermon_offline` INT(11) UNSIGNED NOT NULL DEFAULT '0', CHANGE `servermon_notprivate` `servermon_notprivate` INT(11) UNSIGNED NOT NULL DEFAULT '0', CHANGE `servermon_slotsexceeded` `servermon_slotsexceeded` INT(11) UNSIGNED NOT NULL DEFAULT '0' ;

ALTER TABLE `usergames_backups` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL, CHANGE `sid` `sid` INT(10) UNSIGNED NOT NULL, CHANGE `timestamp` `timestamp` INT(16) UNSIGNED NOT NULL ;

ALTER TABLE `usergames_configoptions` CHANGE `configid` `configid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `optionid` `optionid` INT(10) UNSIGNED NOT NULL, CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `usergames_configs` CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL, CHANGE `cfid` `cfid` INT(10) UNSIGNED NOT NULL, CHANGE `exist` `exist` TINYINT(1) NOT NULL DEFAULT '1', CHANGE `lastchecked` `lastchecked` INT(16) UNSIGNED NOT NULL ;

ALTER TABLE `usergames_graphdata` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL, CHANGE `gid` `gid` INT(10) UNSIGNED NOT NULL, CHANGE `sid` `sid` INT(10) UNSIGNED NOT NULL, CHANGE `time` `time` INT(16) UNSIGNED NOT NULL ;

ALTER TABLE `users` CHANGE `uid` `uid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `mainadmin` `mainadmin` TINYINT(1) NOT NULL DEFAULT '0', CHANGE `status` `status` TINYINT(1) NOT NULL DEFAULT '1' ;

ALTER TABLE `users_profile` CHANGE `uid` `uid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

ALTER TABLE `users_subusers` CHANGE `subid` `subid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `mainid` `mainid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `users_subusersperm` CHANGE `subid` `subid` INT(10) UNSIGNED NOT NULL, CHANGE `ugid` `ugid` INT(10) UNSIGNED NOT NULL ;

ALTER TABLE `uservoice` CHANGE `uvid` `uvid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `uid` `uid` INT(10) UNSIGNED NOT NULL, CHANGE `ipid` `ipid` INT(10) UNSIGNED NOT NULL, CHANGE `status` `status` TINYINT(1) NOT NULL ;