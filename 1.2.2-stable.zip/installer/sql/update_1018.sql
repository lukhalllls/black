ALTER TABLE `games_cache` ADD `enabled` INT( 1 ) NOT NULL DEFAULT '1' ;
ALTER TABLE `games_cache` ADD `recheck` INT( 1 ) NOT NULL ;

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` char(32) NOT NULL,
  `data` longtext NOT NULL,
  `last_accessed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;