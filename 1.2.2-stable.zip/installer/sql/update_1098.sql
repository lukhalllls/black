ALTER TABLE `machines` CHANGE `ftpport` `ftpport` INT(6) NOT NULL DEFAULT '221' ;
CREATE TABLE IF NOT EXISTS `usergames_databases` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ugid` int(10) UNSIGNED NOT NULL,
  `db` varchar(32) NOT NULL,
  `user` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;