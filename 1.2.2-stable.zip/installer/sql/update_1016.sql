ALTER TABLE `games_addons` ADD `restart` tinyint(1) NOT NULL DEFAULT '0' ;
ALTER TABLE `games_addons` CHANGE `linux_command` `linux_command` VARCHAR( 2048 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;
ALTER TABLE `games_addons` CHANGE `windows_command` `windows_command` VARCHAR( 2048 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;
ALTER TABLE `games_updates` CHANGE `windows_command` `windows_command` VARCHAR( 2048 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;
ALTER TABLE `games_updates` CHANGE `linux_command` `linux_command` VARCHAR( 2048 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;