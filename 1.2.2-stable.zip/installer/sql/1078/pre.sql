ALTER TABLE `games_cache` ADD UNIQUE (`gid` ,`sid`) ;
ALTER TABLE `usergames` ADD `maintenance` TINYINT(1) NOT NULL DEFAULT '0' ;
ALTER TABLE `iplist` ADD `dedicated` TINYINT(1) NOT NULL DEFAULT '0' ;
ALTER TABLE `machines` ADD `fileserver` INT(10) NOT NULL ;