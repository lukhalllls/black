INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('console_lines', '500') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('ftp_displaypass', '0') ;
ALTER TABLE `usergames_configoptions` DROP `usercontrol` ;