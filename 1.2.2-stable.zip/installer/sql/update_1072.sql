ALTER TABLE `machines` ADD `backupfile_location` VARCHAR(256) NOT NULL DEFAULT '' AFTER `userfile_location` ;
ALTER TABLE `machines` CHANGE `listenport` `listenport` INT(6) NOT NULL DEFAULT '299' ;
ALTER TABLE `machines` CHANGE `ftpport` `ftpport` INT(6) NOT NULL DEFAULT '21' ;

ALTER TABLE  `games` ADD  `backups` TINYINT( 1 ) NOT NULL DEFAULT  '0',
ADD  `backupclientaccess` TINYINT( 1 ) NOT NULL DEFAULT  '0',
ADD  `backuplimit` INT( 3 ) NOT NULL DEFAULT  '0' ;

CREATE TABLE IF NOT EXISTS `usergames_backups` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ugid` int(10) NOT NULL,
  `sid` int(10) NOT NULL,
  `timestamp` int(16) NOT NULL,
  `size` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

ALTER TABLE `games_addons` CHANGE `windows_command` `windows_command` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;
ALTER TABLE `games_addons` CHANGE `linux_command` `linux_command` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;

ALTER TABLE  `games_updates` CHANGE `windows_command` `windows_command` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;
ALTER TABLE  `games_updates` CHANGE `linux_command` `linux_command` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ;

ALTER TABLE  `games_configs` CHANGE  `install`  `install` TINYINT( 1 ) NOT NULL DEFAULT  '1' ;
ALTER TABLE  `games_configs` CHANGE  `quickedit`  `quickedit` TINYINT( 1 ) NOT NULL DEFAULT  '1' ;