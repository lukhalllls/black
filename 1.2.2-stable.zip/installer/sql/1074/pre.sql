INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('skipsessionvalidation', 'false') ;
UPDATE `settings` SET `value`='bootstrap' WHERE `name`='template' ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_clientaccess', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_subuseraccess', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_subadminaccess', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_adminaccess', '1') ;
DELETE FROM `settings` WHERE `name`='graphs_cache' ;

CREATE TABLE IF NOT EXISTS `servermon_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `time` int(16) NOT NULL,
  `result` text NOT NULL,
  `session` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

ALTER TABLE `usergames` ADD `commandline` TEXT NOT NULL ;