INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('smarty_forcecompile', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('eventlog_gamebackup', '1') ;
ALTER TABLE `tasklist` ADD `misc4` VARCHAR( 255 ) NOT NULL ;