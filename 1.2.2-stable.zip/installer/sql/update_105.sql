INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('webftp_timeout', '5') ;
ALTER TABLE `machines` ADD `server_offline` TINYINT( 1 ) NOT NULL ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_machineoffline', 6) ;
INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES (6, 'Server Monitor: Backend not responding', '<p>Server Monitor was unable to connect to the backend on {ip}</p>') ;