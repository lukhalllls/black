ALTER TABLE `machines` ADD `cpucores` INT( 2 ) NOT NULL DEFAULT '0' ;
ALTER TABLE `usergames` ADD `affinity` INT( 2 ) NOT NULL DEFAULT '-1' ;
CREATE TABLE IF NOT EXISTS `usergames_configs` (
  `ugid` int(10) NOT NULL,
  `cfid` int(10) NOT NULL,
  `exist` int(1) NOT NULL DEFAULT '1',
  UNIQUE KEY `ugid` (`ugid`,`cfid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ;

INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('ftp_displayblacklist', '0') ;