ALTER TABLE `iplist` CHANGE `ip` `ip` VARCHAR(45) NOT NULL ;
ALTER TABLE `iplist` CHANGE `internalip` `internalip` VARCHAR(45) NOT NULL ;
ALTER TABLE `machines` CHANGE `main_ip` `main_ip` VARCHAR(45) NOT NULL ;
ALTER TABLE `machines` ADD `httpport` INT(6) NOT NULL DEFAULT '298' AFTER `ftpport` ;
ALTER TABLE `users` ADD `lastip` VARCHAR(45) NOT NULL ;

ALTER TABLE `games` ADD `fastdl` INT(1) NOT NULL DEFAULT '0',
ADD `fastdlurl` VARCHAR(64) NOT NULL ,
ADD `fastdlallowed` VARCHAR(256) NOT NULL ,
ADD `fastdlexclude` VARCHAR(256) NOT NULL ;

ALTER TABLE `usergames` ADD `fastdl` TINYINT(1) NOT NULL DEFAULT '0' ;