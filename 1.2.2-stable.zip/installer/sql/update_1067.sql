ALTER TABLE  `games` ADD  `rconprotocol` VARCHAR(32) NOT NULL ;
ALTER TABLE  `tasklist` ADD  `misc5` VARCHAR(255) NOT NULL ;