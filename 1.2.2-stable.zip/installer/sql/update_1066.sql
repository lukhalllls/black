ALTER TABLE `games_configs` CHANGE `install` `install` TINYINT(1) NOT NULL ;
ALTER TABLE `games_configs` CHANGE `quickedit` `quickedit` TINYINT(1) NOT NULL ;
