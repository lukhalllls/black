ALTER TABLE `games` CHANGE `port_custom1` `port_custom1default` INT( 6 ) NOT NULL ,
CHANGE `port_custom2` `port_custom2default` INT( 6 ) NOT NULL ,
CHANGE `port_custom3` `port_custom3default` INT( 6 ) NOT NULL ,
CHANGE `port_custom4` `port_custom4default` INT( 6 ) NOT NULL ;

ALTER TABLE `games_configoptions` ADD `fieldtype` VARCHAR( 256 ) NOT NULL ;
ALTER TABLE `games_configoptions` ADD `order` INT( 10 ) NOT NULL ;