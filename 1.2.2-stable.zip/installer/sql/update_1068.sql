ALTER TABLE `tasklist` ADD `data` TEXT NOT NULL ;
ALTER TABLE `tasklist` ADD `result` TEXT NOT NULL ;
ALTER TABLE `tasklist` DROP `newuser`, DROP `email`, DROP `misc1`, DROP `misc2`, DROP `misc3`, DROP `misc4`, DROP `misc5` ;
ALTER TABLE `iplist` ADD `alias` VARCHAR(255) NOT NULL ;
ALTER TABLE `tasklist` ADD `datefinished` VARCHAR(16) NOT NULL ;