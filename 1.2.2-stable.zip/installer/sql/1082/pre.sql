ALTER TABLE `machines` ADD `owner` INT(10) NOT NULL ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('ban_limit', '5') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('ban_expiretime', '30') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_logretention', '30') ;

CREATE TABLE IF NOT EXISTS `bans` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(46) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(2) NOT NULL,
  `lastattempt` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;