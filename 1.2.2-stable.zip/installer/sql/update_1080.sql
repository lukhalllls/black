INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('forcehttps', '0') ;
ALTER TABLE `games_scripts` ADD `wait` TINYINT(1) NOT NULL DEFAULT '0' ;