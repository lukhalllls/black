INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('machine_timeout', '5') ;

CREATE TABLE IF NOT EXISTS `games_cache` (
  `cacheid` int(10) NOT NULL AUTO_INCREMENT,
  `gid` int(10) NOT NULL,
  `sid` int(10) NOT NULL,
  `size` varchar(10) NOT NULL,
  `time` int(16) NOT NULL,
  PRIMARY KEY (`cacheid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

ALTER TABLE `machines`
  DROP `gamecache`,
  DROP `cachedtime` ;

ALTER TABLE `games` ADD `servermon` TINYINT( 1 ) NOT NULL DEFAULT '1' ;