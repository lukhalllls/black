INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('gameservergraphs_auth', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('graphs_cache', '1') ;
ALTER TABLE `games` ADD `redirectfolder` VARCHAR( 255 ) NOT NULL ;
ALTER TABLE `users` ADD `allowedips` TEXT NOT NULL ;