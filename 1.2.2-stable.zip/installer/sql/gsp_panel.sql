SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO" ;

--
-- Database: `gsp_panel`
--

-- --------------------------------------------------------

--
-- Table structure for table `blacklist`
--

CREATE TABLE IF NOT EXISTS `blacklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE IF NOT EXISTS `plugins` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `api_logs`
--

CREATE TABLE IF NOT EXISTS `api_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(16) NOT NULL,
  `user` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `request` text COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `response` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `servermon_log`
--

CREATE TABLE IF NOT EXISTS `servermon_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(16) unsigned NOT NULL,
  `result` text COLLATE utf8_unicode_ci NOT NULL,
  `session` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `templateid` int(10) unsigned NOT NULL,
  UNIQUE KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `emailtemplates`
--

CREATE TABLE IF NOT EXISTS `emailtemplates` (
  `templateid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`templateid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `eventid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `userid` int(10) unsigned NOT NULL,
  `runbyid` int(10) unsigned NOT NULL,
  `ugid` int(10) unsigned NOT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `time` int(16) unsigned NOT NULL,
  `subuser` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE IF NOT EXISTS `games` (
  `gid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `linux_enable` tinyint(1) NOT NULL DEFAULT '0',
  `windows_enable` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `querycode` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `port_increment` int(6) NOT NULL,
  `port_default` int(6) NOT NULL,
  `port_querydefault` int(6) NOT NULL,
  `port_rcondefault` int(6) NOT NULL,
  `port_custom1default` int(6) NOT NULL,
  `port_custom2default` int(6) NOT NULL,
  `port_custom3default` int(6) NOT NULL,
  `port_custom4default` int(6) NOT NULL,
  `files_path` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `linux_startmode` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linux_installtype` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `windows_exec` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `windows_startmode` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `windows_installtype` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `windows_workingpath` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `reinstall_enable` tinyint(1) NOT NULL DEFAULT '0',
  `windows_console` tinyint(1) NOT NULL,
  `ftp` tinyint(1) NOT NULL DEFAULT '1',
  `servermon` tinyint(1) NOT NULL DEFAULT '1',
  `redirectfolder` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `linux_logfile` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `windows_logfile` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `graphs` tinyint(1) NOT NULL DEFAULT '1',
  `consolekillcommand` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alertdiskusage` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `fastdl` tinyint(1) NOT NULL DEFAULT '0',
  `fastdlurl` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `fastdlallowed` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `fastdlexclude` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `rconprotocol` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `backups` tinyint(1) NOT NULL DEFAULT '0',
  `backupclientaccess` tinyint(1) NOT NULL DEFAULT '0',
  `backuplimit` int(3) NOT NULL DEFAULT '0',
  `addonmanager` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'stock',
  `servermon_offline_1` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'restart',
  `servermon_offline_2` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'restart',
  `servermon_offline_3` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'stop',
  `servermon_private_1` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'restart',
  `servermon_private_2` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'restart',
  `servermon_private_3` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'stop',
  `servermon_slots_1` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'restart',
  `servermon_slots_2` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'restart',
  `servermon_slots_3` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'stop',
  `servermon_cpulimit` int(3) NOT NULL DEFAULT '0',
  `servermon_cpu_1` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'email',
  `servermon_cpu_2` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'email',
  `servermon_cpu_3` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'email',
  `servermon_ramlimit` int(3) NOT NULL DEFAULT '0',
  `servermon_ram_1` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'email',
  `servermon_ram_2` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'email',
  `servermon_ram_3` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'email',
  `database_allowed` int(1) NOT NULL DEFAULT '0',
  `database_autocreate` int(1) NOT NULL DEFAULT '0',
  `database_adminurl` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `database_limit` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `games_addons`
--

CREATE TABLE IF NOT EXISTS `games_addons` (
  `addonid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `copyfolder` tinyint(1) NOT NULL,
  `windows_path` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linux_path` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `systemcommands` tinyint(1) NOT NULL,
  `windows_command` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linux_command` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `userinstall` tinyint(1) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `restart` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`addonid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `games_configoptions`
--

CREATE TABLE IF NOT EXISTS `games_configoptions` (
  `optionid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `control` tinyint(1) NOT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `fieldtype` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `order` int(10) NOT NULL,
  `illegalchars` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`optionid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `games_configs`
--

CREATE TABLE IF NOT EXISTS `games_configs` (
  `cfid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL,
  `directory` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `contents` longtext COLLATE utf8_unicode_ci NOT NULL,
  `rewrite` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `quickedit` tinyint(1) NOT NULL DEFAULT '1',
  `install` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cfid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `games_scripts`
--

CREATE TABLE IF NOT EXISTS `games_scripts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL,
  `description` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `os` tinyint(1) NOT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `legacy` tinyint(1) NOT NULL DEFAULT '0',
  `wait` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `games_updates`
--

CREATE TABLE IF NOT EXISTS `games_updates` (
  `updateid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `copyfolder` tinyint(1) NOT NULL,
  `windows_path` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linux_path` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `systemcommands` tinyint(1) NOT NULL,
  `windows_command` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linux_command` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `userinstall` tinyint(1) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`updateid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `iplist`
--

CREATE TABLE IF NOT EXISTS `iplist` (
  `ipid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL,
  `ip` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `internalip` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dedicated` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ipid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `machines`
--

CREATE TABLE IF NOT EXISTS `machines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alias` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `main_ip` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `os` tinyint(1) NOT NULL,
  `listenport` int(6) NOT NULL DEFAULT '299',
  `ftpport` int(6) NOT NULL DEFAULT '221',
  `httpport` int(6) NOT NULL DEFAULT '298',
  `passphrase` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `game_server` tinyint(1) NOT NULL DEFAULT '0',
  `slots_quota` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `servers_quota` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `file_location` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `userfile_location` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `backupfile_location` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `server_offline` tinyint(1) NOT NULL,
  `cpucores` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `debugging` tinyint(1) NOT NULL DEFAULT '0',
  `fileserver` int(10) unsigned NOT NULL,
  `diskthrottle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `owner` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `syscontrol`
--

CREATE TABLE IF NOT EXISTS `syscontrol` (
  `controlid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `controltype` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `game` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `gameupdate` int(10) NOT NULL,
  `machine` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `systemcommand` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`controlid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `tasklist`
--

CREATE TABLE IF NOT EXISTS `tasklist` (
  `taskid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ugid` int(10) unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateposted` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `result` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `datefinished` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`taskid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `usergames`
--

CREATE TABLE IF NOT EXISTS `usergames` (
  `ugid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `gid` int(10) unsigned NOT NULL,
  `ipid` int(10) unsigned NOT NULL,
  `private` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `port_main` int(6) NOT NULL,
  `port_query` int(6) NOT NULL,
  `port_rcon` int(6) NOT NULL,
  `port_custom1` int(6) NOT NULL,
  `port_custom2` int(6) NOT NULL,
  `port_custom3` int(6) NOT NULL,
  `port_custom4` int(6) NOT NULL,
  `priority` enum('Below Normal','Normal','Above Normal','High','Real Time') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Normal',
  `installed` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL,
  `billingid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `servermon_offline` int(11) unsigned NOT NULL DEFAULT '0',
  `servermon_notprivate` int(11) unsigned NOT NULL DEFAULT '0',
  `servermon_slotsexceeded` int(11) unsigned NOT NULL DEFAULT '0',
  `servermon_disklimit` tinyint(1) NOT NULL DEFAULT '0',
  `servermon_cpu` tinyint(1) NOT NULL DEFAULT '0',
  `servermon_ram` tinyint(1) NOT NULL DEFAULT '0',
  `affinity` int(2) NOT NULL DEFAULT '-1',
  `dedicatedip` tinyint(1) NOT NULL DEFAULT '0',
  `size` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `fastdl` tinyint(1) NOT NULL DEFAULT '0',
  `commandline` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ugid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `usergames_backups`
--

CREATE TABLE IF NOT EXISTS `usergames_backups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ugid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `timestamp` int(16) unsigned NOT NULL,
  `size` bigint(24) NOT NULL,
  `file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `usergames_configs`
--

CREATE TABLE IF NOT EXISTS `usergames_configs` (
  `ugid` int(10) unsigned NOT NULL,
  `cfid` int(10) unsigned NOT NULL,
  `exist` tinyint(1) NOT NULL DEFAULT '1',
  `lastchecked` int(16) unsigned NOT NULL,
  UNIQUE KEY `ugid` (`ugid`,`cfid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `usergames_databases`
--

CREATE TABLE IF NOT EXISTS `usergames_databases` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ugid` int(10) UNSIGNED NOT NULL,
  `db` varchar(32) NOT NULL,
  `user` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `usergames_configoptions`
--

CREATE TABLE IF NOT EXISTS `usergames_configoptions` (
  `configid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `optionid` int(10) unsigned NOT NULL,
  `ugid` int(10) unsigned NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`configid`),
  KEY `optionid` (`optionid`),
  KEY `ugid` (`ugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `usergames_graphdata`
--

CREATE TABLE IF NOT EXISTS `usergames_graphdata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ugid` int(10) unsigned NOT NULL,
  `time` int(16) unsigned NOT NULL,
  `usedslots` int(5) NOT NULL,
  `maxslots` int(5) NOT NULL,
  `status` int(1) NOT NULL,
  `cpu` int(5) NOT NULL,
  `memory` int(5) NOT NULL,
  `status_sum` int(5) NOT NULL,
  `gid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `archive` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ugid` (`ugid`),
  KEY `time` (`time`),
  KEY `gid` (`gid`),
  KEY `sid` (`sid`),
  KEY `archive` (`archive`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `userlevel` tinyint(1) NOT NULL DEFAULT '0',
  `permission` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `servermon_emails` int(1) NOT NULL DEFAULT '0',
  `billingid` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mainadmin` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `allowedips` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `session` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `lastip` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `users_profile`
--

CREATE TABLE IF NOT EXISTS `users_profile` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `zipcode` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `users_subusers`
--

CREATE TABLE IF NOT EXISTS `users_subusers` (
  `subid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `mainid` int(10) unsigned NOT NULL,
  `session` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`subid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `users_subusersperm`
--

CREATE TABLE IF NOT EXISTS `users_subusersperm` (
  `subid` int(10) unsigned NOT NULL,
  `ugid` int(10) unsigned NOT NULL,
  `perms` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`subid`,`ugid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `games_cache`
--


CREATE TABLE IF NOT EXISTS `games_cache` (
  `cacheid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `size` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `time` int(16) unsigned NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `quota` int(10) NOT NULL DEFAULT '-1',
  `recheck` tinyint(1) NOT NULL,
  PRIMARY KEY (`cacheid`),
  UNIQUE KEY `gid` (`gid`,`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessiondata` (
  `id` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `data` longtext COLLATE utf8_unicode_ci NOT NULL,
  `last_accessed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `scheduler`
--

CREATE TABLE IF NOT EXISTS `scheduler` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `crontime` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `syscontrolid` int(10) unsigned NOT NULL,
  `ugid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `bans`
--

CREATE TABLE IF NOT EXISTS `bans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(46) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(2) unsigned NOT NULL,
  `lastattempt` int(16) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `machine` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `game` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `datetime` datetime NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;


INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('email', '*@example.com') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', 'cod4_lnxded*') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', 'hlds_*') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', '*.so') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', '*.dll') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', 'srcds_*') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', '*.exe') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', '*.so.1') ;
INSERT IGNORE INTO `blacklist` (`type`, `content`) VALUES ('file', '*.so.6') ;


INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('newuser', 0) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('newserver', 2) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('password', 3) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_offline', 5) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_notprivate', 0) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_slotsexceeded', 0) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_machineoffline', 6) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_diskusage', 7) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_cpuexceeded', 11) ;
INSERT IGNORE INTO `emails` (`type`, `templateid`) VALUES ('servermon_ramexceeded', 12) ;


INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES (2, 'Your GSP-Panel game server is setup!', '<p>Hello {name},</p>\r\n<p style="padding-left: 30px;">Thank  you for ordering from GSP-Panel, your server is setup and the  information is below.</p>\r\n<p style="padding-left: 30px;">Game  Panel: <a title="{panelurl}" href="{panelurl}" target="_blank">{panelurl}</a></p>\r\n<p style="padding-left: 30px;">Username:  {username}</p>\r\n<p style="padding-left: 30px;">Password:  {password}</p>\r\n<p style="padding-left: 30px;">IP:  {ip}:{port}</p>\r\n<p style="padding-left: 30px;">&nbsp;</p>\r\n<p>Thanks,</p>\r\n<p>GSP-Panel Support</p>\r\n<p><a href="http://www.gsp-panel.com">www.gsp-panel.com</a></p>') ;
INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES (3, 'GSP-Panel Password Recovery', '<p>Hello,</p>\r\n<p>&nbsp;&nbsp;&nbsp; You have requested a password recovery, below is the information to login.</p>\r\n<p>&nbsp;&nbsp;&nbsp; <a title="{panelurl}" href="{panelurl}">{panelurl}</a></p>\r\n<p>&nbsp;&nbsp;&nbsp; Username: {username}</p>\r\n<p>&nbsp;&nbsp;&nbsp; Password: {password}</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>Thanks,</p>\r\n<p>GSP-Panel Support</p>\r\n<p><a href="http://www.gsp-panel.com">www.gsp-panel.com</a></p>') ;
INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES (5, 'Server Monitor: Server did not respond', '<p>The following server did not respond to a query:</p>\r\n<p>User: {email}</p>\r\n<p>Server: {External IP}:{PORT}</p>\r\n<p>User''s game id: {ugid}</p>') ;
INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES (6, 'Server Monitor: Backend not responding', '<p>Server Monitor was unable to connect to the backend on {ip}</p>') ;
INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES (7, 'Server Monitor - Disk Usage Alert', '<p>The following server has exceeded it''s allocated disk space</p>\r\n<p>User: {email}</p>\r\n<p>Server: {External IP}:{PORT}</p>\r\n<p>User''s game id: {ugid}</p>') ;
INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES(11, 'Server Monitor - CPU Limit Exceeded', '<p>The following server has exceeded&nbsp;the CPU limit.</p>\r\n<p>User: {email}</p>\r\n<p>Server: {External IP}:{PORT}</p>\r\n<p>User\'s game id: {ugid}</p>') ;
INSERT IGNORE INTO `emailtemplates` (`templateid`, `subject`, `content`) VALUES(12, 'Server Monitor - RAM Limit Exceeded', '<p>The following server has exceeded the RAM limit.</p>\r\n<p>User: {email}</p>\r\n<p>Server: {External IP}:{PORT}</p>\r\n<p>User\'s game id: {ugid}</p>') ;

INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('debugging', '0') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('template', 'bootstrap') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('smartydebug', '0') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('passencrypt', 'mcryptnew') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('title', 'GSP-Panel') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('webapi', '0') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('webapi_pass', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('mailserver', 'phpmail') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('email_name', 'GSP-Panel Support') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('email_from', 'noreply@yourdomain.com') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('email_reply', 'noreply@yourdomain.com') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('smtp_server', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('smtp_port', '465') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('smtp_auth', 'ssl') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('smtp_user', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('smtp_password', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('usequota', '0') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('redirectlogout', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('webftp', '1') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('webftpeditable', 'cfg, txt, ini') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('maintenance_mode', '0') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('maintenance_mainonly', '1') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('maintenance_message', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('language', 'english') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('gameservergraphs', '2') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('masterip', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('licensekey', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('licensekeycache', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('version', '') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('webftp_timeout', '5') ;
INSERT IGNORE INTO `settings`  (`name`, `value`) VALUES ('machine_timeout', '5') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_adduser', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_edituser', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_deleteuser', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_suspenduser', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_unsuspenduser', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_addadministrator', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_editadministrator', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_deleteadministrator', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_addmachine', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_editmachine', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_deletemachine', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_addgame', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_editgame', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_deletegame', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_addusergame', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_editusergame', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_deleteusergame', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_suspendserver', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_unsuspendserver', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_serverstarted', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_serverrestarted', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_serverstopped', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_reinstallserver', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_updatedserver', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_serverinstalled', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('console_lines', '500') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('ftp_displaypass', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('smarty_forcecompile', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('eventlog_gamebackup', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('gameservergraphs_auth', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('tmppath', '') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('servermon_lastrun', '') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('ftp_displayblacklist', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('baseurl', '') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('cronmethod', 'gsppanel') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('scheduleraccess', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('skipsessionvalidation', 'false') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_clientaccess', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_subuseraccess', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_subadminaccess', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_adminaccess', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('advancedfeatures', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('loadbalancing', '1') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('licensetimeout', '20') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('forcehttps', '0') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('ban_limit', '5') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('ban_expiretime', '30') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('webapi_logretention', '30') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('charset', 'auto') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('gameq_timeout', '10') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('gameq_streamtimeout', '300000') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES('gameq_writewait', '300') ;