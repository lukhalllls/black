INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('cronmethod', 'local') ;
INSERT IGNORE INTO `settings` (`name`, `value`) VALUES ('scheduleraccess', '0') ;
INSERT INTO `emailtemplates` (`subject`, `content`) VALUES('Server Monitor - Disk Usage Alert', '<p>The following server has exceeded it''s allocated disk space</p>\r\n<p>User: {email}</p>\r\n<p>Server: {External IP}:{PORT}</p>\r\n<p>User''s game id: {ugid}</p>') ;
ALTER TABLE `usergames` ADD  `servermon_disklimit` INT( 1 ) NOT NULL DEFAULT  '0' AFTER  `servermon_slotsexceeded` ;
ALTER TABLE `usergames` ADD  `size` VARCHAR( 32 ) NOT NULL ;
ALTER TABLE `games` ADD `alertdiskusage` VARCHAR(32) NOT NULL ;
CREATE TABLE IF NOT EXISTS `scheduler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL,
  `crontime` varchar(256) NOT NULL,
  `syscontrolid` int(10) NOT NULL,
  `ugid` int(10) NOT NULL,
  `uvid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;