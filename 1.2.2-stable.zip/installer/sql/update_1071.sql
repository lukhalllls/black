CREATE TABLE `news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `machine` varchar(32) NOT NULL,
  `game` varchar(32) NOT NULL,
  `voice` varchar(32) NOT NULL,
  `datetime` datetime NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;