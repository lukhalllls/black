ALTER TABLE  `games` ADD  `addonmanager` VARCHAR( 255 ) NOT NULL DEFAULT  'stock' ;
ALTER TABLE  `usergames_backups` ADD `file` varchar(256) NOT NULL ;

CREATE TABLE IF NOT EXISTS `plugins` (
  `id` varchar(32) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;