<?php

use GSPPanel\{Plugins, Display};

class Addon
{

    // Plugin meta data
    private $name = "Skelton Addon Installer";
    private $url = "http://gsp-panel.com";
    private $description = "This is an example plugin of an addon installer";
    private $version = "1.0";
    private $author = "GSP-Panel";
    private $type = "addon_manager";

    /*
     * Return an array of the plugin details
     * This is a required function
     */
    public function PluginDetails()
    {
        // Returns all the details of this plugin as an array
        return array("name" => $this->name, "type" => $this->type, "url" => $this->url, "description" => $this->description, "version" => $this->version, "author" => $this->author);
    }

    /*
     * Initialize the plugin
     * This is a required function
     */
    public function Init()
    {
        // This is called when the plugin is loaded
        // This is a good place to check any custom databases, bind events, setup variables, etc
        // No need to bind events for this addon since functions will be called directly
    }

    /*
     * Install the plugin
     * This is a required function
     */
    public function Install()
    {
        // This is called when the plugin is enabled
        // return true for a successful install or false for a failed install
        return array("status" => true);
    }

    /*
     * Uninstall the plugin
     * This is a required function
     */
    public function Uninstall()
    {
        // This is called when the plugin is disabled
        // return true for a successful uninstall or false for a failed uninstall
        return array("status" => false, "error" => "Unable to uninstall plugin");
    }

    /*
     *  This function should return an array of addons
     *  The first variable passed to this is the game's ID
     */
    public function ListAddons($gid = 0)
    {
        $plugins = array();
        $plugins[] = array("name" => "Addon 123", "description" => "Example Addon", "addonid" => "1");
        $plugins[] = array("name" => "Addon 456", "description" => "Example Addon", "addonid" => "2");
        $plugins[] = array("name" => "Addon 789", "description" => "Example Addon", "addonid" => "3");
        return $plugins;
    }

    /*
     * This function is used to install the addon, since this is a plugin it probably has it's own methods of installing
     * This is passed an array, the first value is the user's game id, the second value is the addon's id
     */
    public function InstallAddon($params)
    {
        $ugid = $params['ugid'];
        $addonid = $params['addonid'];

        // See the Games::InstallAddon API function documentation for a list of valid returns
        return array("error" => 0);
    }
    
    /*
     * Display the addon list while in the gameserver
     * The first variable passed to this is the game's ID
     */
    public function DisplayAddons($gid = 0)
    {
        Display::getInstance()->addons = json_encode($this->ListAddons());
        Display::getInstance()->Output(DOC_ROOT."/includes/plugins/addon/addonlist.tpl");
    }
    
    /*
     * Display the addon manager for admins
     * The first variable passed to this is the game's ID
     */
    public function DisplayAddonManager($gid = 0)
    {
        die("This addon does not have any settings");
    }

    /*
     * Add an addon to this plugin
     * The variables passed to this can be seen by reviewing the Games::AddGameAddon API documentation
     */
    public function AddGameAddon($params)
    {
        // See the Games::AddGameAddon API function documentation for a list of valid returns
        return array("error" => 0);
    }

    /*
     * Edit an addon for this plugin
     * The variables passed to this can be seen by reviewing the Games::EditGameAddon API documentation
     */
    public function EditGameAddon($params)
    {
        // See the Games::EditGameAddon API function documentation for a list of valid returns
        return array("error" => 0);
    }

    /*
     * Deletes an addon from the plugin
     * The first variable is the game's ID, the second variable is the addon's ID
     */
    public function DeleteAddon($params)
    {
        $gid = $params['gid'];
        $addonid = $params['addonid'];
        // Delete from the database
        // Delete any files
    }
}
?>

