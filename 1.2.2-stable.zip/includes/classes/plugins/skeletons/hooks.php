<?php

use GSPPanel\{Plugins, Email};

class Hooks
{
    // Plugin meta data
    private $name = "Skelton Hook Plugin";
    private $url = "http://gsp-panel.com";
    private $description = "This is an example plugin that binds to hooks";
    private $version = "1.0";
    private $author = "GSP-Panel";
    private $type = "hook";

    // Returns an array of plugin details
    public function PluginDetails()
    {
        return array("name" => $this->name, "type" => $this->type, "url" => $this->url, "description" => $this->description, "version" => $this->version, "author" => $this->author);
    }

    // Initialize the plugin
    public function Init()
    {
        // This is called when the plugin is loaded
        // This is a good place to check any custom databases, bind events, setup variables, etc
        
        // Bind to the addon_installed event which will call the addon_email function with a priority of 1 (first addon_installed hook to get called)
        Plugins::getInstance()->bindEvent("addon_installed", get_class(), "addon_email", 1);
    }

    public function Install()
    {
        // This is called when the plugin is enabled
        // return true for a successful install or false for a failed install
        return array("status" => true);
    }

    public function Uninstall()
    {
        // This is called when the plugin is disabled
        // return true for a successful uninstall or false for a failed uninstall
        return array("status" => false, "error" => "Unable to install plugin");
    }

    /**
     * This function is called when addon_installed event is triggered
     */
    public function addon_email($ugid, $addonid)
    {
        $addons = array("4");
        // If the addon is in the above array, send an email
        if(in_array($addonid, $addons))
        {
            Emails::SendMail(array("subject" => "test", "content" => "your content", "email" => "some@emailaddress.com"));
        }
    }

}
?>

