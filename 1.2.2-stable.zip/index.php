<?php

require_once("includes/gsp-panel.php");

use GSPPanel\{User, GSP, EventLog, SafeSQL};

if(isset($_REQUEST['action']))
    $action = $_REQUEST['action'];
if(isset($_REQUEST['password']))
    $password = $_REQUEST['password'];
if(isset($_REQUEST['email']))
    $email = $_REQUEST['email'];

if(isset($_GET['action']) && $_GET['action'] == "login")
{
    $redirect = true;
}
else
{
    $redirect = false;
}

if(empty($action) || $action == "login")
{
    if($action == "login")
    {
        if(empty($email) || empty($password))
        {
            echo '<div id="error">'.$lang['invalidlogin'].'</div>';
            exit();
        }
        else
        {
            // Check if the users login is correct
            $logincheck = User::Login($email, $password);
            // Account is suspended
            if($logincheck == -1)
            {
                echo '<div id="error">'.$lang['accountsuspended'].'</div>';
                exit();
            }
            // Invalid IP
            elseif($logincheck == -2)
            {
                echo '<div id="error">'.$lang['invalidip'].'</div>';
                exit();
            }
            // Incorrect information
            elseif($logincheck == 0)
            {
                echo '<div id="error">'.$lang['invalidlogin'].'</div>';
                exit();
            }
            // Login successful
            elseif($logincheck == 1)
            {
                $_SESSION['language'] = $_REQUEST['language'];
                // If the user is an administrator redirect to the admin section
                if($_SESSION['userlevel'] == "1")
                {
                    EventLog::Log("login", $_SESSION['uid'], $_SESSION['uid']);
                    if($redirect == true)
                    {
                        header("Location: admin/index.php");
                    }
                    echo '<div id="good">admin/index.php</div>';
                    exit();
                }
                else
                {
                    if($_SESSION['subuser'] == true)
                    {
                        EventLog::Log("login", $_SESSION['uid'], $_SESSION['subid'], "", true);
                    }
                    else
                    {
                        EventLog::Log("login", $_SESSION['uid'], $_SESSION['uid']);
                    }

                    // Redirect the user to the client section
                    if($redirect == true)
                    {
                        header("Location: client/index.php");
                    }
                    echo '<div id="good">client/index.php</div>';
                    exit();
                }
            }
        }
    }
    // Display login
    $display->pagename = $lang['login'];

    $languages = array();
    $dir = opendir("includes/lang/");
    while($file = readdir($dir))
    {
        if($file != "." && $file != ".." && is_file("includes/lang/".$file))
        {
            $path_info = pathinfo("includes/lang/".$file);
            if($path_info['extension'] == "php")
            {
                $languages[] = str_replace(".php", "", $file);
            }
        }
    }
    $display->languages = $languages;

    $display->DisplayType("login");
    $display->Output("login/login.tpl");
}
elseif($action == "forgotpassword")
{
    // A post was submitted with an email address
    if(isset($email))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` JOIN `users_profile` ON users.uid=users_profile.uid WHERE `email`='%s' LIMIT 1", array($email)));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            // The user is suspended
            if($row['status'] != "1")
            {
                echo '<div id="error">'.$lang['accountsuspended'].'</div>';
                exit();
            }
            else
            {
                // Update the password
                if($row['userlevel'] == "1")
                {
                    User::EditAdmin(array("uid" => $row['uid'], "email" => $row['email'], "password" => Strings::createRandomPassword()));
                }
                else
                {
                    User::EditClient(array("uid" => $row['uid'], "email" => $row['email'], "password" => Strings::createRandomPassword()));
                }
                // Send the forgot password email
                $results = Emails::SendMail(array("type" => "password", "uid" => $row['uid']));
                if($results['error'] == 0)
                {
                    $_SESSION['goodmessage'] = $lang['recoveryemail'];
                    echo '<div id="good">index.php</div>';
                    exit();
                }
                else
                {
                    echo '<div id="error">'.$lang['recoveryemailerror'].'</div>';
                    exit();
                }
            }
            header("Location: index.php");
        }
        // The user does not exist
        else
        {
            echo '<div id="error">'.$lang['noaccount'].'</div>';
            exit();
        }
    }
    // Display forgot password
    $display->pagename = $lang['forgotpassword'];
    $display->tab = 1;
    $display->DisplayType("login");
    $display->Output("login/login.tpl");
}
elseif($action == "logout")
{
    // Destroy session
    @session_start();
    $_SESSION = array();
    session_unset();
    session_destroy();
    // Redirect if needed
    if(GSP::getInstance()->settings['redirectlogout'] != "")
    {
        header("Location: ".GSP::getInstance()->settings['redirectlogout']);
        exit();
    }
    else
    {
        header("Location: index.php");
        exit();
    }
}
?>