<?php
require_once("includes/gsp-panel.php");

use GSPPanel\GSP;

$display->pagename = "Maintenance";
$display->DisplayType("login");
$display->message = GSP::getInstance()->settings['maintenance_message'];
$display->Output("common/maintenance.tpl");
?>