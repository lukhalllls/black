$(document).ready(function() {
    var path = window.location.href; // because the 'href' property of the DOM element is the absolute path
    $("#layoutSidenav_nav .sb-sidenav a.nav-link").each(function() {
        if (this.href === path) {
            $(this).addClass("active");
        }
    });

    // Toggle the side navigation
    $("#sidebarToggle").on("click", function(e) {
        e.preventDefault();
        $("body").toggleClass("sb-sidenav-toggled");
    });
    
    // ADD SLIDEDOWN ANIMATION TO DROPDOWN //
    $('.dropdown').on('show.bs.dropdown', function(e) {
        $(this).find('.dropdown-menu').first().stop(true, true).slideDown();
    });

    // ADD SLIDEUP ANIMATION TO DROPDOWN //
    $('.dropdown').on('hide.bs.dropdown', function(e) {
        $(this).find('.dropdown-menu').first().stop(true, true).slideUp();
    });

    // Activate tooltips
    $('[data-toggle="tooltip"]').tooltip();

    // Go to the tab specified in url
    var hash = document.location.hash;
    var prefix = "tab_";
    if (hash) {
        $('.nav-tabs a[href="' + hash.replace(prefix, "") + '"]').tab('show');
    }

    // Change hash for page-reload
    $('.nav-tabs a').on('shown.bs.tab', function(e) {
        //    window.location.hash = e.target.hash.replace("#", "#" + prefix);
    });

    $('.nav-tabs a').click(function(e) {
        var url = $(this).attr("data-url");
        if (url)
        {
            $.fn.ajaxWindow();
            e.preventDefault();

            var url = $(this).attr("data-url");
            var href = this.hash;
            var pane = $(this);

            // ajax load from data-url
            $.ajax(url, {
               timeout: 30000, // 1000 ms
               success: function (data) {
                   $(href).html(data);
                   $.fn.ajaxWindow(false);
                    pane.tab('show');
               } 
            });
        }
    });

    // Display the ajax loading dialog on page changes
    window.onbeforeunload = function() {
        $.fn.ajaxWindow();
    };

    /* Setup datatable defaults */
    $.extend($.fn.dataTable.defaults, {
        "sPaginationType": "simple_numbers",
        "bFilter": false,
        "bSort": false,
        "bPaginate": true,
        "bDestroy": true,
        "iDisplayLength": 25,
        "bLengthChange": false,
        "sDom": "<'row'<'span6'T><'span6'f>r>t<'row'<'span6'p>>",
        // Setup for responsive datatables helper.
        bAutoWidth: false
    });


    /* Create a datatable with responsive attributes */
    $.fn.CreateDatatable = function(table, options) {
        var defaults = {
            "fnDrawCallback": function() {
                $('table' + table + ' td').bind('mouseenter', function() {
                    $(this).parent().children().each(function() {
                        $(this).addClass('datatable_highlight');
                    });
                });
                $('table' + table + ' td').bind('mouseleave', function() {
                    $(this).parent().children().each(function() {
                        $(this).removeClass('datatable_highlight');
                    });
                });
            },
            responsive: {
                details: false
            }
        };

        $.extend(defaults, options);
        var tableContainer = $(table);
        return tableContainer.dataTable(defaults);
        //return tableContainer;
    };


    /* Create a bootbox with the specified title and message */
    $.fn.Alert = function(title, message) {
        BootstrapDialog.show({
            title: "<i class=\"fa fa-exclamation-triangle\"> " + title,
            message: message
        });
    };

    /* Show the ajax loading window */
    var ajaxopened = false;
    $.fn.ajaxWindow = function(enabled)
    {
        if (typeof (enabled) === 'undefined')
        {
            enabled = true;
        }
        if (enabled === false)
        {
            ajaxopened = false;
            $('#ajaxprocessing').modal('hide');
        }
        else
        {
            if (ajaxopened !== true)
            {
                $('#ajaxprocessing').modal({backdrop: 'static'}, 'show');
                ajaxopened = true;
            }
        }
    };

    /* Create a function that parses good/bad error messages from ajax */
    $.fn.ParseAjax = function(data) {
        var response = $('<div />').html(data);
        // Check for a good response
        if ($(response).find('#good').text().length) {
            $('#ajax_good_text').html($(response).find('#good').text()).parent().show();
        }
        else
        {
            $("#ajax_good").hide();
        }
        // Check for an error
        if ($(response).find('#error').text().length) {
            $('#ajax_error_text').html($(response).find('#error').text()).parent().show();
        }
        else
        {
            $("#ajax_error").hide();
        }
    };

    // Setup tooltips
    $(document).tooltip({
        selector: '[data-toggle="tooltip"]'
    });

    /* Defaults for ajax */
    $.ajaxSetup({
        cache: false,
        timeout: 15000,
        type: 'GET'
    });

    /*$(document).ajaxStart(function() {
        $('#loadingbar').show();
    });
    $(document).ajaxStop(function() {
        $('#loadingbar').hide();
    });*/


    $(document).on("click", "[data-toggle='prompt']", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        var question = $(this).attr('data-question');
        BootstrapDialog.confirm(question, function(r) {
            if (r)
            {
                $.fn.ajaxWindow();
                $.ajax({
                    timeout: 80000,
                    url: url,
                    success: function(msg) {
                        location.reload();
                    },
                    error: function() {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                        location.reload();
                    }
                });
            }
        });
        return false;
    });

    /* Scheduler */
    $(document).on('change', "#scheduletype", (function () {
        var type = $(this).val();
        $(".syscontrollist").hide();
        if (type == "syscontrol")
        {
            $(".syscontrollist").show();
        }
        $('#crontime').empty();
        $('#crontime').cron({
            initial: "0 * * * *",
            customValues: {
                "5 Minutes" : "*/5 * * * *"
            },
            onChange: function() {
                $('input[name=crontime]').val($(this).cron("value"));
            }
        });
        return false;
    }));

    /* Game cron */
    $(document).on("click", ".addcronlink", function(e) {
        e.preventDefault();
        BootstrapDialog.show({
            message: $('#addcron').html(),
            title: add,
            onshow: function(dialogRef) {
                $(dialogRef.getModalBody()).find('#crontime').cron({
                    initial: "0 0 * * *",
                    onChange: function() {
                        $(dialogRef.getModalBody()).find('input[name=crontime]').val($(this).cron("value"));
                    }
                });
            },
            buttons: [
                {
                    label: cancel,
                    action: function(dialogRef) {
                        dialogRef.close();
                    }
                },
                {
                    icon: 'fa fa-save',
                    label: save,
                    action: function(dialogRef) {
                        $(dialogRef.getModalBody()).find('form').ajaxSubmit({
                            beforeSubmit: function() {
                                $.fn.ajaxWindow();
                            },
                            clearForm: true,
                            resetForm: true,
                            type: 'post',
                            timeout: 30000,
                            success: function(data) {
                                //  $.fn.ajaxWindow(false);
                                $.fn.refreshCrons();
                                $.fn.ParseAjax(data);
                            },
                            error: function(objAJAXRequest, strError) {
                                $.fn.ajaxWindow(false);
                                $.fn.Alert(error, timedout);
                            }
                        });
                        dialogRef.close();
                    }
                }
            ]
        });
        return false;
    });
    $.fn.refreshCrons = function() {
        $.fn.ajaxWindow();
        $('#cron_list').empty();
        $("#cron_list").load(gamepage + "?mode=viewcrons&ugid=" + ugid + "&rand=" + Math.random(), function() {
            $.fn.CreateDatatable('#schedulerdatatable');
            $.fn.ajaxWindow(false);
        });
    };
    $(document).on("click", ".deletecron", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(deletescheduledtaskquestion, function(r) {
            if (r)
            {
                $.ajax({
                    url: url,
                    timeout: 30000,
                    beforeSend: function() {
                        $.fn.ajaxWindow();
                    },
                    success: function(data) { 
                        if(typeof ugid === 'undefined')
                        {
                            $.fn.ajaxWindow();
                            window.location.href = url;
                        }
                        else
                        {
                            $.fn.refreshCrons();
                            $.fn.ParseAjax(data);
                        }
                    },
                    error: function(objAJAXRequest, strError) {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                    }
                });
            }
        });
        return false;
    });

    /*  Game Databases */
    $(document).on("click", ".createdatabase", function(e) {
        e.preventDefault();
        BootstrapDialog.show({
            message: $('#createdatabase').html(),
            title: add,
            onshow: function(dialogRef) {
                
            },
            buttons: [
                {
                    label: cancel,
                    action: function(dialogRef) {
                        dialogRef.close();
                    }
                },
                {
                    icon: 'fa fa-save',
                    label: save,
                    action: function(dialogRef) {
                        $(dialogRef.getModalBody()).find('form').ajaxSubmit({
                            beforeSubmit: function() {
                                $.fn.ajaxWindow();
                            },
                            clearForm: true,
                            resetForm: true,
                            type: 'post',
                            timeout: 30000,
                            success: function(data) {
                                //  $.fn.ajaxWindow(false);
                                $.fn.refreshDatabases();
                                $.fn.ParseAjax(data);
                            },
                            error: function(objAJAXRequest, strError) {
                                $.fn.ajaxWindow(false);
                                $.fn.Alert(error, timedout);
                            }
                        });
                        dialogRef.close();
                    }
                }
            ]
        });
        return false;
    });
    $.fn.refreshDatabases = function() {
        $.fn.ajaxWindow();
        $('#database_list').empty();
        $("#database_list").load(gamepage + "?mode=viewdatabases&ugid=" + ugid + "&rand=" + Math.random(), function() {
            $.fn.CreateDatatable('#databasedatatable');
            $.fn.ajaxWindow(false);
        });
    };

    $(document).on("click", ".deletedatabase", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(deletedatabasequestion, function(r) {
            if (r)
            {
                $.ajax({
                    url: url,
                    timeout: 30000,
                    beforeSend: function() {
                        $.fn.ajaxWindow();
                    },
                    success: function(data) {
                        $.fn.refreshDatabases();
                        $.fn.ParseAjax(data);
                    },
                    error: function(objAJAXRequest, strError) {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                    }
                });
            }
        });
        return false;
    });

    /* Console */
    $(document).on("click", ".rconsendcommand", function(e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var rconpass = $("input[name=rconpassword]").val();
        var rconcommand = $("input[name=rconcommand]").val();
        $.ajax({
            url: url,
            method: 'post',
            data: 'rconpassword=' + rconpass + "&rconcommand=" + rconcommand,
            timeout: 30000,
            beforeSend: function() {
                $('#rconresponse').html('<div class="fa fa-spinner fa-spin"></div>');
            },
            success: function(data) {
                $('#rconresponse').html(data);
                $("#refreshconsolelog").trigger("click");
            },
            error: function(objAJAXRequest, strError) {
                $.fn.Alert(error, timedout);
            }
        });
        return false;
    });
    
    $(document).on("click", "#refreshconsolelog", function(e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        $.ajax({
            url: url,
            beforeSend: function() {
                $('#displayconsolelog').html('<img src="../templates/' + template + '/images/ajax-loader.gif" />');
            },
            success: function(data) {
                var response = $('<div />').html(data);
                // Check for an error
                if ($(response).find('#error').text().length) {
                    $('#displayconsolelog').html($(response).find('#error').text()).parent().show();
                }
                else
                {
                    $('#displayconsolelog').html(data);
                    // Scroll to the bottom of the div
                    $('#displayconsolelog').scrollTop(1E10);
                }
            },
            error: function(objAJAXRequest, strError) {
                $.fn.Alert(error, timedout);
            }
        });
        return false;
    })

    /* QuickEdit */
    $(document).on("click", ".quickedit", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        $.ajax({
            url: url,
            beforeSend: function() {
                $.fn.ajaxWindow();
            },
            success: function(data) {
                $.fn.ajaxWindow(false);
                var response = $('<div />').html(data);
                // Check for an error
                if ($(response).find('#error').text().length)
                {
                    $('#ajax_error_text').html($(response).find('#error').text()).parent().show();
                }
                else
                {
                    BootstrapDialog.show({
                        title: edit,
                        message: data,
                        height: '600px',
                        buttons: [{
                                label: cancel,
                                action: function(dialogRef) {
                                    dialogRef.close();
                                }
                            }, {
                                icon: 'fa fa-save',
                                label: save,
                                action: function(dialogRef) {
                                    $(dialogRef.getModalBody()).find('form').ajaxSubmit({
                                        beforeSubmit: function() {
                                            $.fn.ajaxWindow();
                                        },
                                        clearForm: true,
                                        resetForm: true,
                                        type: 'post',
                                        timeout: 30000,
                                        success: function(data) {
                                            $.fn.ajaxWindow(false);
                                            $.fn.ParseAjax(data);
                                        },
                                        error: function(objAJAXRequest, strError) {
                                            $.fn.ajaxWindow(false);
                                            $.fn.Alert(error, timedout);
                                        }
                                    });
                                    dialogRef.close();
                                }
                            }]
                    });
                }
            },
            error: function(objAJAXRequest, strError) {
                $.fn.ajaxWindow(false);
                $.fn.Alert(error, timedout);
            }
        });
        return false;
    });

    /* Game backups */
    $.fn.refreshBackups = function() {
        $.fn.ajaxWindow();
        $('#backup_list').empty();
        $("#backup_list").load(gamepage + "?mode=viewbackups&ugid=" + ugid + "&rand=" + Math.random(), function() {
            $.fn.CreateDatatable('#backupsdatatable');
            $.fn.ajaxWindow(false);
        });
    };
    $(document).on("click", ".backup", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(backupquestion, function(r) {
            if (r)
            {
                $.ajax({
                    url: url,
                    timeout: 30000,
                    beforeSend: function() {
                        $.fn.ajaxWindow();
                    },
                    success: function(data) {
                        $.fn.ParseAjax(data);
                        $.fn.refreshBackups();
                    },
                    error: function(objAJAXRequest, strError) {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                    }
                });
            }
        });
        return false;
    });
    $(document).on("click", ".deletebackup", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(deletebackupquestion, function(r) {
            if (r)
            {
                $.ajax({
                    url: url,
                    timeout: 30000,
                    beforeSend: function() {
                        $.fn.ajaxWindow();
                    },
                    success: function(data) {
                        $.fn.refreshBackups();
                        $.fn.ParseAjax(data);
                    },
                    error: function(objAJAXRequest, strError) {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                    }
                });
            }
        });
        return false;
    });
    $(document).on("click", ".restorebackup", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(restorebackupquestion, function(r) {
            if (r)
            {
                $.ajax({
                    url: url,
                    timeout: 30000,
                    beforeSend: function() {
                        $.fn.ajaxWindow();
                    },
                    success: function(data) {
                        $.fn.ajaxWindow(false);
                        $.fn.ParseAjax(data);
                    },
                    error: function(objAJAXRequest, strError) {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                    }
                });
            }
        });
        return false;
    });

    /* Install updates/addons */
    $(document).on("click", ".installaddon", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(addonquestion, function(r) {
            if (r)
            {
                $.fn.ajaxWindow();
                $.ajax({
                    timeout: 80000,
                    url: gamepage + "?mode=installaddon&ugid=" + ugid + "&addonid=" + url,
                    success: function(msg) {
                        location.reload();
                    },
                    error: function() {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                        location.reload();
                    }
                });
            }
        });
        return false;
    });
    $(document).on("click", ".installupdate", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(updatequestion, function(r) {
            if (r)
            {
                $.fn.ajaxWindow();
                $.ajax({
                    timeout: 80000,
                    url: url,
                    success: function(msg) {
                        window.location.href = msg;
                    },
                    error: function() {
                        $.fn.ajaxWindow(false);
                        $.fn.Alert(error, timedout);
                        location.reload();
                    }
                });
            }
        });
        return false;
    });


    $(document).on("click", ".unlockgame", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(unlockgamequestion, function(r) {
            if (r)
            {
                window.location = url;
            }
        });
        return false;
    });

    $.fn.refreshGame = function() {
        $.ajax({
            url: gamepage + "?mode=gameinfo&ugid=" + ugid + "&rand=" + Math.random(),
            timeout: 20000,
            beforeSend: function() {
                $("#gameinfo").html('<img src="../templates/' + template + '/images/ajax-loader.gif" />');
            },
            success: function(data) {
                $("#gameinfo").html(data);
            },
            error: function(objAJAXRequest, strError) {
                $("#gameinfo").html(loadingerror);
            }
        });
    };

    /*
     * SUBUSERS
     */
    $.fn.refreshSubusers = function() {
        $('#subuserlist').empty();
        if (userlevel === "1")
        {
            $("#subuserlist").load("clients.php?mode=subuserlist&uid=" + $("input[name=uid]").val(), function() {
                $.fn.CreateDatatable('#subuserlisttable');
                $.fn.ajaxWindow(false);
            });
        }
        else
        {
            $("#subuserlist").load("index.php?mode=subuserlist", function() {
                $.fn.CreateDatatable('#subuserlisttable');
                $.fn.ajaxWindow(false);
            });
        }
    };
    var optionssubuser = {
        beforeSubmit: function() {
            $.fn.ajaxWindow();
        },
        clearForm: true,
        resetForm: true,
        type: 'post',
        success: function(data) {
            $.fn.refreshSubusers();

            $.fn.ParseAjax(data);
        }
    };
    $(document).on("click", ".addsubuserlink", function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('href'),
            beforeSend: function() {
                $.fn.ajaxWindow();
            },
            success: function(html) {
                $.fn.ajaxWindow(false);
                if (html.replace(/^(\r\n)|(\n)/, '') === "0")
                {
                    $.fn.Alert(error, noservices);
                }
                else
                {
                    BootstrapDialog.show({
                        message: html,
                        title: addsubuser,
                        buttons: [
                            {
                                label: cancel,
                                action: function(dialogRef) {
                                    dialogRef.close();
                                }
                            },
                            {
                                icon: 'fa fa-save',
                                label: save,
                                action: function(dialogRef) {
                                    $(dialogRef.getModalBody()).find('form').ajaxSubmit(optionssubuser);
                                    dialogRef.close();
                                }
                            }
                        ]
                    });
                }
            },
            error: function(objAJAXRequest, strError) {
                $.fn.ajaxWindow(false);
                $.fn.Alert(error, errorsubuser);
            }
        });
        return false;
    });
    $(document).on("click", ".deletesubuser", function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        BootstrapDialog.confirm(delsubuser, function(r) {
            if (r) {
                $.fn.ajaxWindow();
                $.get(url, function(data) {
                    $.fn.refreshSubusers();
                    $.fn.ParseAjax(data);
                });
            }
        });

        return false;
    });
    $(document).on("click", ".editsubuserlink", function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('href'),
            beforeSend: function() {
                $.fn.ajaxWindow();
            },
            success: function(html) {
                $.fn.ajaxWindow(false);
                if (html.replace(/^(\r\n)|(\n)/, '') === "0")
                {
                    $.fn.Alert(error, noservices);
                }
                else
                {
                    BootstrapDialog.show({
                        message: html,
                        title: editsubuser,
                        buttons: [
                            {
                                label: cancel,
                                action: function(dialogRef) {
                                    dialogRef.close();
                                }
                            },
                            {
                                icon: 'fa fa-save',
                                label: save,
                                action: function(dialogRef) {
                                    $(dialogRef.getModalBody()).find('form').ajaxSubmit(optionssubuser);
                                    dialogRef.close();
                                }
                            }
                        ]
                    });
                }
            },
            error: function(objAJAXRequest, strError) {
                $.fn.ajaxWindow(false);
                $.fn.Alert(error, errorsubuser);
            }
        });
        return false;
    });

});

// Iframe resize
function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.body.scrollHeight + 30 + 'px';
    obj.style.width = obj.contentWindow.document.body.scrollWidth + 30 + 'px';
}