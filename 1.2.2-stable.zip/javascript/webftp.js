$(document).on("click", "#webftp_load", function() {
    var url = $(this).attr('href');
    $("#ftp_info").hide();
    $.fn.ajaxWindow();
    $.ajax({
        url: url,
        success: function(data) {
            $.fn.ajaxWindow(false);
            var response = $('<div>' + data + '</div>');
            if ($(response).find('#error').text().length) {
                $('#ajax_error_text').html($(response).find('#error').text()).parent().show();
                $("#webftp_interface").hide();
                $("#ftp_info").show();
            }
            else {
                $("#ajax_error").hide();
                $("#webftp_interface").html(data).show();
                $.fn.CreateDatatable('#datatable');
            }
        },
        error: function(objAJAXRequest, strError) {
            $.fn.ajaxWindow(false);
            $("#webftp_interface").hide();
            $("#ftp_info").show();
            $('#ajax_error').html("{/literal}{$lang.errorftpconnect}{literal}").show();
        }
    });
    return false;
});

$(document).on("submit", "#actionform", function(e) {
    if ($('input[name=actionType]').val() == "get")
    {
        return true;
    }
    e.preventDefault();

    var postdata = $(this).serialize();
    $.ajax({
        type: 'POST',
        url: 'ftp.php',
        data: postdata,
        beforeSend: function()
        {
            $.fn.ajaxWindow();
        },
        success: function(data) {
            $.fn.ajaxWindow(false);
            if ($('input[name=actionType]').val() == "edit")
            {
                BootstrapDialog.show({
                    title: edit,
                    message: data,
                    height: '600px',
                    buttons: [{
                            label: 'Cancel',
                            action: function(dialogRef) {
                                dialogRef.close();
                            }
                        }, {
                            icon: 'fa fa-save',
                            label: 'Save',
                            action: function(dialogRef) {
                                $(dialogRef.getModalBody()).find('form').ajaxSubmit({
                                    beforeSubmit: function() {
                                        $.fn.ajaxWindow();
                                    },
                                    clearForm: true,
                                    resetForm: true,
                                    type: 'post',
                                    timeout: 30000,
                                    success: function(data) {
                                        $.fn.ajaxWindow(false);
                                        $.fn.ParseAjax(data);
                                    },
                                    error: function(objAJAXRequest, strError) {
                                        $.fn.ajaxWindow(false);
                                        $.fn.Alert("Error", "The operation timed out");
                                    }
                                });
                                dialogRef.close();
                            }
                        }]
                });
            }
            else if ($('input[name=actionType]').val() == "upload")
            {
                var response = $('<div>' + data + '</div>');
                if ($(response).find('#error').text().length) {
                    $('#ajax_error_text').html($(response).find('#error').text()).parent().show();
                }
                else {
                    $("#ajax_error").hide();
                    BootstrapDialog.show({
                        message: data,
                        height: '600px'
                    });
                }
            }
            else
            {
                var response = $('<div>' + data + '</div>');
                $('#webftp_interface').empty().html(data);
                $.fn.CreateDatatable('#datatable');
                if ($(response).find('#good').text().length) {
                    $('#ajax_good_text').html($(response).find('#good').text()).parent().show();
                }
                else {
                    $("#ajax_good").hide();
                }

                if ($(response).find('#error').text().length) {
                    $('#ajax_error_text').html($(response).find('#error').text()).parent().show();
                }
                else {
                    $("#ajax_error").hide();
                }
            }
            ;
        }
    });
});

$(document).on("click", "#webftp_createdir", function() {
    var r = window.prompt('Create Directory:', "");
    if (r !== null)
    {
        $('input[name=actionType]').val('createdir');
        $('input[name=file]').val(r);
        $("#actionform").submit();
    }
});

$(document).on("click", "#webftp_mode", function() {
    $('input[name=actionType]').val('changemode');
    $('input[name=mode]').val($(this).data("mode"));
    $("#actionform").submit();
});

$(document).on("click", "#webftp_close", function() {
    $("#webftp_interface").empty().hide();
    $("#ftp_info").show();
});

$(document).on("click", ".webftp_download", function() {
    $('input[name=file]').val($(this).closest("tr").data("filename"));
    $('input[name=actionType]').val('get');
    $("#actionform").submit();
});

$(document).on("click", ".webftp_delete", function() {
    var filename = $(this).closest("tr").data("filename");
    var action = $(this).closest("tr").data("delaction");
    BootstrapDialog.confirm("Are you sure you want to delete this file?", function(r) {
        if (r)
        {
            $('input[name=file]').val(filename);
            $('input[name=actionType]').val(action);
            $("#actionform").submit();
        }
    });
});

$(document).on("click", ".webftp_edit", function() {
    $('input[name=actionType]').val('edit');
    $('input[name=file]').val($(this).closest("tr").data("filename"));
    $("#actionform").submit();
});

$(document).on("click", ".webftp_rename", function() {
    var r = window.prompt('Rename ' + $(this).closest("tr").data("filename") + ' to:', $(this).closest("tr").data("filename"));
    if (r !== null)
    {
        $('input[name=actionType]').val('rename');
        $('input[name=file]').val($(this).closest("tr").data("filename"));
        $('input[name=file2]').val(r);
        $("#actionform").submit();
    }
});


$(document).on('dblclick', '#datatable tbody tr', function(e) {
    if ($(e.target).is('tr :not("a,i")')) {
        if ($(this).data("action") === "cdup")
        {
            $('input[name=actionType]').val('cd');
            $('input[name=file]').val('..');
        }
        else
        {
            $('input[name=file]').val($(this).closest("tr").data("filename"));
            $('input[name=actionType]').val($(this).data("action"));
        }
        $("#actionform").submit();
    }
});







/*
 * Edit file
 */
$(document).on("submit", "#editFileForm", function(e) {
    e.preventDefault();
    $(this).ajaxSubmit({
        beforeSubmit: function() {
            $.fn.ajaxWindow();
        },
        clearForm: true,
        resetForm: true,
        type: 'post',
        timeout: 30000,
        success: function(data) {
            $.fn.ajaxWindow(false);

            $.fn.ParseAjax(data);
        },
        error: function(objAJAXRequest, strError) {
            $.fn.ajaxWindow(false);
            $('#ajax_error_text').html("{/literal}{$lang.unablelogin}{literal}").parent().show();
        }
    });
});