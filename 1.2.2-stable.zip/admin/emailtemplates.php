<?php
require_once("../includes/gsp-panel.php");

use GSPPanel\Emails;

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || $_REQUEST['mode'] == "delete")
    {
        die("This feature is disabled in demo mode");
    }
}

// Permission checks for sub-admins
if($_SESSION['mainadmin'] != "1")
{
    if(!in_array("emailtemplates", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
}
//print_r($_REQUEST);
//die();
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    /*
     * Save edit
     */
    if($_REQUEST['mode'] == "edit")
    {
        $params = array('subject' => $_REQUEST['subject'],
                'content' => $_REQUEST['content'],
                'templateid' => $_REQUEST['tid']);

        $results = Emails::EditTemplate($params);
        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['templatesaved'];
            header("Location: emailtemplates.php");
            exit();
        }
        elseif($results['error'] == -1)
        {
            $error = $lang['notemplateid'];
        }
        elseif($results['error'] == -2)
        {
            $error = $lang['missinginformation'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
    /*
     * Save Add
     */
    elseif($_REQUEST['mode'] == "add")
    {
        $params = array('subject' => $_REQUEST['subject'],
                'content' => $_REQUEST['content']);

        $results = Emails::AddTemplate($params);
        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['templatesaved'];
            header("Location: emailtemplates.php");
            exit();
        }
        elseif($results['error'] == -1)
        {
            $error = $lang['missinginformation'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
}
if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['manageemailtemplate'];

    $display->templates = Emails::ListTemplate();

    $display->DisplayType("admin");
    $display->Output("admin/configuration/emailtemplates-list.tpl");
}
elseif($_REQUEST['mode'] == "edit")
{
    $display->pagename = $lang['editemailtemplate'];
    
    $info = Emails::GetTemplate($_REQUEST['tid']);
    if($info  && count($info) > 0)
    {
        $display->DisplayType("admin");
        $display->info = $info;
        $display->Output("admin/configuration/emailtemplates-add.tpl");
    }
    else
    {
        $_SESSION['errormessage'] = $lang['templatenotfound'];
        header("Location: index.php");
    }
}
elseif($_REQUEST['mode'] == "add")
{
    $display->pagename = $lang['addemailtemplate'];
    $display->DisplayType("admin");
    $display->Output("admin/configuration/emailtemplates-add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    $params = array("templateid" => $_REQUEST['tid']);
    $results = Emails::DeleteTemplate($params);

    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['templateremoved'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['notemplateid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['templatenotfound'];
    }
    header("Location: emailtemplates.php");
    exit();
}
?>