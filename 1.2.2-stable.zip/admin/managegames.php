<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{Machines, GSP, Games, SafeSQL, Plugins};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delete", "deloption", "delconfig", "delscript", "deladdon", "delupdate", "export", "import")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1" && !in_array("managegames", $_SESSION['permissions']))
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}


if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    /*
     * Edit
     */
    if($_REQUEST['mode'] == "edit")
    {
        if(isset($_REQUEST['alertdiskusage']) && !empty($_REQUEST['alertdiskusage']))
        {
            switch($_REQUEST['alertdiskusage2'])
            {
                case "bytes":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'];
                    break;
                case "KB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024;
                    break;
                case "MB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024 * 1024;
                    break;
                case "GB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024 * 1024 * 1024;
                    break;
                case "TB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024 * 1024 * 1024 * 1024;
                    break;
            }
        }
        $params = array('gamename' => $_REQUEST['gamename'],
            'linux_enable' => $_REQUEST['linux_enable'],
            'windows_enable' => $_REQUEST['windows_enable'],
            'querycode' => $_REQUEST['querycode'],
            'files_path' => $_REQUEST['filepath'],
            'port_increment' => $_REQUEST['port_increment'],
            'port_default' => $_REQUEST['port_default'],
            'port_querydefault' => $_REQUEST['port_querydefault'],
            'port_rcondefault' => $_REQUEST['port_rcondefault'],
            'port_custom1' => $_REQUEST['port_custom1'],
            'port_custom2' => $_REQUEST['port_custom2'],
            'port_custom3' => $_REQUEST['port_custom3'],
            'port_custom4' => $_REQUEST['port_custom4'],
            'reinstall_enable' => $_REQUEST['reinstall_enable'],
            'linux_startmode' => $_REQUEST['linux_startmode'],
            'linux_installtype' => $_REQUEST['linux_installtype'],
            'linux_logfile' => $_REQUEST['linux_logfile'],
            'windows_startmode' => $_REQUEST['windows_startmode'],
            'windows_installtype' => $_REQUEST['windows_installtype'],
            'windows_exec' => $_REQUEST['windows_exec'],
            'windows_workingpath' => $_REQUEST['windows_workingpath'],
            'windows_logfile' => $_REQUEST['windows_logfile'],
            'ftp' => $_REQUEST['ftp'],
            'servermon' => $_REQUEST['servermon'],
            'graphs' => $_REQUEST['graphs'],
            'windows_console' => $_REQUEST['windows_console'],
            'configoptions' => $_REQUEST['configoption'],
            'maxslots' => $_REQUEST['maxslots'],
            'redirectfolder' => $_REQUEST['redirectfolder'],
            'gid' => $_REQUEST['gid'],
            'consolekillcommand' => $_REQUEST['consolekillcommand'],
            'fastdl' => $_REQUEST['fastdl'],
            'fastdlurl' => $_REQUEST['fastdlurl'],
            'fastdlallowed' => $_REQUEST['fastdlallowed'],
            'fastdlexclude' => $_REQUEST['fastdlexclude'],
            'rconprotocol' => $_REQUEST['rconprotocol'],
            'alertdiskusage' => $_REQUEST['alertdiskusage'],
            'backups' => $_REQUEST['backups'],
            'backupclientaccess' => $_REQUEST['backupclientaccess'],
            'backuplimit' => $_REQUEST['backuplimit'],
            'addonmanager' => $_REQUEST['addonmanager'],
            'servermon_offline_1' => $_REQUEST['servermon_offline_1'],
            'servermon_offline_2' => $_REQUEST['servermon_offline_2'],
            'servermon_offline_3' => $_REQUEST['servermon_offline_3'],
            'servermon_private_1' => $_REQUEST['servermon_private_1'],
            'servermon_private_2' => $_REQUEST['servermon_private_2'],
            'servermon_private_3' => $_REQUEST['servermon_private_3'],
            'servermon_slots_1' => $_REQUEST['servermon_slots_1'],
            'servermon_slots_2' => $_REQUEST['servermon_slots_2'],
            'servermon_slots_3' => $_REQUEST['servermon_slots_3'],
            'servermon_cpulimit' => $_REQUEST['servermon_cpulimit'],
            'servermon_cpu_1' => $_REQUEST['servermon_cpu_1'],
            'servermon_cpu_2' => $_REQUEST['servermon_cpu_2'],
            'servermon_cpu_3' => $_REQUEST['servermon_cpu_3'],
            'servermon_ramlimit' => $_REQUEST['servermon_ramlimit'],
            'servermon_ram_1' => $_REQUEST['servermon_ram_1'],
            'servermon_ram_2' => $_REQUEST['servermon_ram_2'],
            'servermon_ram_3' => $_REQUEST['servermon_ram_3'],
            'database_allowed' => $_REQUEST['database_allowed'],
            'database_autocreate' => $_REQUEST['database_autocreate'],
            'database_adminurl' => $_REQUEST['database_adminurl'],
            'database_limit' => $_REQUEST['database_limit']);
        $result = Games::EditGame($params);

        if($result['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['gamesaved'];
            header("Location: managegames.php");
            exit();
        }
        elseif($result['error'] == -1)
        {
            $error[] = $lang['nogameid'];
        }
        elseif($result['error'] == -2)
        {
            $error[] = $lang['missinginformation'];
        }
        elseif($result['error'] == -3)
        {
            $error[] = $lang['gamelinuxstartmodeempty'];
        }
        elseif($result['error'] == -4)
        {
            $error[] = $lang['gamewindowsstartmodeempty'];
        }
        elseif($result['error'] == -5)
        {
            $error[] = $lang['selectos'];
        }

        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
    /*
     * Add
     */
    elseif($_REQUEST['mode'] == "add")
    {
        if(isset($_REQUEST['alertdiskusage']) && !empty($_REQUEST['alertdiskusage']))
        {
            switch($_REQUEST['alertdiskusage2'])
            {
                case "bytes":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'];
                    break;
                case "KB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024;
                    break;
                case "MB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024 * 1024;
                    break;
                case "GB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024 * 1024 * 1024;
                    break;
                case "TB":
                    $_REQUEST['alertdiskusage'] = $_REQUEST['alertdiskusage'] * 1024 * 1024 * 1024 * 1024;
                    break;
            }
        }

        $params = array('gamename' => $_REQUEST['gamename'],
            'linux_enable' => $_REQUEST['linux_enable'],
            'windows_enable' => $_REQUEST['windows_enable'],
            'querycode' => $_REQUEST['querycode'],
            'files_path' => $_REQUEST['filepath'],
            'port_increment' => $_REQUEST['port_increment'],
            'port_default' => $_REQUEST['port_default'],
            'port_querydefault' => $_REQUEST['port_querydefault'],
            'port_rcondefault' => $_REQUEST['port_rcondefault'],
            'port_custom1' => $_REQUEST['port_custom1'],
            'port_custom2' => $_REQUEST['port_custom2'],
            'port_custom3' => $_REQUEST['port_custom3'],
            'port_custom4' => $_REQUEST['port_custom4'],
            'reinstall_enable' => $_REQUEST['reinstall_enable'],
            'linux_startmode' => $_REQUEST['linux_startmode'],
            'linux_installtype' => $_REQUEST['linux_installtype'],
            'linux_logfile' => $_REQUEST['linux_logfile'],
            'configoptions' => $_REQUEST['configoption'],
            'maxslots' => $_REQUEST['maxslots'],
            'windows_exec' => $_REQUEST['windows_exec'],
            'windows_workingpath' => $_REQUEST['windows_workingpath'],
            'windows_logfile' => $_REQUEST['windows_logfile'],
            'ftp' => $_REQUEST['ftp'],
            'servermon' => $_REQUEST['servermon'],
            'graphs' => $_REQUEST['graphs'],
            'windows_console' => $_REQUEST['windows_console'],
            'windows_startmode' => $_REQUEST['windows_startmode'],
            'windows_installtype' => $_REQUEST['windows_installtype'],
            'redirectfolder' => $_REQUEST['redirectfolder'],
            'consolekillcommand' => $_REQUEST['consolekillcommand'],
            'fastdl' => $_REQUEST['fastdl'],
            'fastdlurl' => $_REQUEST['fastdlurl'],
            'fastdlallowed' => $_REQUEST['fastdlallowed'],
            'fastdlexclude' => $_REQUEST['fastdlexclude'],
            'rconprotocol' => $_REQUEST['rconprotocol'],
            'alertdiskusage' => $_REQUEST['alertdiskusage'],
            'backups' => $_REQUEST['backups'],
            'backupclientaccess' => $_REQUEST['backupclientaccess'],
            'backuplimit' => $_REQUEST['backuplimit'],
            'addonmanager' => $_REQUEST['addonmanager'],
            'servermon_offline_1' => $_REQUEST['servermon_offline_1'],
            'servermon_offline_2' => $_REQUEST['servermon_offline_2'],
            'servermon_offline_3' => $_REQUEST['servermon_offline_3'],
            'servermon_private_1' => $_REQUEST['servermon_private_1'],
            'servermon_private_2' => $_REQUEST['servermon_private_2'],
            'servermon_private_3' => $_REQUEST['servermon_private_3'],
            'servermon_slots_1' => $_REQUEST['servermon_slots_1'],
            'servermon_slots_2' => $_REQUEST['servermon_slots_2'],
            'servermon_slots_3' => $_REQUEST['servermon_slots_3'],
            'servermon_cpulimit' => $_REQUEST['servermon_cpulimit'],
            'servermon_cpu_1' => $_REQUEST['servermon_cpu_1'],
            'servermon_cpu_2' => $_REQUEST['servermon_cpu_2'],
            'servermon_cpu_3' => $_REQUEST['servermon_cpu_3'],
            'servermon_ramlimit' => $_REQUEST['servermon_ramlimit'],
            'servermon_ram_1' => $_REQUEST['servermon_ram_1'],
            'servermon_ram_2' => $_REQUEST['servermon_ram_2'],
            'servermon_ram_3' => $_REQUEST['servermon_ram_3'],
            'database_allowed' => $_REQUEST['database_allowed'],
            'database_autocreate' => $_REQUEST['database_autocreate'],
            'database_adminurl' => $_REQUEST['database_adminurl'],
            'database_limit' => $_REQUEST['database_limit']);
        $result = Games::AddGame($params);

        if($result['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['gamesaved'];
            header("Location: managegames.php");
            exit();
        }
        elseif($result['error'] == -1)
        {
            $error[] = $lang['missinginformation'];
        }
        elseif($result['error'] == -2)
        {
            $error[] = $lang['gamelinuxstartmodeempty'];
        }
        elseif($result['error'] == -3)
        {
            $error[] = $lang['gamewindowsstartmodeempty'];
        }
        elseif($result['error'] == -4)
        {
            $error[] = $lang['selectos'];
        }

        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
    elseif($_REQUEST['mode'] == "saveconfig")
    {
        if(!empty($_REQUEST['configid']))
        {
            $return = Games::EditGameConfig(array("filename" => $_REQUEST['filename'], "directory" => $_REQUEST['directory'], "content" => $_REQUEST['content'], "rewrite" => $_REQUEST['rewrite'], "quickedit" => $_REQUEST['quickedit'], "install" => $_REQUEST['install'], "configid" => $_REQUEST['configid']));
        }
        else
        {
            $return = Games::AddGameConfig(array("filename" => $_REQUEST['filename'], "directory" => $_REQUEST['directory'], "content" => $_REQUEST['content'], "rewrite" => $_REQUEST['rewrite'], "quickedit" => $_REQUEST['quickedit'], "install" => $_REQUEST['install'], "gid" => $_REQUEST['gid']));
        }

        if($return['error'] == -1)
        {
            echo '<div id="error">'.$lang['nofilename'].'</div>';
            exit();
        }
    }
    elseif($_REQUEST['mode'] == "savescript")
    {
        if(!empty($_REQUEST['scriptid']))
        {
            $return = Games::EditGameScript(array("description" => $_REQUEST['description'], "os" => $_REQUEST['os'], "content" => $_REQUEST['content'], "event" => $_REQUEST['event'], "wait" => $_REQUEST['wait'], "scriptid" => $_REQUEST['scriptid']));
        }
        else
        {
            $return = Games::AddGameScript(array("description" => $_REQUEST['description'], "os" => $_REQUEST['os'], "content" => $_REQUEST['content'], "event" => $_REQUEST['event'], "wait" => $_REQUEST['wait'], "gid" => $_REQUEST['gid']));
        }

        if($return['error'] == -1)
        {
            echo '<div id="error">'.$lang['nocontent'].'</div>';
            exit();
        }
    }
    elseif($_REQUEST['mode'] == "saveaddon")
    {
        if(!empty($_REQUEST['addonid']))
        {
            $return = Games::EditGameAddon(array("name" => $_REQUEST['name'], "copyfolder" => $_REQUEST['copyfolder'], "windows_path" => $_REQUEST['windows_path'], "linux_path" => $_REQUEST['linux_path'],
                        "systemcommands" => $_REQUEST['systemcommands'], "windows_command" => $_REQUEST['windows_command'], "linux_command" => $_REQUEST['linux_command'], "userinstall" => $_REQUEST['userinstall'],
                        "message" => $_REQUEST['message'], "description" => $_REQUEST['description'], "restart" => $_REQUEST['restart'], "addonid" => $_REQUEST['addonid']));
        }
        else
        {
            $return = Games::AddGameAddon(array("name" => $_REQUEST['name'], "copyfolder" => $_REQUEST['copyfolder'], "windows_path" => $_REQUEST['windows_path'], "linux_path" => $_REQUEST['linux_path'],
                        "systemcommands" => $_REQUEST['systemcommands'], "windows_command" => $_REQUEST['windows_command'], "linux_command" => $_REQUEST['linux_command'], "userinstall" => $_REQUEST['userinstall'],
                        "message" => $_REQUEST['message'], "description" => $_REQUEST['description'], "restart" => $_REQUEST['restart'], "gid" => $_REQUEST['gid']));
        }
        if($return['error'] == -1)
        {
            echo '<div id="error">'.$lang['noaddonname'].'</div>';
            exit();
        }
    }
    elseif($_REQUEST['mode'] == "saveupdate")
    {
        if(!empty($_REQUEST['updateid']))
        {
            $return = Games::EditGameUpdate(array("name" => $_REQUEST['name'], "copyfolder" => $_REQUEST['copyfolder'], "windows_path" => $_REQUEST['windows_path'], "linux_path" => $_REQUEST['linux_path'],
                        "systemcommands" => $_REQUEST['systemcommands'], "windows_command" => $_REQUEST['windows_command'], "linux_command" => $_REQUEST['linux_command'], "userinstall" => $_REQUEST['userinstall'],
                        "message" => $_REQUEST['message'], "description" => $_REQUEST['description'], "updateid" => $_REQUEST['updateid']));
        }
        else
        {
            $return = Games::AddGameUpdate(array("name" => $_REQUEST['name'], "copyfolder" => $_REQUEST['copyfolder'], "windows_path" => $_REQUEST['windows_path'], "linux_path" => $_REQUEST['linux_path'],
                        "systemcommands" => $_REQUEST['systemcommands'], "windows_command" => $_REQUEST['windows_command'], "linux_command" => $_REQUEST['linux_command'], "userinstall" => $_REQUEST['userinstall'],
                        "message" => $_REQUEST['message'], "description" => $_REQUEST['description'], "gid" => $_REQUEST['gid']));
        }

        if($return['error'] == -1)
        {
            echo '<div id="error">'.$lang['noupdatename'].'</div>';
            exit();
        }
    }
    elseif($_REQUEST['mode'] == "import")
    {
        if(file_exists($_FILES['importfile']['tmp_name']))
        {
            $file = $_FILES['importfile']['tmp_name'];

            if(!($fp = fopen($file, "r")))
            {
                die("could not open file");
            }

            $data = fread($fp, filesize($file));
            fclose($fp);
            unlink($file);

            $result = Games::Import($data);
            if($result['error'] == 0)
            {
                $_SESSION['goodmessage'] = $lang['gameimported'];
                header("Location: managegames.php");
            }
            elseif($result['error'] == -1)
            {
                $display->errormessage = $lang['nodatareceived'];
            }
            elseif($result['error'] == -2)
            {
                $display->errormessage = $lang['missinginformation'];
            }
            elseif($result['error'] == -3)
            {
                $display->errormessage = $lang['gamelinuxstartmodeempty'];
            }
            elseif($result['error'] == -4)
            {
                $display->errormessage = $lang['gamewindowsstartmodeempty'];
            }
            elseif($result['error'] == -5)
            {
                $display->errormessage = $lang['selectos'];
            }
        }
        else
        {
            $display->errormessage = $lang['erroruploading'];
        }
    }
}
if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['gametemplates'];
    $display->DisplayType("admin");

    $gamelist = Games::ListGames();
    foreach($gamelist as $k => $v)
    {
        if($v['linux_enable'] == "1")
        {
            $gamelist[$k]['os'] = "Linux";
        }
        if($v['windows_enable'] == "1")
        {
            if(!empty($gamelist[$k]['os']))
            {
                $gamelist[$k]['os'] .= " & ";
            }
            $gamelist[$k]['os'] .= "Windows";
        }
    }
    $display->games = $gamelist;

    $display->Output("admin/configuration/managegames-list.tpl");
}
elseif($_REQUEST['mode'] == "edit")
{
    $display->gamequery = Games::ListProtocols();

    $display->pagename = $lang['editgame'];

    $info = Games::GetGameInfo($_REQUEST['gid']);
    if($info && count($info) > 0)
    {
        $display->updates = $info['updates'];
        $display->scripts = $info['scripts'];
        $display->configs = $info['configs'];
        $display->configoptions = $info['configoptions'];
        $display->maxslots = $info['maxslots'];
        $display->info = $info['info'];
        
        $display->addonmanagers = Plugins::getInstance()->listEnabled("addon_manager");
        
        $display->DisplayType("admin");
        $display->Output("admin/configuration/managegames-add.tpl");
    }
    else
    {
        $_SESSION['errormessage'] = $lang['gamenotfound'];
        header("Location: index.php");
    }
}
elseif($_REQUEST['mode'] == "add")
{
    $display->gamequery = Games::ListProtocols();
    $display->addonmanagers = Plugins::getInstance()->listEnabled("addon_manager");

    $display->pagename = $lang['addgame'];

    $display->DisplayType("admin");
    $display->Output("admin/configuration/managegames-add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    $return = Games::DeleteGame($_REQUEST['gid']);
    if($return['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['gameremoved'];
    }
    elseif($return['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($return['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamedeleteerror'];
    }
    header("Location: managegames.php");
    exit();
}
elseif($_REQUEST['mode'] == "verify")
{
    $return = Games::CheckMachines(array("gid" => $_REQUEST['gid']));
    if($return['error'] == -1)
    {
        $_SESSION['error'] = $lang['nogameid'];
        header("Location: managegames.php");
    }
    else
    {
        $display->serverlist = $return;
        $display->DisplayType("ajax");
        $display->Output("admin/configuration/ajax-verifygames.tpl");
    }
}
elseif($_REQUEST['mode'] == "deloption")
{
    Games::DeleteConfigurableOption($_GET['gid'], $_GET['optionid']);
    header("Location: managegames.php?mode=edit&gid=".$_REQUEST['gid']."#tab_configoptions");
    exit();
}
elseif($_REQUEST['mode'] == "delconfig")
{
    Games::DeleteConfig($_GET['gid'], $_GET['configid']);
    exit();
}
elseif($_REQUEST['mode'] == "delscript")
{
    Games::DeleteScript($_GET['gid'], $_GET['scriptid']);
    exit();
}
elseif($_REQUEST['mode'] == "editconfig")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_configs` WHERE cfid=%i LIMIT 1", array($_REQUEST['configid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $display->config = $row;
    }
    $display->configid = $_REQUEST['configid'];
    $display->DisplayType("ajax");
    $display->Output("admin/configuration/ajax-editconfig.tpl");
}
elseif($_REQUEST['mode'] == "configlist")
{
    $configs = Games::ListConfigs($_REQUEST['gid']);

    $display->configs = $configs;
    $display->DisplayType("ajax");
    $display->Output("admin/configuration/ajax-configlist.tpl");
}
elseif($_REQUEST['mode'] == "editscript")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_scripts` WHERE id=%i LIMIT 1", array($_REQUEST['scriptid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $display->script = $row;
    }
    $display->configid = $_REQUEST['configid'];
    $display->DisplayType("ajax");
    $display->Output("admin/configuration/ajax-editscript.tpl");
}
elseif($_REQUEST['mode'] == "scriptlist")
{
    $display->scripts = Games::ListScripts($_REQUEST['gid']);

    $display->DisplayType("ajax");
    $display->Output("admin/configuration/ajax-scriptlist.tpl");
}
elseif($_REQUEST['mode'] == "deladdon")
{
    Games::DeleteAddon($_GET['gid'], $_GET['addonid']);
    header("Location: managegames.php?mode=edit&gid=".$_REQUEST['gid']."#tab_addons");
    exit();
}
elseif($_REQUEST['mode'] == "editaddon")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_addons` WHERE addonid=%i LIMIT 1", array($_REQUEST['addonid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $display->addon = $row;
    }
    $display->addonid = $_REQUEST['addonid'];
    $display->DisplayType("ajax");
    $display->Output("admin/configuration/ajax-editaddon.tpl");
}
elseif($_REQUEST['mode'] == "addonlist")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT gid, addonmanager FROM `games` WHERE `gid`=%i LIMIT 1", array($_REQUEST['gid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        if(!empty($row['addonmanager']) && $row['addonmanager'] != "stock")
        {
            Plugins::getInstance()->triggerPluginEvent($row['addonmanager'], "displayaddonmanager", $row['gid']);
        }
        else
        {
            $display->addons = Games::ListAddons($_REQUEST['gid']);

            $display->DisplayType("ajax");
            $display->Output("admin/configuration/ajax-addonlist.tpl");
        }
    }
}
elseif($_REQUEST['mode'] == "delupdate")
{
    Games::DeleteUpdate($_GET['gid'], $_GET['updateid']);
    header("Location: managegames.php?mode=edit&gid=".$_REQUEST['gid']."#tab_updates");
    exit();
}
elseif($_REQUEST['mode'] == "editupdate")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_updates` WHERE updateid=%i LIMIT 1", array($_REQUEST['updateid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $display->update = $row;
    }
    $display->updateid = $_REQUEST['updateid'];
    $display->DisplayType("ajax");
    $display->Output("admin/configuration/ajax-editupdate.tpl");
}
elseif($_REQUEST['mode'] == "updatelist")
{
    $display->updates = Games::ListUpdates($_REQUEST['gid']);

    $display->DisplayType("ajax");
    $display->Output("admin/configuration/ajax-updatelist.tpl");
}
elseif($_REQUEST['mode'] == "export")
{
    header('Content-type: application/txt');
    header('Content-Disposition: attachment; filename="GSPPanel Game Template.txt"');
    echo Games::ExportGameTemplate($_REQUEST['gid'], "xml");
    exit();
}
elseif($_REQUEST['mode'] == "import")
{
    if(!isset($_REQUEST['id']) || empty($_REQUEST['id']))
    {
        $results = Games::Import_GSPList();
        if($results['error'] == "0")
        {
            foreach($results['list'] as $k => $v)
            {
                if($v['hastemplate'] == "1")
                {
                    $display->gamelist[$k] = $v;
                }
            }
        }

        $display->pagename = $lang['importgame'];
        $display->DisplayType("admin");
        $display->Output("admin/configuration/managegames-import.tpl");
    }
    else
    {
        $results = Games::Import_GSP($_REQUEST['id']);
        if($results['error'] != 0)
        {
            $_SESSION['errormessage'] = $lang['import_error'];
        }
        else
        {
            $results = Games::Import_GSPList($_REQUEST['id']);
            if($results['error'] == 0)
            {
                $winmachines = count(Machines::ListMachines(array("os" => "1", "gameserver" => "1")));
                $linmachines = count(Machines::ListMachines(array("os" => "0", "gameserver" => "1")));
                if(($results['list']['windows'] == "1" && $winmachines > 0) || ($results['list']['linux'] == "1" && $linmachines > 0))
                {
                    header("Location: utility.php?module=gameinstaller&mode=selectmachine&redir=1&id=".$_REQUEST['id']);
                    exit();
                }
            }
        }
        header("Location: managegames.php");
        exit();
    }
}
?>