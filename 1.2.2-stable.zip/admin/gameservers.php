<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{GSP, Machines, Games, SafeSQL};

if($_SESSION['mainadmin'] != "1" && (!in_array("addservice", $_SESSION['permissions']) && !in_array("editservice", $_SESSION['permissions']) && !in_array("deleteservice", $_SESSION['permissions']) && !in_array("suspendservice", $_SESSION['permissions']) && !in_array("manageservice", $_SESSION['permissions'])))
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['gameservers'];
    $display->DisplayType("admin");

    $display->machines = Machines::ListMachines();
    $display->games = Games::ListGames();

    $display->Output("admin/gameservers/gameservers-list.tpl");
}
elseif($_REQUEST['mode'] == "pagination")
{
    $limit = $_REQUEST['length'];

    $sid = $_REQUEST['columns'][0]['search']['value'];
    $gid = $_REQUEST['columns'][1]['search']['value'];
    $ip = $_REQUEST['columns'][2]['search']['value'];

    $totalall_rows = count(Games::ListGameServers());
    $total_rows = count(Games::ListGameServers(array("sid" => $sid, "gid" => $gid, "ip" => $ip)));
    $gameservers = Games::ListGameServers(array("sid" => $sid, "gid" => $gid, "ip" => $ip, "limit" => ($_REQUEST['start']).",".$limit));

    $json = array();
    $json['draw'] = $_REQUEST['draw'];
    $json['recordsTotal'] = $totalall_rows;
    $json['recordsFiltered'] = $total_rows;
    $json['data'] = array();
    foreach($gameservers as $k => $v)
    {
        $installstatus = null;
        if($v['installed'] == 1)
        {
            if($v['task'] == "") $installstatus = $lang['yesstr'];
            elseif($v['task'] == "gameupdate") $installstatus = $lang['updating'];
            elseif($v['task'] == "installing") $installstatus = $lang['installing'];
            elseif($v['task'] == "moving") $installstatus = $lang['moving'];
            elseif($v['task'] == "backup") $installstatus = $lang['backingup'];
        }
        else
        {
            if($v['task'] == "installing") $installstatus = $lang['installing'];
            elseif($v['task'] == "downloading") $installstatus = $lang['downloading'];
            else
            {
                if(in_array("addservice", $_SESSION['permissions']))
                {
                    $installstatus = '<a ref="'.$v['ugid'].'" class="installgame" data-url="manageusergames.php?mode=installgame&ugid='.$v['ugid'].'">'.$lang['nostr'].'</a>';
                }
                else
                {
                    $installstatus = $lang['nostr'];
                }
            }
        }

        $unlockurl = null;
        if($v['locked'] == 1)
        {
            $unlockurl = '<a href="manageusergames.php?mode=unlock&ugid='.$v['ugid'].'" class="unlockgame btn btn-sm btn-secondary"><i class="fa fa-unlock"></i></a>';
        }

        $json['data'][] = array($v['ugid'], '<div class="status_'.$v['ugid'].'"><img src="../templates/'.$gsp->settings['template'].'/images/ajax-loader-round.gif" /></div>', '<div class="players_'.$v['ugid'].'"><img src="../templates/'.$gsp->settings['template'].'/images/ajax-loader-round.gif" /></div>', '<div class="hostname_'.$v['ugid'].'"><img src="../templates/'.$gsp->settings['template'].'/images/ajax-loader-round.gif" /></div>', $v['name'], $v['ip'].":".$v['port_main'], '<div class="installgameq_'.$v['ugid'].'" style="text-align:center; vertical-align:middle;">'.$installstatus.'</div>', '<a class="btn btn-secondary btn-sm" href="manageusergames.php?mode=managegame&ugid='.$v['ugid'].'">'.$lang['manage'].'</a>'.$unlockurl);
    }

    echo json_encode($json);
}
elseif($_REQUEST['mode'] == "serverinfo")
{
    // Image variables
    $online = '<div class="online"></div>';
    $offline = '<div class="offline"></div>';

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `ugid`='%i' LIMIT 1", array($_REQUEST['ugid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        if($row['status'] == 1)
        {
            $params = array('ugid' => $row['ugid'],
                'nomap' => true);
            $results = Games::QueryGame($params);
            if($results['error'] == 0)
            {
                if($results['status'] == 1)
                {
                    echo '<div id="status">'.$online.'</div>';
                    echo '<div id="players">'.$results['active']."/".$results['total'].'</div>';
                    if(strlen($results['hostname']) > 30)
                    {
                        $results['hostname'] = substr($results['hostname'], 0, 27)."...";
                    }
                    echo '<div id="hostname">'.$results['hostname'].'</div>';
                    exit();
                }
            }
        }
    }
    echo '<div id="status">'.$offline.'</div>';
    echo '<div id="players">'."N/A".'</div>';
    echo '<div id="hostname">'."N/A".'</div>';
    exit();
}
?>