<?php

use GSPPanel\{GSP, SafeSQL};

$display->pagename = $lang['reports'];


if(empty($_REQUEST['type']) && !isset($_REQUEST['type']))
{
    $display->DisplayType("admin");
    $display->Output("admin/utilities/reports/list.tpl");
}
elseif($_REQUEST['type'] == "games")
{
    $gamelist = array();
    $x = 0;
    $query = GSP::getInstance()->db->query("SELECT * FROM `games`");
    while($row = $query->fetch_assoc())
    {
        $querygame = GSP::getInstance()->db->query("SELECT 
                    (SELECT COUNT(*) FROM `usergames` WHERE `status`='0' AND `gid`='".$row['gid']."') as 'offline',
                    (SELECT COUNT(*) FROM `usergames` WHERE `status`='1' AND `gid`='".$row['gid']."') as 'online',
                    (SELECT COUNT(*) FROM `usergames` WHERE `status`='2' AND `gid`='".$row['gid']."') as 'suspended'");
        if($querygame)
        {
            $rowstats = $querygame->fetch_assoc();
            $gamelist[$x]['name'] = $row['name'];
            $gamelist[$x]['offline'] = $rowstats['offline'];
            $gamelist[$x]['online'] = $rowstats['online'];
            $gamelist[$x]['suspended'] = $rowstats['suspended'];
        }
        $x++;
    }

    $display->gamelist = $gamelist;
    $display->Output("admin/utilities/reports/games.tpl");
    exit();
}
elseif($_REQUEST['type'] == "ips")
{
    $machinelist = array();
    $x = 0;
    $query = GSP::getInstance()->db->query("SELECT * FROM `machines` WHERE `game_server`='1'");
    while($row = $query->fetch_assoc())
    {
        // Select all IPs
        $queryips = GSP::getInstance()->db->query("SELECT * FROM `iplist` WHERE `sid`='".$row['id']."'");
        while($rowips = $queryips->fetch_assoc())
        {
            $querygame = GSP::getInstance()->db->query("SELECT 
                (SELECT COUNT(*) FROM `usergames` WHERE `ipid`='".$rowips['ipid']."') as 'gameservers'");
            if($querygame)
            {
                $rowstats = $querygame->fetch_assoc();
                $machinelist[$x]['alias'] = $row['alias'];
                $machinelist[$x]['ips'][$rowips['ip']] = $rowstats;
            }
        }
        $x++;
    }

    $display->ips = $machinelist;
    $display->Output("admin/utilities/reports/ips.tpl");
    exit();
}
?>
