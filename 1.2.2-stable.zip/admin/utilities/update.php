<?php

use GSPPanel\{GSP};

if(defined("DEMO"))
{
    die("This feature is disabled in demo mode");
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if($_REQUEST['mode'] == "process")
{
    $results = GSP::getInstance()->Update();
    if($results['error'] == 0)
    {
        echo $lang['updatesuccessful'];
    }
    elseif($results['error'] == -1)
    {
        echo $lang['nophpzip'];
    }
    elseif($results['error'] == -2)
    {
        echo $lang['pathnotwritable'];
    }
    elseif($results['error'] == -3)
    {
        echo $lang['cannotfindzip'];
    }
    elseif($results['error'] == -4)
    {
        echo $lang['unknownerror'];
    }
    elseif($results['error'] == -5)
    {
        echo $lang['errordownload'].", ".$results['message'];
    }
    elseif($results['error'] == -6)
    {
        echo $results['message'];
    }
    exit;
}

$display->pagename = $lang['update'];

$display->DisplayType("admin");
$display->Output("admin/utilities/update.tpl");
?>
