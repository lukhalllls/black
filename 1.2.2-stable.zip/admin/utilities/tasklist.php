<?php

use GSPPanel\{GSP, SafeSQL, Games};

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("del")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

// Delete old 'finished' tasks in the tasklist
$timetodelete = time() - 172800; // Two days
GSP::getInstance()->db->query("DELETE FROM `tasklist` WHERE `datefinished`!='' AND `dateposted` < ".$timetodelete);

if(isset($_REQUEST['mode']))
{    
    if($_REQUEST['mode'] == "del" && !empty($_REQUEST['task']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `tasklist` WHERE `taskid`=%i LIMIT 1", array($_REQUEST['task'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            if($row['type'] == "installusergameupdate" || $row['type'] == "installusergame")
            {
                Games::UnlockGame($row['ugid']);
            }
            GSP::getInstance()->db->query(SafeSQL::query("DELETE FROM `tasklist` WHERE `taskid`=%i LIMIT 1", array($_REQUEST['task'])));
            $_SESSION['good'] = $lang['taskdeleted'];
        }
        header("Location: utility.php?module=tasklist");
    }
}

$query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `tasklist` WHERE `type`!='downloadfile' AND `type`!='getusergamesize' ORDER BY `taskid` DESC", array()));
if($query && $query->num_rows > 0)
{
    $tasks = array();
    $x = 0;
    while($row = $query->fetch_assoc())
    {
        $tasks[$x] = $row;
        $queryuser = GSP::getInstance()->db->query(SafeSQL::query("SELECT users.uid,email FROM `users` JOIN `usergames` ON usergames.uid=users.uid WHERE usergames.ugid='%i' LIMIT 1", array($row['ugid'])));
        $rowuser = $queryuser->fetch_assoc();
        $tasks[$x]['email'] = $rowuser['email'];
        $tasks[$x]['uid'] = $rowuser['uid'];
        $x++;
    }
    $display->tasks = $tasks;
}

$display->pagename = $lang['tasklist'];

$display->DisplayType("admin");
$display->Output("admin/utilities/tasklist.tpl");
?>