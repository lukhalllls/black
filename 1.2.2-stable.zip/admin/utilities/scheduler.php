<?php

use GSPPanel\{GSP, Cron};

if(defined("DEMO"))
{
    if($_POST['submitted'] || in_array($_REQUEST['mode'], array("delete")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if(isset($_POST['submitted']))
{
    if(!isset($_REQUEST['cronid']) || empty($_REQUEST['cronid']))
    {
        $results = Cron::Add(array("time" => $_REQUEST['crontime'], "type" => $_REQUEST['scheduletype'], "syscontrolid" => $_REQUEST['syscontrol']));
        if($results['error'] == -1)
        {
            $display->errormessage = $lang['badcrontime'];
        }
        elseif($results['error'] == -2)
        {
            $display->errormessage = $lang['noscheduletype'];
        }
        elseif($results['error'] == -3)
        {
            $display->errormessage = $lang['nosyscontrolid'];
        }
        elseif($results['error'] == -4)
        {
            $display->errormessage = $lang['missingugidoruvid'];
        }
        elseif($results['error'] == -5)
        {
            $display->errormessage = $lang['servermonscheduled'];
        }
        elseif($results['error'] == 0)
        {
            $display->goodmessage = $lang['scheduledtaskadded'];
        }
    }
    else
    {
        $results = Cron::Edit(array("time" => $_REQUEST['crontime'], "type" => $_REQUEST['scheduletype'], "syscontrolid" => $_REQUEST['syscontrol'], "cronid" => $_REQUEST['cronid']));
    }
}

if(!isset($_REQUEST['mode']))
{
    $display->pagename = $lang['scheduler'];

    $cronjobs = array();
    $x = 0;
    $query = GSP::getInstance()->db->query("SELECT * FROM `scheduler`");
    if($query && $query->num_rows > 0)
    {
        while($row = $query->fetch_assoc())
        {
            $cronjobs[$x]['cronid'] = $row['id'];
            $cronjobs[$x]['crontime'] = $row['crontime'];
            $cronjobs[$x]['type'] = $row['type'];
            if($row['type'] == "syscontrol")
            {
                $querysys = GSP::getInstance()->db->query("SELECT * FROM `syscontrol` WHERE `controlid`='".$row['syscontrolid']."' LIMIT 1");
                if($querysys && $querysys->num_rows == 1)
                {
                    $rowsys = $querysys->fetch_assoc();
                    $cronjobs[$x]['syscontrolname'] = $rowsys['name'];
                }
                $cronjobs[$x]['syscontrolid'] = $row['syscontrolid'];
            }
            elseif($row['type'] == "servermon")
            {
                $cronjobs[$x]['relid'] = "";
            }
            elseif($row['type'] == "restart" || $row['type'] == "start" || $row['type'] == "stop" || $row['type'] == "backup")
            {
                if(!empty($row['ugid']))
                {
                    $cronjobs[$x]['ugid'] = $row['ugid'];
                }
            }

            $x++;
        }
    }

    $display->cronjobs = $cronjobs;

    $display->DisplayType("admin");
    $display->Output("admin/utilities/scheduler/scheduler-list.tpl");
}
elseif($_REQUEST['mode'] == "add")
{
    $syscontrols = array();
    $x = 0;
    $query = GSP::getInstance()->db->query("SELECT * FROM `syscontrol`");
    if($query && $query->num_rows > 0)
    {
        while($row = $query->fetch_assoc())
        {
            $syscontrols[$x] = $row;
            $x++;
        }
    }

    $display->syscontrols = $syscontrols;

    $display->DisplayType("ajax");
    $display->Output("admin/utilities/scheduler/scheduler-add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    $return = Cron::Remove($_REQUEST['cronid']);
    if($return['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['notaskspecified'];
    }
    else
    {
        $_SESSION['goodmessage'] = $lang['scheduledtaskdeleted'];
    }
    header("Location: utility.php?module=scheduler");
}
?>
