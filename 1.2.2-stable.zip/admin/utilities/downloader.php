<?php

use GSPPanel\{Machines, GSP, SafeSQL, Strings};

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delete")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $result = Machines::DownloadFile($_REQUEST['sid'], $_REQUEST['url'], $_REQUEST['localfile']);
    if($result['error'] == 0)
    {
        $display->goodmessage = $lang['downloadstarted'];
    }
    elseif($result['error'] == -1)
    {
        $display->errormessage = $lang['noserverid'];
    }
    elseif($result['error'] == -2)
    {
        $display->errormessage = $lang['nourl'];
    }
    elseif($result['error'] == -3)
    {
        $display->errormessage = $lang['nolocalfile'];
    }
    elseif($result['error'] == -4)
    {
        $display->errormessage = $lang['servernotfound'];
    }
    elseif($result['error'] == -5)
    {
        $display->errormessage = $lang['serverupdate'];
    }
    elseif($result['error'] == -6)
    {
        $display->errormessage = $lang['machinecannotconnect2'];
    }
}

if($_REQUEST['mode'] == "delete")
{
    if(!empty($_REQUEST['dlid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `tasklist` WHERE `taskid`=%i AND `type`='downloadfile' LIMIT 1", array($_REQUEST['dlid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            GSP::getInstance()->db->query(SafeSQL::query("DELETE FROM `tasklist` WHERE `taskid`=%i AND `type`='downloadfile' LIMIT 1", array($_REQUEST['dlid'])));
            $display->goodmessage = $lang['downloaddeleted'];
        }
    }
    unset($_REQUEST['mode']);
}


if(empty($_REQUEST['mode']))
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `tasklist` WHERE (`type`='downloadfile' OR `type`='movedownload' OR `type`='downloadgamefile') ORDER BY dateposted DESC", array()));
    if($query && $query->num_rows > 0)
    {
        $downloads = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $row['data'] = json_decode($row['data'], true);
            $downloads[$x]['id'] = $row['taskid'];
            $downloads[$x]['dateposted'] = $row['dateposted'];
            $downloads[$x]['localfile'] = $row['data']['localfile'];
            if($row['type'] == "movedownload" || $row['type'] == "downloadgamefile")
            {
                $downloads[$x]['url'] = $lang['na'];
            }
            else
            {
                $downloads[$x]['url'] = $row['data']['url'];
            }
            $downloads[$x]['size'] = $row['data']['filesize'];
            $downloads[$x]['error'] = $row['data']['error'];
            if(isset($row['data']['finished']) && $row['data']['finished'] == "1")
            {
                $downloads[$x]['finished'] = $row['data']['finished'];
                $downloads[$x]['finishedpercentage'] = $row['data']['finishedpercentage'];
                $downloads[$x]['finishedsize'] = $row['data']['finishedsize'];
            }
            $x++;
        }
        $display->downloads = $downloads;
    }
    $query = GSP::getInstance()->db->query("SELECT * FROM `machines`");
    if($query && $query->num_rows > 0)
    {
        $machineslist = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $machineslist[$x]['id'] = $row['id'];
            $machineslist[$x]['alias'] = $row['alias'];
            $x++;
        }
        $display->machines = $machineslist;
    }

    $display->pagename = $lang['downloads'];

    $display->DisplayType("admin");
    $display->Output("admin/utilities/downloader.tpl");
}
elseif($_REQUEST['mode'] == "status")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `tasklist` WHERE `taskid`=%i LIMIT 1", array($_REQUEST['taskid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $row['data'] = json_decode($row['data'], true);

        $result = Machines::SendCommand($row['data']['sid'], "filelist:_:".$row['data']['localfile'], "yes");
        if($result != -1 && $result != -2 && $result != false)
        {
            if($row['data']['error'] == "1")
            {
                echo $lang['error'];
            }
            else
            {
                $result = explode(":", $result);
                $percentage = round(($result[1] / $row['data']['filesize']) * 100);
                echo $percentage."%<br />  ".Strings::ByteSize($result[1])." out of ".Strings::ByteSize($row['data']['filesize'])."";
            }
        }
        else
        {
            echo $lang['unablestatus'];
        }
    }
}
?>
