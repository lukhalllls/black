<?php

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

$display->pagename = $lang['servermon'];

$display->DisplayType("admin");
$display->Output("admin/utilities/servermonitor.tpl");
?>