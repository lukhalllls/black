<?php

use GSPPanel\{GSP, SafeSQL};

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delete")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if(empty($_REQUEST['newsid']))
    {
        GSP::getInstance()->db->query(SafeSQL::query("INSERT INTO `news` SET `machine`='%s', `game`='%s', `datetime`=FROM_UNIXTIME(%i), `content`='%s'", array($_REQUEST['machine'], $_REQUEST['game'], time(), $_REQUEST['content'])));
    }
    else
    {
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `news` SET `machine`='%s', `game`='%s', `content`='%s' WHERE `id`=%i", array($_REQUEST['machine'], $_REQUEST['game'], $_REQUEST['content'], $_REQUEST['newsid'])));
    }
    header("Location: utility.php?module=news");
    exit();
}

if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['news'];
    $display->DisplayType("admin");

    $query = GSP::getInstance()->db->query("SELECT * FROM `news` ORDER BY `datetime` DESC");
    if($query && $query->num_rows > 0)
    {
        $news = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $news[$x] = $row;
            $x++;
        }
        $display->news = $news;
    }

    $display->Output("admin/utilities/news/list.tpl");
}
elseif($_REQUEST['mode'] == "add")
{
    $display->pagename = $lang['addnews'];
    $display->DisplayType("admin");
    $query = GSP::getInstance()->db->query("SELECT * FROM `machines`");
    if($query && $query->num_rows > 0)
    {
        $machines = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $machines[$x] = $row;
            $x++;
        }
        $display->machines = $machines;
    }
    $query = GSP::getInstance()->db->query("SELECT * FROM `games`");
    if($query && $query->num_rows > 0)
    {
        $games = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $games[$x] = $row;
            $x++;
        }
        $display->games = $games;
    }
    $display->Output("admin/utilities/news/add.tpl");
}
elseif($_REQUEST['mode'] == "edit")
{
    $display->pagename = $lang['editnews'];
    $display->DisplayType("admin");

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `news` WHERE `id`=%i LIMIT 1", array($_REQUEST['newsid'])));
    if($query && $query->num_rows == 1)
    {
        $rownews = $query->fetch_assoc();
        $display->info = $rownews;
    }

    $query = GSP::getInstance()->db->query("SELECT * FROM `machines`");
    if($query && $query->num_rows > 0)
    {
        $machines = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $machines[$x] = $row;
            $x++;
        }
        $display->machines = $machines;
    }
    $query = GSP::getInstance()->db->query("SELECT * FROM `games`");
    if($query && $query->num_rows > 0)
    {
        $games = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $games[$x] = $row;
            $x++;
        }
        $display->games = $games;
    }

    $display->Output("admin/utilities/news/add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    if(!empty($_REQUEST['newsid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("DELETE FROM `news` WHERE `id`=%i LIMIT 1", array($_REQUEST['newsid'])));
        $_SESSION['goodmessage'] = $lang['newsdeleted'];
        header("Location: utility.php?module=news");
    }
}
?>
