<?php

use GSPPanel\{Games, GSP, SafeSQL, Machines, GameInstaller};

$display->pagename = $lang['gameinstaller'];

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $gameinfo = "";

    if($_REQUEST['id'] == "steamcmd")
    {
        $gameinfo = array(
            "name" => "SteamCMD",
            "id" => "steamcmd",
            "updated" => null,
            "linux" => 1,
            "windows" => 1,
            "path" => $_REQUEST['steamfolder'],
            "linuxdl" => "",
            "windowsdl" => "",
            "linuxcmd" => "",
            "windowscmd" => "",
            "windowssteamid" => $_REQUEST['steamappid'],
            "linuxsteamid" => $_REQUEST['steamappid'],
            "extract" => ""
            );
    }
    else
    {

        // Get the game information
        $results = Games::Import_GSPList($_REQUEST['id']);
        if($results['error'] == "0")
        {
            $gameinfo = $results['list'];
        }
        else
        {
            $display->errormessage = "Unable to get game information";
        }
    }

    if(!empty($gameinfo))
    {
        foreach($_REQUEST['machine'] as $k => $v)
        {
            $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `machines` WHERE `id`='%i' LIMIT 1", array($k)));
            if($query && $query->num_rows == 1)
            {
                $row = $query->fetch_assoc();
            }

            $result = GameInstaller::InstallGame(array(
                "sid" => $k,
                "name" => $gameinfo['name'],
                "id" => $gameinfo['id'],
                "updated" => $gameinfo['updated'],
                "linux" => $gameinfo['linux'],
                "windows" => $gameinfo['windows'],
                "path" => $gameinfo['path'],
                "linuxdl" => $gameinfo['linuxdl'],
                "windowsdl" => $gameinfo['windowsdl'],
                "linuxcmd" => $gameinfo['linuxcmd'],
                "windowscmd" => $gameinfo['windowscmd'],
                "windowssteamid" => $gameinfo['windowssteamid'],
                "linuxsteamid" => $gameinfo['linuxsteamid'],
                "extract" => $gameinfo['extract'],
                "steamuser" => $_REQUEST['steamusername'],
                "steampass" => $_REQUEST['steampassword']
                ));

            if($result['error'] == 0)
            {
                $display->goodmessage[] = $row['alias']." - ".$lang['gameinstallstarted'];
            }
            elseif($result['error'] == -1)
            {
                $display->errormessage[] = $row['alias']." - ".$lang['gameinstallfailed'];
            }
        }
    }
    if($_REQUEST['redir'] == "1")
    {
        header("Location: managegames.php");
    }
    unset($_REQUEST['mode']);
}


if(empty($_REQUEST['mode']))
{
    $results = Games::Import_GSPList();

    $gamelist = array();
    $gamelist[] = array("name" => "SteamCMD Downloader (Use for unlisted games)", "id" => "steamcmd", "updated" => "", "linux" => 1, "windows" => 1, "hastemplate" => 0);

    if($results['error'] == "0")
    {
        foreach($results['list'] as $key => $val)
        {
            if(!empty($val['windows']) || !empty($val['linux']))
            {
                $gamelist[] = $val;
            }
        }
    }

    $display->gamelist = $gamelist;

    $display->DisplayType("admin");
    $display->Output("admin/utilities/gameinstaller/list.tpl");
}
elseif($_REQUEST['mode'] == "selectmachine")
{
    if(!isset($_REQUEST['id']) || empty($_REQUEST['id']))
    {
        header("utility.php?module=gameinstaller");
    }

    if($_REQUEST['id'] == "steamcmd")
    {
        // Find the machines it can be installed on
        $machines = array();

        $query = GSP::getInstance()->db->query("SELECT * FROM `machines` WHERE `game_server`='1'");
        if($query && $query->num_rows > 0)
        {
            while($row = $query->fetch_assoc())
            {
                $querytask = GSP::getInstance()->db->query("SELECT * FROM `tasklist` WHERE `datefinished`='' AND `type`='gameinstaller' AND `data` REGEXP '(.*\"sid\":\"".$row['id']."\".*)' AND `data` REGEXP '(.*\"id\":\"".$val['id']."\".*)' LIMIT 1");
                if($querytask && $querytask->num_rows == 1)
                {
                    $row['installing'] = true;
                }
                $machines[] = $row;
            }
        }

        $display->steamcmd = true;

        $display->machines = $machines;
        $display->id = "steamcmd";
        $display->redir = 0;


        $display->DisplayType("admin");
        $display->Output("admin/utilities/gameinstaller/selectmachine.tpl");
        exit();
    }
    else
    {
        $results = Games::Import_GSPList($_REQUEST['id']);
        if($results['error'] == "0")
        {
            $val = $results['list'];
            if($val['id'] == $_REQUEST['id'] && (!empty($val['windows']) || !empty($val['linux'])))
            {
                // Find the machines it can be installed on
                $machines = array();
                if(!empty($val['linux']))
                {
                    $query = GSP::getInstance()->db->query("SELECT * FROM `machines` WHERE `os`='0' AND `game_server`='1'");
                    if($query && $query->num_rows > 0)
                    {
                        while($row = $query->fetch_assoc())
                        {
                            $querytask = GSP::getInstance()->db->query("SELECT * FROM `tasklist` WHERE `datefinished`='' AND `type`='gameinstaller' AND `data` REGEXP '(.*\"sid\":\"".$row['id']."\".*)' AND `data` REGEXP '(.*\"id\":\"".$val['id']."\".*)' LIMIT 1");
                            if($querytask && $querytask->num_rows == 1)
                            {
                                $row['installing'] = true;
                            }
                            $machines[] = $row;
                        }
                    }
                }
                if(!empty($val['windows']))
                {
                    $query = GSP::getInstance()->db->query("SELECT * FROM `machines` WHERE `os`='1' AND `game_server`='1'");
                    if($query && $query->num_rows > 0)
                    {
                        while($row = $query->fetch_assoc())
                        {
                            $querytask = GSP::getInstance()->db->query("SELECT * FROM `tasklist` WHERE `datefinished`='' AND `type`='gameinstaller' AND `data` REGEXP '(.*\"sid\":\"".$row['id']."\".*)' AND `data` REGEXP '(.*\"id\":\"".$val['id']."\".*)' LIMIT 1");
                            if($querytask && $querytask->num_rows == 1)
                            {
                                $row['installing'] = true;
                            }
                            $machines[] = $row;
                        }
                    }
                }
                if(!empty($val['windowssteamid']) || !empty($val['linuxsteamid']))
                {
                    $display->steamcmd = true;
                }
                else
                {
                    $display->steamcmd = false;
                }

                $display->machines = $machines;
                $display->id = $val['id'];
                $display->redir = $_REQUEST['redir'];
            }
            $display->DisplayType("admin");
            $display->Output("admin/utilities/gameinstaller/selectmachine.tpl");
        }
        else
        {
            echo $results;
        }
    }
}
?>
