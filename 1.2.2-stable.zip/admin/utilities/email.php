<?php

use GSPPanel\{GSP, SafeSQL, Emails, User, Machines, Games};

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delete")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $clients = array();
    $x = 0;

    // If the client type is a game then build a client list
    if($_REQUEST['client'] == "game")
    {
        if($_REQUEST['game'] != "")
        {
            $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` JOIN `usergames` ON users.uid=usergames.uid WHERE gid=%i GROUP BY users.uid", array($_REQUEST['game'])));
            if($query && $query->num_rows > 0)
            {
                while($row = $query->fetch_assoc())
                {
                    $clients[$x] = $row;
                    $x++;
                }
            }
        }
        else
        {
            $display->errormessage = $lang['usergamenotspecified'];
        }
    }
    // If the client type is a server then build a client list
    elseif($_REQUEST['client'] == "server")
    {
        if(!empty($_REQUEST['server']))
        {
            $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` JOIN `usergames` ON users.uid=usergames.uid JOIN `iplist` ON iplist.ipid=usergames.ipid WHERE sid=%i GROUP BY users.uid", array($_REQUEST['server'])));
            if($query && $query->num_rows > 0)
            {
                while($row = $query->fetch_assoc())
                {
                    $clients[$x] = $row;
                    $x++;
                }
            }
        }
        else
        {
            $display->errormessage = $lang['noserverid'];
        }
    }
    // If the client is set
    elseif($_REQUEST['client'] != "")
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` WHERE uid=%i", array($_REQUEST['client'])));
        if($query && $query->num_rows > 0)
        {
            $row = $query->fetch_assoc();
            $clients[0] = $row;
        }
        else
        {
            $display->errormessage = $lang['clientnotfound'];
        }
    }
    else
    {
        $display->errormessage = $lang['noclient'];
    }

    if(count($clients) == 0)
    {
        $display->errormessage = $lang['noclientstomail'];
    }


    if($_REQUEST['email_type'] == "new")
    {
        if(empty($_REQUEST['subject']) || empty($_REQUEST['content']))
        {
            $display->errormessage = $lang['mailnosubject'];
        }
    }
    elseif($_REQUEST['email_type'] != "")
    {
        $templateid = $_REQUEST['email_type'];
    }
    else
    {
        $display->errormessage = $lang['noemailtype'];
    }

    if(count($clients) > 0)
    {
        foreach($clients as $key => $value)
        {
            if($_REQUEST['email_type'] == "new")
            {
                if($_REQUEST['client'] == "game" && !empty($value['ugid']))
                {
                    $results = Emails::SendMail(array("subject" => $_REQUEST['subject'], "content" => $_REQUEST['content'], "uid" => $value['uid'], "ugid" => $value['ugid']));
                }
                else
                {
                    $results = Emails::SendMail(array("subject" => $_REQUEST['subject'], "content" => $_REQUEST['content'], "uid" => $value['uid']));
                }
            }
            else
            {
                if($_REQUEST['client'] == "game" && !empty($value['ugid']))
                {
                    $results = Emails::SendMail(array("templateid" => $templateid, "uid" => $value['uid'], "ugid" => $value['ugid']));
                }
                else
                {
                    $results = Emails::SendMail(array("templateid" => $templateid, "uid" => $value['uid']));
                }
            }

            if($results['error'] == 0)
            {
                $sent_successfully++;
            }
            elseif($results['error'] == -7)
            {
                $sent_errors++;
                $sent_error = $results['message'];
            }
            else
            {
                $sent_errors++;
            }
        }

        if(count($sent_successfully) > 0)
        {
            $display->goodmessage = str_replace("%t", $sent_successfully, $lang['sentemails']);
        }
        if(count($sent_errors) > 0)
        {
            $error[0] = $sent_errors." ".$lang['emailsfailed'];
        }

        if(isset($sent_error) && !empty($sent_error))
        {
            $error[1] = $sent_error;
        }

        $display->errormessage = $error;
    }
}

$_REQUEST['mode'] = "";

if(!isset($_REQUEST['mode']) || empty($_REQUEST['mode']))
{
    $display->pagename = $lang['emailutility'];
    $display->DisplayType("admin");

    $display->clients = User::ListUsers();
    $display->machines = Machines::ListMachines();
    $display->games = Games::ListGames();
    $display->emailtemplates = Emails::ListTemplate();

    $display->Output("admin/utilities/email/main.tpl");
}
?>