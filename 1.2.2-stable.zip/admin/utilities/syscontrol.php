<?php

use GSPPanel\{GSP, SafeSQL, SysControl};

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delete", "run")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if($_REQUEST['save'] == "yes")
    {
        if(empty($_REQUEST['controlid']))
        {
            GSP::getInstance()->db->query(SafeSQL::query("INSERT INTO `syscontrol` SET `name`='%s', `controltype`='%s', `game`='%s', `machine`='%s', `gameupdate`='%s', `systemcommand`='%s'", array($_REQUEST['savename'], $_REQUEST['controltype'], $_REQUEST['game'], $_REQUEST['machine'], $_REQUEST['gameupdate'], $_REQUEST['systemcommand'])));
        }
        else
        {
            GSP::getInstance()->db->query(SafeSQL::query("UPDATE `syscontrol` SET `name`='%s', `controltype`='%s', `game`='%s', `machine`='%s', `gameupdate`='%s', `systemcommand`='%s' WHERE `controlid`=%i", array($_REQUEST['savename'], $_REQUEST['controltype'], $_REQUEST['game'], $_REQUEST['machine'], $_REQUEST['gameupdate'], $_REQUEST['systemcommand'], $_REQUEST['controlid'])));
        }
    }
    else
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("INSERT INTO `syscontrol` SET `name`='%s', `controltype`='%s', `game`='%s', `machine`='%s', `gameupdate`='%s', `systemcommand`='%s'", array($_REQUEST['savename'], $_REQUEST['controltype'], $_REQUEST['game'], $_REQUEST['machine'], $_REQUEST['gameupdate'], $_REQUEST['systemcommand'])));
        $controlid = GSP::getInstance()->db->insert_id;

        $results = SysControl::Run($controlid);
        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['ransyscontrol'];
        }
        $query = GSP::getInstance()->db->query(SafeSQL::query("DELETE FROM `syscontrol` WHERE `controlid`='%i' LIMIT 1", array($controlid)));
    }
}

if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['systemcontrol'];
    $display->DisplayType("admin");

    $query = GSP::getInstance()->db->query("SELECT * FROM `syscontrol`");
    if($query && $query->num_rows > 0)
    {
        $syscontrol = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $syscontrol[$x] = $row;
            $x++;
        }
        $display->syscontrol = $syscontrol;
    }

    $display->Output("admin/utilities/syscontrol/syscontrol-list.tpl");
}
elseif($_REQUEST['mode'] == "add")
{
    $display->pagename = $lang['addsystemcontrol'];
    $display->DisplayType("admin");
    $query = GSP::getInstance()->db->query("SELECT * FROM `machines`");
    if($query && $query->num_rows > 0)
    {
        $machines = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $machines[$x] = $row;
            $x++;
        }
        $display->machines = $machines;
    }
    $query = GSP::getInstance()->db->query("SELECT * FROM `games`");
    if($query && $query->num_rows > 0)
    {
        $games = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $games[$x] = $row;
            $x++;
        }
        $display->games = $games;
    }
    $display->Output("admin/utilities/syscontrol/syscontrol-add.tpl");
}
elseif($_REQUEST['mode'] == "gameupdatelist")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_updates` WHERE `gid`=%i", array($_REQUEST['gid'])));
    if($query && $query->num_rows > 0)
    {
        $gameupdates = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $gameupdates[$x] = $row;
            $x++;
        }
        $display->gameupdates = $gameupdates;
    }
    $display->DisplayType("ajax");
    $display->Output("admin/utilities/syscontrol/ajax-typelist.tpl");
}
elseif($_REQUEST['mode'] == "edit")
{
    $display->pagename = $lang['editsystemcontrol'];
    $display->DisplayType("admin");

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `syscontrol` WHERE `controlid`=%i LIMIT 1", array($_REQUEST['controlid'])));
    if($query && $query->num_rows == 1)
    {
        $rowcontrol = $query->fetch_assoc();
        $display->info = $rowcontrol;
    }

    $query = GSP::getInstance()->db->query("SELECT * FROM `machines`");
    if($query && $query->num_rows > 0)
    {
        $machines = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $machines[$x] = $row;
            $x++;
        }
        $display->machines = $machines;
    }
    $query = GSP::getInstance()->db->query("SELECT * FROM `games`");
    if($query && $query->num_rows > 0)
    {
        $games = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $games[$x] = $row;
            $x++;
        }
        $display->games = $games;
    }

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_updates` WHERE `gid`='%i'", array($rowcontrol['game'])));
    if($query && $query->num_rows > 0)
    {
        $gameupdates = array();
        $x = 0;
        while($row = $query->fetch_assoc())
        {
            $gameupdates[$x] = $row;
            $x++;
        }
        $display->gameupdates = $gameupdates;
    }

    $display->Output("admin/utilities/syscontrol/syscontrol-add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    if(!empty($_REQUEST['controlid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("DELETE FROM `syscontrol` WHERE `controlid`=%i LIMIT 1", array($_REQUEST['controlid'])));
        $_SESSION['goodmessage'] = $lang['savedsystemcontroldeleted'];
        header("Location: utility.php?module=syscontrol");
    }
}
elseif($_REQUEST['mode'] == "run")
{
    if(!empty($_REQUEST['controlid']))
    {
        $results = SysControl::Run($_REQUEST['controlid']);
        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['ransyscontrol'];
        }
        elseif($results['error'] == -1)
        {
            $_SESSION['errormessage'] = $lang['nocontrolid'];
        }
        elseif($results['error'] == -1)
        {
            $_SESSION['errormessage'] = $lang['nocontrolfound'];
        }
    }
    header("Location: utility.php?module=syscontrol");
}


?>
