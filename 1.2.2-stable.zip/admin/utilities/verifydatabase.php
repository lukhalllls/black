<?php

use GSPPanel\{GSP, SafeSQL};

if(defined("DEMO"))
{
    die("This feature is disabled in demo mode");
}

if(empty($_REQUEST['mode']))
{
    $tables = array();

    $lines = file(DOC_ROOT."/installer/sql/gsp_panel.sql");
    if(!$lines)
    {
        $_SESSION['errormessage'] = $lang['unabletoloadsql'];
        header("Location: index.php");
    }

    /* Get rid of the comments and form one jumbo line */
    foreach($lines as $line)
    {
        $line = trim($line);
        if(preg_match("/^--/", $line) == 0)
        {
            $scriptfile.=" ".$line;
        }
    }

    if(!$scriptfile)
    {
        $_SESSION['errormessage'] = $lang['unabletoloadsql'];
        header("Location: index.php");
    }

    /* Split the jumbo line into smaller lines */
    $queries = explode(' ;', $scriptfile);

    /* Run each line as a query */
    foreach($queries as $query)
    {
        $query = trim($query);
        if($query == "")
        {
            continue;
        }
        if(preg_match("/CREATE\sTABLE/", $query)) 
        {
            $tables[implode(' ', array_slice(str_word_count($query, 2, "_"), 5, 1))] = $query;
        }
    }

    ksort($tables);

    $outputtables = array();

    foreach($tables as $k => $v)
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("CHECK TABLE %s", array($k)));
        if($query && $query->num_rows > 0)
        {
            $row = $query->fetch_assoc();
            $outputtables[$k] = array("status" => $row['Msg_text'], "rawcommand" => $v);
        }

        // Get all the column information for this table
        /*
        $query = GSP::getInstance()->db->query(SafeSQL::query("SHOW COLUMNS FROM %s", array($k)));
        if($query && $query->num_rows > 0)
        {
            while($row = $query->fetch_assoc())
            {
                // Column verification will be added later
            }
        }
        */
    }

    $display->pagename = $lang['verifydatabase'];
    $display->DisplayType("admin");
    $display->tables = $outputtables;
    $display->Output("admin/utilities/verifydatabase/list.tpl");
}
?>
