<?php

use GSPPanel\{GSP, SafeSQL, User, Strings};

if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || isset($_REQUEST['clear']))
    {
        die("This feature is disabled in demo mode");
    }
}

if(isset($_REQUEST['clear']) && $_SESSION['mainadmin'] == "1")
{
    GSP::getInstance()->db->query("DELETE FROM `events`");
}

if(empty($_REQUEST['logtype']))
{
    $display->users = User::ListUsers();
    $display->pagename = $lang['logs'];
    $display->DisplayType("admin");
    $display->Output("admin/utilities/logs/logs.tpl");
}

if($_REQUEST['logtype'] == "events")
{
    $limit = $_REQUEST['length'];

    $uid = $_REQUEST['columns'][0]['search']['value'];
    $type = $_REQUEST['columns'][1]['search']['value'];

    if($type != 'debug') $sql = "AND `type`!='debug'";
    // Query for the user if specified
    if(!empty($uid)) $sql .= " AND `userid`='".$uid."'";
    // Query for the type if specified
    if(!empty($type)) $sql .= " AND `type`='".$type."'";


    $query = GSP::getInstance()->db->query("SELECT COUNT(*) as total FROM `events` WHERE `type`!='login'");
    if($query && $query->num_rows > 0)
    {
        $info = $query->fetch_assoc();
        $totalall_rows = $info['total'];
    }

    $query = GSP::getInstance()->db->query("SELECT COUNT(*) as total FROM `events` WHERE `type`!='login' ".$sql);
    if($query && $query->num_rows > 0)
    {
        $info = $query->fetch_assoc();
        $total_rows = $info['total'];
    }

    $json = array();
    $json['draw'] = $_REQUEST['draw'];
    $json['recordsTotal'] = $totalall_rows;
    $json['recordsFiltered'] = $total_rows;
    $json['data'] = array();

    $log = array();
    $query = GSP::getInstance()->db->query("SELECT * FROM `events` WHERE `type`!='login' ".$sql." ORDER BY `time` DESC LIMIT ".$_REQUEST['start'].",".$limit);
    if($query && $query->num_rows > 0)
    {
        while($row = $query->fetch_assoc())
        {
            // Get the username
            $row['user'] = User::UIDToUser($row['userid']);

            // If a subuser ran it, get their username
            if($row['subuser'] == 1)
            {
                $row['runby'] = User::UIDToUser($row['runbyid'], "subuser");
            }
            else
            {
                // Get the first and last name for the user and the runby user
                $queryuser = GSP::getInstance()->db->query(SafeSQL::query("SELECT firstname, lastname FROM `users_profile` WHERE `uid`='%i' LIMIT 1", array($row['userid'])));
                if($queryuser && $queryuser->num_rows == 1)
                {
                    $rowuser = $queryuser->fetch_assoc();
                }
                $queryuser = GSP::getInstance()->db->query(SafeSQL::query("SELECT firstname, lastname FROM `users_profile` WHERE `uid`='%i' LIMIT 1", array($row['runbyid'])));
                if($queryuser && $queryuser->num_rows == 1)
                {
                    $rowrunby = $queryuser->fetch_assoc();
                }
                $row['runby'] = User::UIDToUser($row['runbyid']);
            }

            // If the user has a name then display the popup
            if($rowuser && !empty($rowuser['firstname']))
            {
                $tempuser = '<a href="clients.php?mode=summary&uid='.$row['userid'].'" data-toggle="tooltip" title="'.Strings::filter($rowuser['firstname']).' '.Strings::filter($rowuser['lastname']).'('.Strings::filter($row['user']).')">'.$row['userid'].'</a>';
            }
            else
            {
                $tempuser = '<a href="clients.php?mode=summary&uid='.$row['userid'].'" data-toggle="tooltip" title="'.Strings::filter($row['user']).'">'.$row['userid'].'</a>';
            }
            $row['message'] = str_replace("{user}", $tempuser, $row['message']);

            // If the runby user has a name then display the popup
            if($rowrunby && !empty($rowrunby['firstname']))
            {
                $tempuser = '<a href="clients.php?mode=summary&uid='.$row['runbyid'].'" data-toggle="tooltip" title="'.Strings::filter($rowrunby['firstname']).' '.Strings::filter($rowrunby['lastname']).'('.Strings::filter($row['runby']).')">'.$row['runbyid'].'</a>';
            }
            else
            {
                $tempuser = '<a href="clients.php?mode=summary&uid='.$row['runbyid'].'" data-toggle="tooltip" title="'.Strings::filter($row['runby']).'">'.$row['runbyid'].'</a>';
            }

            $row['message'] = str_replace("{runby}", $tempuser, $row['message']);

            // Replace the ugid variable with a link
            $row['message'] = str_replace("{ugid}", '<a href="manageusergames.php?mode=managegame&ugid='.$row['ugid'].'">'.$row['ugid'].'</a>', $row['message']);

            $row['time'] = date("Y-m-d H:i:s", $row['time']);

            $json['data'][] = array($row['time'], $row['user'], $row['message'], $row['runby']);
        }
    }

    echo json_encode($json);
}
elseif($_REQUEST['logtype'] == "api")
{
    if($_REQUEST['mode'] == "view")
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `api_logs` WHERE `id`='%i' LIMIT 1", array($_REQUEST['id'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            // Get the username
            $row['requestjson'] = $row['request'];
            $row['datajson'] = $row['data'];
            $row['responsejson'] = $row['response'];
            $row['request'] = json_decode($row['request'], true);
            $row['data'] = json_decode($row['data'], true);
            $row['response'] = json_decode($row['response'], true);

            $display->log = $row;

            $display->DisplayType("ajax");
            $display->Output("admin/utilities/logs/api-view.tpl");
            exit();
        }
    }
    else
    {
        $limit = $_REQUEST['length'];

        $query = GSP::getInstance()->db->query("SELECT COUNT(*) as total FROM `api_logs`");
        if($query && $query->num_rows > 0)
        {
            $info = $query->fetch_assoc();
            $totalall_rows = $info['total'];
        }

        $query = GSP::getInstance()->db->query("SELECT COUNT(*) as total FROM `api_logs`");
        if($query && $query->num_rows > 0)
        {
            $info = $query->fetch_assoc();
            $total_rows = $info['total'];
        }

        $json = array();
        $json['draw'] = $_REQUEST['draw'];
        $json['recordsTotal'] = $totalall_rows;
        $json['recordsFiltered'] = $total_rows;
        $json['data'] = array();

        $log = array();
        $query = GSP::getInstance()->db->query("SELECT * FROM `api_logs` ORDER BY `time` DESC LIMIT ".$_REQUEST['start'].",".$limit);
        if($query && $query->num_rows > 0)
        {
            while($row = $query->fetch_assoc())
            {
                $row['request'] = json_decode($row['request'], true);
                $row['data'] = json_decode($row['data'], true);
                $row['response'] = json_decode($row['response'], true);

                $row['time'] = date("Y-m-d H:i:s", $row['time']);

                $json['data'][] = array($row['id'], $row['time'], $row['user'], $row['request']['ip'], $row['request']['action']);
            }
        }

        echo json_encode($json);
    }
}
elseif($_REQUEST['logtype'] == "servermon")
{
    if($_REQUEST['mode'] == "view")
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `servermon_log` WHERE `session`='%s' ORDER BY `time` ASC", array($_REQUEST['id'])));
        if($query && $query->num_rows > 0)
        {
            while($row = $query->fetch_assoc())
            {
                echo $row['result']."<br />";
            }
        }
        exit();
    }
    else
    {

        $limit = $_REQUEST['length'];

        $query = GSP::getInstance()->db->query("SELECT COUNT(*) as total FROM (SELECT DISTINCT * FROM `servermon_log` GROUP BY `session`) as sq");
        if($query && $query->num_rows > 0)
        {
            $info = $query->fetch_assoc();
            $totalall_rows = $info['total'];
        }

        $query = GSP::getInstance()->db->query("SELECT COUNT(*) as total FROM (SELECT DISTINCT * FROM `servermon_log` GROUP BY `session`) as sq");
        if($query && $query->num_rows > 0)
        {
            $info = $query->fetch_assoc();
            $total_rows = $info['total'];
        }

        $json = array();
        $json['draw'] = $_REQUEST['draw'];
        $json['recordsTotal'] = $totalall_rows;
        $json['recordsFiltered'] = $total_rows;
        $json['data'] = array();

        $log = array();
        $query = GSP::getInstance()->db->query("SELECT * FROM `servermon_log` GROUP BY `session` ORDER BY `time` DESC LIMIT ".$_REQUEST['start'].",".$limit);
        if($query && $query->num_rows > 0)
        {
            while($row = $query->fetch_assoc())
            {
                $row['time'] = date("Y-m-d H:i:s", $row['time']);

                $json['data'][] = array($row['session'], $row['time'], $row['session']);
            }
        }

        echo json_encode($json);
    }
}

?>