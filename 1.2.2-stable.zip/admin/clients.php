<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{GSP, SafeSQL, User, Games, EventLog};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delete", "delsubuser", "loginas")))
    {
        die("This feature is disabled in demo mode");
    }
}

// Permission checks for sub-admins
if($_SESSION['mainadmin'] != "1")
{
    if(!in_array("addclient", $_SESSION['permissions']) && !in_array("editclient", $_SESSION['permissions']) && !in_array("deleteclient", $_SESSION['permissions']) && !in_array("manageclient", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if(($_REQUEST['mode'] == "savesubuser" || $_REQUEST['mode'] == "delsubuser" || $_REQUEST['mode'] == "addsubuser" || $_REQUEST['mode'] == "editsubuser" || $_REQUEST['mode'] == "subuserlist" || $_REQUEST['mode'] == "loginas") && !in_array("manageclient", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if($_REQUEST['mode'] == "edit" && !in_array("editclient", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if($_REQUEST['mode'] == "add" && !in_array("addclient", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if($_REQUEST['mode'] == "delete" && !in_array("deleteclient", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    /*
     * EDIT
     */
    if($_REQUEST['mode'] == "edit")
    {
        $params = array('email' => $_REQUEST['email'],
            'password' => $_REQUEST['password'],
            'status' => $_REQUEST['status'],
            'phone' => $_REQUEST['phone'],
            'firstname' => $_REQUEST['firstname'],
            'lastname' => $_REQUEST['lastname'],
            'address' => $_REQUEST['address'],
            'city' => $_REQUEST['city'],
            'state' => $_REQUEST['state'],
            'zipcode' => $_REQUEST['zipcode'],
            'country' => $_REQUEST['country'],
            'notes' => $_REQUEST['notes'],
            'billingid' => $_REQUEST['billingid'],
            'uid' => $_REQUEST['uid']);
        $returnval = User::EditClient($params);
        if($returnval['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['usersaved'];
            header("Location: clients.php?mode=summary&uid=".$params['uid']);
            exit();
        }
        elseif($returnval['error'] == -1)
        {
            $error = $lang['nouserspecified'];
        }
        elseif($returnval['error'] == -2)
        {
            $error = $lang['invalidemail'];
        }
        elseif($returnval['error'] == -3)
        {
            $error = $lang['usernotexist'];
        }
        elseif($returnval['error'] == -4)
        {
            $error = $lang['novalidemail'];
        }
        if(!empty($error))
        {

            $display->errormessage = $error;
        }
    }
    /*
     * ADD
     */
    elseif($_REQUEST['mode'] == "add")
    {
        $params = array('email' => $_REQUEST['email'],
            'password' => $_REQUEST['password'],
            'status' => $_REQUEST['status'],
            'phone' => $_REQUEST['phone'],
            'firstname' => $_REQUEST['firstname'],
            'lastname' => $_REQUEST['lastname'],
            'address' => $_REQUEST['address'],
            'city' => $_REQUEST['city'],
            'state' => $_REQUEST['state'],
            'zipcode' => $_REQUEST['zipcode'],
            'country' => $_REQUEST['country'],
            'billingid' => $_REQUEST['billingid'],
            'notes' => $_REQUEST['notes']);
        $returnval = User::AddClient($params);
        if($returnval['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['useradded'];
            header("Location: clients.php");
            exit();
        }
        elseif($returnval['error'] == -1)
        {
            $error = $lang['novalidemail'];
        }
        elseif($returnval['error'] == -2)
        {
            $error = $lang['invalidemail'];
        }
        if(!empty($error))
        {
            $display->info = $_REQUEST;
            $display->errormessage = $error;
        }
    }

    /*
     * Save Subuser
     */
    elseif($_REQUEST['mode'] == "savesubuser")
    {
        if(!empty($_REQUEST['subid']))
        {
            $params = array("email" => $_REQUEST['email'],
                "password" => $_REQUEST['password'],
                "gameserver" => $_REQUEST['gameserver'],
                "subid" => $_REQUEST['subid'],
                "uid" => $_REQUEST['uid']);
            $results = User::EditSubUser($params);
            if($results['error'] == 0)
            {
                $msg = '<div id="good">'.$lang['subusersaved'].'</div>';
            }
            elseif($results['error'] == -1)
            {
                $msg = '<div id="error">'.$lang['missinginformation'].'</div>';
            }
            elseif($results['error'] == -2)
            {
                $msg = '<div id="error">'.$lang['invalidemail'].'</div>';
            }
            elseif($results['error'] == -3)
            {
                $msg = '<div id="error">'.$lang['usernotexist'].'</div>';
            }
            echo $msg;
            exit();
        }
        else
        {
            $params = array("email" => $_REQUEST['email'],
                "password" => $_REQUEST['password'],
                "gameserver" => $_REQUEST['gameserver'],
                "uid" => $_REQUEST['uid']);
            $results = User::AddSubUser($params);
            if($results['error'] == 0)
            {
                $msg = '<div id="good">'.$lang['subusersaved'].'</div>';
            }
            elseif($results['error'] == -1)
            {
                $msg = '<div id="error">'.$lang['novalidemail'].'</div>';
            }
            elseif($results['error'] == -2)
            {
                $msg = '<div id="error">'.$lang['invalidemail'].'</div>';
            }
            echo $msg;
            exit();
        }
    }
}
if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['clients'];
    $display->DisplayType("admin");

    $display->Output("admin/clients/clients-list.tpl");
}
elseif($_REQUEST['mode'] == "pagination")
{
    $limit = $_REQUEST['length'];

    $totalall_rows = count(User::ListUsers());
    $total_rows = count(User::ListUsers(array("search" => $_REQUEST['search']['value'])));

    $clientlist = User::ListUsers(array("search" => $_REQUEST['search']['value'], "limit" => ($_REQUEST['start']).",".$limit));

    $json = array();
    $json['draw'] = $_REQUEST['draw'];
    $json['recordsTotal'] = $totalall_rows;
    $json['recordsFiltered'] = $total_rows;
    $json['data'] = array();
    foreach($clientlist as $k => $v)
    {
        $json['data'][] = array($v['uid'], $v['email'], $v['firstname']." ".$v['lastname'], $v['servicecount'], '<a class="btn btn-secondary btn-sm" href="clients.php?mode=summary&uid='.$v['uid'].'">'.$lang['manage'].'</a>');
    }

    echo json_encode($json);
}
elseif($_REQUEST['mode'] == "edit")
{
    $display->pagename = $lang['editclient'];

    $info = User::GetUserInfo($_REQUEST['uid']);

    if($info && count($info) != 0)
    {
        $display->info = $info;
        $display->DisplayType("admin");
        $display->Output("admin/clients/clients-add.tpl");
    }
    else
    {
        $_SESSION['errormessage'] = $lang['nouserfound'];
        header("Location: index.php");
    }
}
elseif($_REQUEST['mode'] == "add")
{
    $display->pagename = $lang['addclient'];
    $display->DisplayType("admin");
    $display->Output("admin/clients/clients-add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    $results = User::DeleteUser($_REQUEST['uid']);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['userremoved'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['usernotexist'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['unableremovegameoffline'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['unableremovegamedebug'];
    }
    exit();
}
elseif($_REQUEST['mode'] == "summary")
{
    $display->pagename = $lang['clientsummary'];

    $info = User::GetClientInfo($_REQUEST['uid']);
    if($info && count($info) != 0)
    {
        $display->DisplayType("admin");
        $display->info = $info;

        $fulleventlist = EventLog::ViewLog(array("userid" => $_REQUEST['uid'], "orderby" => "time DESC", "limit" => "5"));
        if(count($fulleventlist) > 0)
        {
            $display->eventlist = $fulleventlist;
        }

        $lastlogin = EventLog::ViewLog(array("userid" => $_REQUEST['uid'], "type" => "login", "orderby" => "time DESC", "limit" => "1"));
        if($lastlogin && count($lastlogin) == 1)
        {
            $display->lastlogin = $lastlogin[0]['time'];
        }
        $display->subusers = User::ListSubUsers($_REQUEST['uid']);

        $services = array();
        $x = 0;

        $gameservers = Games::ListGameServers(array("uid" => $_REQUEST['uid']));
        foreach($gameservers as $gs)
        {
            $services[$x] = $gs;
            $x++;
        }

        $display->services = $services;
        $display->Output("admin/clients/clients-summary.tpl");
    }
    else
    {
        $_SESSION['errormessage'] = $lang['nouserfound'];
        header("Location: index.php");
    }
}
elseif($_REQUEST['mode'] == "loginas")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` WHERE `uid`='%i' AND `userlevel`='0' LIMIT 1", array($_REQUEST['uid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $_SESSION = array();
        //@session_destroy();
        @session_start();
        if($row['status'] == 0)
        {
            $_SESSION['errormessage'] = $lang['loginallowedsuspended'];
        }
        $_SESSION['loggedin'] = "1";
        $_SESSION['uid'] = $row['uid'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['userlevel'] = $row['userlevel'];
        $_SESSION['billingid'] = $row['billingid'];
        $_SESSION['permissions'] = $row['permission'];
        // Valid login
        header("Location: ../client/index.php");
    }
}
elseif($_REQUEST['mode'] == "delsubuser")
{
    if(!empty($_GET['uid']) && !empty($_GET['subid']))
    {
        $results = User::DeleteSubUser($_GET['subid']);
        if($results['error'] == 0)
        {
            echo '<div id="good">'.$lang['userremoved'].'</div>';
        }
        else
        {
            echo '<div id="error">'.$lang['unableremoveuser'].'</div>';
        }
        exit();
    }
}
elseif($_REQUEST['mode'] == "addsubuser")
{
    if(!empty($_REQUEST['uid']))
    {
        $display->gameservers = Games::ListGameServers(array("uid" => $_REQUEST['uid']));
        if(count($display->gameservers) > 0)
        {
            $display->uid = $_REQUEST['uid'];
            $display->DisplayType("ajax");
            $display->Output("admin/clients/ajax-editsubuser.tpl");
        }
        else
        {
            echo "0";
        }
    }
}
elseif($_REQUEST['mode'] == "editsubuser")
{
    if(!empty($_REQUEST['uid']) && !empty($_REQUEST['subid']))
    {
        $info = User::GetSubUserInfo($_REQUEST['subid'], $_REQUEST['uid']);
        if($info && count($info) != 0)
        {
            $display->subuser = $info['info'];
            $display->gameservers = $info['gameservers'];
            $display->uid = $_REQUEST['uid'];
            $display->Output("admin/clients/ajax-editsubuser.tpl");
        }
        else
        {
            echo "0";
        }
    }
}
elseif($_REQUEST['mode'] == "subuserlist")
{
    $display->subusers = User::ListSubUsers($_REQUEST['uid']);
    $display->DisplayType("ajax");
    $display->Output("admin/clients/ajax-subuserlist.tpl");
}
elseif($_REQUEST['mode'] == "serverinfo")
{
    // Image variables
    $online = '<div class="online"></div>';
    $offline = '<div class="offline"></div>';

    if(!empty($_REQUEST['ugid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `ugid`='%i' LIMIT 1", array($_REQUEST['ugid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            if($row['status'] == 1)
            {
                $results = Games::QueryGame(array('ugid' => $row['ugid'], 'nomap' => true));
                if($results['error'] == 0)
                {
                    if($results['status'] == 1)
                    {
                        echo '<div id="status">'.$online.'</div>';
                        echo '<div id="players">'.$results['active']."/".$results['total'].'</div>';
                        if(strlen($results['hostname']) > 30)
                        {
                            $results['hostname'] = substr($results['hostname'], 0, 27)."...";
                        }
                        echo '<div id="hostname">'.$results['hostname'].'</div>';
                        exit();
                    }
                }
            }
        }
    }

    echo '<div id="status">'.$offline.'</div>';
    echo '<div id="players">'."N/A".'</div>';
    echo '<div id="hostname">'."N/A".'</div>';
    exit();
}
?>