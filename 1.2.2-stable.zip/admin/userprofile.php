<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{User, GSP, SafeSQL};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    die("This feature is disabled in demo mode");
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if($_REQUEST['mode'] == "save")
    {
        if($_REQUEST['uid'] != $_SESSION['uid'])
        {
            $_SESSION['errormessage'] = $lang['notallowedtoeditotherprofiles'];
            header("Location: userprofile.php");
            exit();
        }
        
        $params = array('email' => $_REQUEST['email'],
            'password' => $_REQUEST['password'],
            'uid' => $_REQUEST['uid']);
        $returnval = User::EditAdmin($params);
        if($returnval['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['profilesaved'];
            header("Location: userprofile.php");
            exit();
        }
        elseif($returnval['error'] == -1)
        {
            $error = $lang['nouserspecified'];
        }
        elseif($returnval['error'] == -2)
        {
            $error = $lang['novalidemail'];
        }
        elseif($returnval['error'] == -4)
        {
            $error = $lang['invalidemail'];
        }
        elseif($returnval['error'] == -5)
        {
            $error = $lang['usernotexist'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
}
$display->pagename = $lang['myprofile'];

$query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` WHERE `uid`=%i AND `userlevel`='1' LIMIT 1", array($_SESSION['uid'])));
if($query && $query->num_rows == 1)
{
    $row = $query->fetch_assoc();

    $display->info = $row;
    $display->DisplayType("admin");
    $display->Output("admin/userprofile/userprofile.tpl");
}
else
{
    $_SESSION['errormessage'] = $lang['profilenotfound'];
    header("Location: index.php");
}
?>