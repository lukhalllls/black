<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\Plugins;

$display->pagename = $lang['plugins'];

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if($_POST['enabled'] == "1")
    {
        $result = Plugins::getInstance()->installPlugin($_POST['id']);
        if($result['status'] === true)
        {
            $_SESSION['goodmessage'] = $lang['pluginenabled'];
        }
        else
        {
            $_SESSION['errormessage'] = $result['error'];
        }
    }
    elseif($_POST['enabled'] == "0")
    {
        Plugins::getInstance()->uninstallPlugin($_POST['id']);
        if($result['status'] === true)
        {
            $_SESSION['goodmessage'] = $lang['plugindisabled'];
        }
        else
        {
            $_SESSION['errormessage'] = $result['error'];
        }
    }
    header("Location: plugins.php");
}

if(empty($_REQUEST['mode']))
{
    $plugins = Plugins::getInstance()->listPlugins();
    foreach($plugins as $k => $v)
    {
        $pluginf[] = $v;
    }
    $display->plugins = $pluginf;

    $display->DisplayType("admin");
    $display->Output("admin/configuration/plugins.tpl");
}
elseif($_REQUEST['mode'] == "edit")
{
    $details = Plugins::getInstance()->getPluginDetails($_REQUEST['id']);
    $display->plugin = $details;

    $display->DisplayType("admin");
    $display->Output("admin/configuration/plugins-edit.tpl");
}
?>