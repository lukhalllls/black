<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{Machines, User, GSP, Games, SafeSQL, Strings};

if($_REQUEST['mode'] == "disablenotice")
{
    if(!empty($_REQUEST['type']))
    {
        if($_REQUEST['type'] == "servermon_runtime")
        {
            $_SESSION['displayed_servermon'] = true;
        }
        elseif($_REQUEST['type'] == "update")
        {
            $_SESSION['displayedupdate'] = true;
        }
        elseif($_REQUEST['type'] == "debugging_mode")
        {
            $_SESSION['displayed_debugging'] = true;
        }
    }
    exit();
}
// Machine status check, this is an ajax query used to reduce load times of the dashboard
if($_REQUEST['mode'] == "machinestatus")
{
    // Calculate the machine statistics for the home page chart
    $machinelist = Machines::ListMachines(array("gameserver" => "1"));
    if($machinelist && count($machinelist) > 0)
    {
        $online = 0;
        $offline = 0;
        $outdated = 0;
        foreach($machinelist as $m)
        {
            $results = Machines::VerifyConnection($m['id']);
            if($results == 1)
            {
                $online++;
            }
            elseif($results == -1)
            {
                $outdated++;
            }
            else
            {
                $offline++;
            }
        }
        if($outdated > 0)
        {
            AddSystemMessage($lang['sysoutdatedremote']);
        }
        $machines = array("online" => $online,
            "offline" => $offline,
            "outdated" => $outdated);
        $display->machines = $machines;
    }
    else
    {
        $machines = array("online" => 0,
            "offline" => 0,
            "outdated" => 0);
        $display->machines = $machines;
    }
    
    $display->DisplayType("ajax");
    $display->Output("admin/index_ajax.tpl");
    exit();
}

// This will display a page for stats and such
$inactiveusers = count(User::ListUsers(array("status" => "0")));
$activeusers = count(User::ListUsers(array("status" => "1")));
if($activeusers > 0 || $inactiveusers > 0)
{
    $totalusers = $inactiveusers + $activeusers;
    $activepercent = ($activeusers / $totalusers) * 100;
    $inactivepercent = ($inactiveusers / $totalusers) * 100;
    $clients = array("activepercent" => $activepercent,
        "active" => $activeusers,
        "suspendedpercent" => $inactivepercent,
        "suspended" => $inactiveusers);
    $display->clients = $clients;
}
else
{
    $clients = array("active" => 0,
        "suspended" => 0);
    $display->clients = $clients;
}

$inactiveservers = count(Games::ListGameServers(array("status" => "2")));
$activeservers =  count(Games::ListGameServers(array("status" => "0"))) + count(Games::ListGameServers(array("status" => "1"))) ;

if($activeservers > 0 || $inactiveservers > 0)
{
    $totalservers = $inactiveservers + $activeservers;
    $activepercent = ($activeservers / $totalservers) * 100;
    $inactivepercent = ($inactiveservers / $totalservers) * 100;
    $games = array("activepercent" => $activepercent,
        "active" => $activeservers,
        "suspendedpercent" => $inactivepercent,
        "suspended" => $inactiveservers);
    $display->games = $games;
}
else
{
    $games = array("active" => 0,
        "suspended" => 0);
    $display->games = $games;
}


// Show latest events
$events = array();
$x = 0;
$query = GSP::getInstance()->db->query("SELECT * FROM `events` WHERE `type`!='login' AND `type`!='debug' ORDER BY `time` DESC LIMIT 20");
if($query && $query->num_rows > 0)
{
    while($row = $query->fetch_assoc())
    {
        $row['user'] = User::UIDToUser($row['userid']);
        if($row['subuser'] == 1)
        {
            $row['runby'] = User::UIDToUser($row['runbyid'], "subuser");
        }
        else
        {
            $queryuser = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users_profile` WHERE `uid`='%i' LIMIT 1", array($row['userid'])));
            if($queryuser && $queryuser->num_rows == 1)
            {
                $rowuser = $queryuser->fetch_assoc();
            }
            $queryuser = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users_profile` WHERE `uid`='%i' LIMIT 1", array($row['runbyid'])));
            if($queryuser && $queryuser->num_rows == 1)
            {
                $rowrunby = $queryuser->fetch_assoc();
            }
            $row['runby'] = User::UIDToUser($row['runbyid']);
        }

        if($rowuser && !empty($rowuser['firstname']))
        {
            $tempuser = '<a data-toggle="tooltip" href="clients.php?mode=summary&uid='.$row['userid'].'" title="'.Strings::filter($rowuser['firstname']).' '.Strings::filter($rowuser['lastname']).'('.Strings::filter($row['user']).')">'.$row['userid'].'</a>';
        }
        else
        {
            $tempuser = '<a data-toggle="tooltip" href="clients.php?mode=summary&uid='.$row['userid'].'" title="'.Strings::filter($row['user']).'">'.$row['userid'].'</a>';
        }
        $row['message'] = str_replace("{user}", $tempuser, $row['message']);

        // Replace runby
        if($rowrunby && !empty($rowrunby['firstname']))
        {
            $tempuser = '<a data-toggle="tooltip" href="clients.php?mode=summary&uid='.$row['runbyid'].'" title="'.Strings::filter($rowrunby['firstname']).' '.Strings::filter($rowrunby['lastname']).'('.Strings::filter($row['runby']).')">'.$row['runbyid'].'</a>';
        }
        else
        {
            $tempuser = '<a data-toggle="tooltip" href="clients.php?mode=summary&uid='.$row['runbyid'].'" title="'.Strings::filter($row['runby']).'">'.$row['runbyid'].'</a>';
        }
        $row['message'] = str_replace("{runby}", $tempuser, $row['message']);

        $row['message'] = str_replace("{ugid}", '<a href="manageusergames.php?mode=managegame&ugid='.$row['ugid'].'">'.$row['ugid'].'</a>', $row['message']);

        $events[$x] = $row;
        $x++;
    }
}
$display->events = $events;

$display->pagename = $lang['home'];
$display->DisplayType("admin");
$display->Output("admin/index.tpl");
?>