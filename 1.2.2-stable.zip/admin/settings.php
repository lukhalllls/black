<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{GSP, SafeSQL, Emails};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("bldel", "testemail")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_GET['mode'] == "bldel")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("DELETE FROM `blacklist` WHERE `id`='%i' LIMIT 1", array($_GET['id'])));
    $_SESSION['goodmessage'] = $lang['blacklistdeleted'];
    header("Location: settings.php");
}
if($_GET['mode'] == "testemail")
{
    $results = Emails::SendMail(array("debug" => true, "subject" => "GSP-Panel Test Email", "content" => "This is a test email", "email" => GSP::getInstance()->settings['email_reply']));
    if($results['error'] == 0)
    {
        echo str_replace("%t", "1", $lang['sentemails']);
    }
    elseif($results['error'] == -7)
    {
        echo "<br />".$results['message'];
    }
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if(!isset($_POST['mode']))
    {
        // Lets save all the settings
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='language'", array($_POST['defaultlanguage'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='title'", array($_POST['title'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='template'", array($_POST['template'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='debugging'", array($_POST['debugging'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='smartydebug'", array($_POST['smartydebug'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='usequota'", array($_POST['usequota'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='redirectlogout'", array($_POST['redirectlogout'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webftp'", array($_POST['webftp'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webftpeditable'", array($_POST['webftpeditable'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='maintenance_mode'", array($_POST['maintenance_mode'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='maintenance_mainonly'", array($_POST['maintenance_mainonly'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='maintenance_message'", array($_POST['maintenance_message'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='gameservergraphs'", array($_POST['gameservergraphs'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='masterip'", array($_POST['masterip'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='console_lines'", array($_POST['console_lines'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='cronmethod'", array($_POST['cronmethod'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='scheduleraccess'", array($_POST['scheduleraccess'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='timezone'", array($_POST['timezone'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='advancedfeatures'", array($_POST['advancedfeatures'])));
        
        if(GSP::getInstance()->settings['cronmethod'] == "gsppanel" && $_POST['cronmethod'] == "local")
        {
            GSP::getInstance()->db->query("DELETE FROM `scheduler`");
        }

        // Delete the smarty cache just incase the template changed
        $smarty->clearAllCache();
        $smarty->clearCompiledTemplate();

        $_SESSION['goodmessage'] = $lang['settingssaved'];
        header("Location: settings.php");
    }
    elseif($_POST['mode'] == "security")
    {
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='forcehttps'", array($_POST['forcehttps'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='ban_limit'", array($_POST['ban_limit'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='ban_expiretime'", array($_POST['ban_expiretime'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='ftp_displaypass'", array($_POST['ftp_displaypass'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='ftp_displayblacklist'", array($_POST['ftp_displayblacklist'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='gameservergraphs_auth'", array($_POST['gameservergraphs_auth'])));

        GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `settings` WHERE `name`='passencrypt' LIMIT 1", array()));
        $row = $query->fetch_assoc();
        // Check if the new and old encryption methods match
        if($row['value'] != $_POST['passencrypt'])
        {
            User::RecodePasswords($_POST['passencrypt']);
        }

        $_SESSION['goodmessage'] = $lang['settingssaved'];
        header("Location: settings.php");
    }
    elseif($_POST['mode'] == "api")
    {
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webapi'", array($_POST['webapi'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webapi_pass'", array($_POST['webapi_pass'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webapi_clientaccess'", array($_POST['webapi_clientaccess'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webapi_subuseraccess'", array($_POST['webapi_subuseraccess'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webapi_subadminaccess'", array($_POST['webapi_subadminaccess'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webapi_adminaccess'", array($_POST['webapi_adminaccess'])));
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='webapi_logretention'", array($_POST['webapi_logretention'])));

        $_SESSION['goodmessage'] = $lang['settingssaved'];
        header("Location: settings.php");
    }
    elseif($_POST['mode'] == "email")
    {
        if($_POST['mailserver'] == "smtp" && (empty($_POST['smtp_server']) || empty($_POST['smtp_port']) || empty($_POST['smtp_user']) || empty($_POST['smtp_password'])))
        {
            $_SESSION['errormessage'] = $lang['smtprequired'];
            header("Location: settings.php");
            exit();
        }

        if(is_array($_POST['email']))
        {
            foreach($_POST['email'] as $key => $value)
            {
                GSP::getInstance()->db->query(SafeSQL::query("INSERT INTO `settings` (name,value) VALUES ('%s','%s') ON DUPLICATE KEY UPDATE `value`='%s'", array($key, $value, $value)));
            }
        }

        if(is_array($_POST['template']))
        {
            foreach($_POST['template'] as $key => $value)
            {
                GSP::getInstance()->db->query(SafeSQL::query("INSERT INTO `emails` (type,templateid) VALUES ('%s','%s') ON DUPLICATE KEY UPDATE `templateid`='%i'", array($key, $value, $value)));
            }
        }

        $_SESSION['goodmessage'] = $lang['settingssaved'];
        header("Location: settings.php");
    }
    elseif($_POST['mode'] == "bladd")
    {
        if(!empty($_POST['content']) && ($_POST['content'] != "*") && ($_POST['content'] != "*@*"))
        {
            GSP::getInstance()->db->query(SafeSQL::query("INSERT INTO `blacklist` SET `type`='%s', `content`='%s'", array($_POST['type'], $_POST['content'])));
            $_SESSION['goodmessage'] = $lang['blacklistadded'];
        }
        else
        {
            $_SESSION['errormessage'] = $lang['blacklisterror'];
        }
        header("Location: settings.php");
    }
    elseif($_POST['mode'] == "eventlogging")
    {
        foreach($_POST['eventlog'] as $key => $value)
        {
            GSP::getInstance()->db->query(SafeSQL::query("INSERT INTO `settings` (name,value) VALUES ('%s','%s') ON DUPLICATE KEY UPDATE `value`='%s'", array('eventlog_'.$key, $value, $value)));
        }

        $_SESSION['goodmessage'] = $lang['settingssaved'];
        header("Location: settings.php");
    }
}

$display->pagename = $lang['generalsettings'];
$display->DisplayType("admin");

// TAB 1
$templates = array();
$dir = opendir("../templates/");
while($file = readdir($dir))
{
    if($file != "." && $file != "..")
    {
        if(is_dir("../templates/".$file))
        {
            $templates[] = $file;
        }
    }
}

$display->templates = $templates;

$languages = array();
$dir = opendir("../includes/lang/");
while($file = readdir($dir))
{
    if($file != "." && $file != ".." && is_file("../includes/lang/".$file))
    {
        $path_info = pathinfo("../includes/lang/".$file);
        if($path_info['extension'] == "php")
        {
            $languages[] = str_replace(".php", "", $file);
        }
    }
}

$display->languages = $languages;

// Get a list of PHP timezones
$timezoneIdentifiers = DateTimeZone::listIdentifiers();
$gmtTime = new DateTime('now', new DateTimeZone('GMT'));

$tempTimezones = array();
foreach($timezoneIdentifiers as $timezoneIdentifier)
{
    $currentTimezone = new DateTimeZone($timezoneIdentifier);
    $tempTimezones[] = array(
        'offset' => (int) $currentTimezone->getOffset($gmtTime),
        'identifier' => $timezoneIdentifier
    );
}

// Sort the array by offset,identifier ascending
usort($tempTimezones, function($a, $b)
{
    return ($a['offset'] == $b['offset']) ? strcmp($a['identifier'], $b['identifier']) : $a['offset'] - $b['offset'];
});

$timezoneList = array();
foreach($tempTimezones as $tz)
{
    $sign = ($tz['offset'] > 0) ? '+' : '-';
    $offset = gmdate('H:i', abs($tz['offset']));
    $timezoneList[$tz['identifier']] = '(GMT '.$sign.$offset.') '.$tz['identifier'];
}

$display->timezones = $timezoneList;


// TAB 3
$blacklist = array();
$x = 0;
$query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `blacklist` ORDER BY `type`", array()));
if($query && $query->num_rows > 0)
{
    while($row = $query->fetch_assoc())
    {
        $blacklist[$x] = $row;
        $x++;
    }
}
$display->blacklist = $blacklist;

// TAB 2
$emailtemplates = array();
$x = 0;
$query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `emailtemplates`", array()));
if($query && $query->num_rows > 0)
{
    while($row = $query->fetch_assoc())
    {
        $typearray = array();
        $query2 = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `emails` WHERE `templateid`='%i'", array($row['templateid'])));
        if($query2)
        {
            while($row2 = $query2->fetch_assoc())
            {
                $typearray[] = $row2['type'];
            }
            $row['type'] = $typearray;
        }
        $emailtemplates[$x] = $row;
        $x++;
    }
}
$display->emailtemplates = $emailtemplates;

$display->Output("admin/configuration/settings.tpl");
?>