<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{Machines, GSP, User, Games, SafeSQL, Strings};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("delete", "addip", "delip", "update", "viewdebug", "savegame", "viewftpdebug", "savedomainalias")))
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SESSION['mainadmin'] != "1" && !in_array("managemachines", $_SESSION['permissions']))
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    /*
     * Edit
     */
    if($_REQUEST['mode'] == "edit")
    {
        $params = array('alias' => $_REQUEST['alias'],
            'main_ip' => $_REQUEST['main_ip'],
            'location' => $_REQUEST['location'],
            'file_location' => $_REQUEST['file_location'],
            'userfile_location' => $_REQUEST['userfile_location'],
            'backupfile_location' => $_REQUEST['backupfile_location'],
            'os' => $_REQUEST['os'],
            'listenport' => $_REQUEST['listenport'],
            'ftpport' => $_REQUEST['ftpport'],
            'httpport' => $_REQUEST['httpport'],
            'game_server' => $_REQUEST['game_server'],
            'slots_quota' => $_REQUEST['slots_quota'],
            'servers_quota' => $_REQUEST['servers_quota'],
            'debugging' => $_REQUEST['debugging'],
            'fileserver' => $_REQUEST['fileserver'],
            'diskthrottle' => $_REQUEST['diskthrottle'],
            'uid' => $_REQUEST['uid'],
            'sid' => $_REQUEST['sid']);

        $results = Machines::EditMachine($params);
        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['machinesaved'];
            header("Location: machines.php");
            exit();
        }
        elseif($results['error'] == -1)
        {
            $error = $lang['nomachineid'];
        }
        elseif($results['error'] == -2)
        {
            $error = $lang['missinginformation'];
        }
        elseif($results['error'] == -3)
        {
            $error = $lang['machinehasotherservers'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
    /*
     * Add
     */
    elseif($_REQUEST['mode'] == "add")
    {
        $params = array('alias' => $_REQUEST['alias'],
            'main_ip' => $_REQUEST['main_ip'],
            'location' => $_REQUEST['location'],
            'file_location' => $_REQUEST['file_location'],
            'userfile_location' => $_REQUEST['userfile_location'],
            'backupfile_location' => $_REQUEST['backupfile_location'],
            'os' => $_REQUEST['os'],
            'listenport' => $_REQUEST['listenport'],
            'ftpport' => $_REQUEST['ftpport'],
            'httpport' => $_REQUEST['httpport'],
            'game_server' => $_REQUEST['game_server'],
            'slots_quota' => $_REQUEST['slots_quota'],
            'servers_quota' => $_REQUEST['servers_quota'],
            'debugging' => $_REQUEST['debugging'],
            'fileserver' => $_REQUEST['fileserver'],
            'diskthrottle' => $_REQUEST['diskthrottle'],
            'uid' => $_REQUEST['uid']);

        $results = Machines::AddMachine($params);
        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['machineadded'];
            header("Location: machines.php?mode=edit&sid=".$results['sid']."#tab_install");
            exit();
        }
        elseif($results['error'] == -1)
        {
            $error = str_replace("%s", $results['count'], $lang['machinesexceeded']);
        }
        elseif($results['error'] == -2)
        {
            $error = $lang['missinginformation'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
    /*
     * Add IP
     */
    elseif($_REQUEST['mode'] == "addip")
    {
        if(is_array($_REQUEST['mip']))
        {
            Machines::AddIPs(array("sid" => $_REQUEST['sid'], "ips" => $_REQUEST['mip']));
        }
        if(!empty($_REQUEST['sip']))
        {
            Machines::AddIPs(array("sid" => $_REQUEST['sid'], "ips" => array($_REQUEST['sip'])));
        }

        header("Location: machines.php?mode=edit&sid=".$_REQUEST['sid']."#tab_ips");
        exit();
    }
    /*
     * Save IP alias
     */
    elseif($_REQUEST['mode'] == "savedomainalias")
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `iplist` WHERE `ipid`=%i LIMIT 1", array($_REQUEST['ipid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();

            GSP::getInstance()->db->query(SafeSQL::query("UPDATE `iplist` SET `alias`='%s' WHERE `ipid`='%i'", array($_REQUEST['value'], $_REQUEST['ipid'])));
            echo "1";
            exit();
        }
    }
    /*
     * Toggle the dedicated ip option
     */
    elseif($_REQUEST['mode'] == "togglededicatedip")
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `iplist` WHERE `ipid`=%i LIMIT 1", array($_REQUEST['ipid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();

            GSP::getInstance()->db->query(SafeSQL::query("UPDATE `iplist` SET `dedicated`='%i' WHERE `ipid`='%i' LIMIT 1", array($_REQUEST['value'], $_REQUEST['ipid'])));
            echo "1";
            exit();
        }
    }
    elseif($_REQUEST['mode'] == "setgamequota")
    {
        if(empty($_REQUEST['value']) && $_REQUEST['value'] !== "0")
        {
            $_REQUEST['value'] = -1;
        }
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `games_cache` SET `quota`='%i' WHERE `sid`='%i' AND `gid`='%i' LIMIT 1", array($_REQUEST['value'], $_REQUEST['sid'], $_REQUEST['gid'])));
        echo "1";
        exit();
    }
}

if(empty($_REQUEST['mode']))
{
    $display->pagename = $lang['managemachines'];
    $display->DisplayType("admin");

    $machines = Machines::ListMachines();

    $x = 0;
    $display->machines = array();
    foreach($machines as $v)
    {
        if($v['os'] == "0")
        {
            $v['os'] = "Linux";
        }
        elseif($v['os'] == "1")
        {
            $v['os'] = "Windows";
        }

        if($v['slots'] == "-1")
        {
            $v['slots'] = "N";
        }
        if($v['slots_quota'] == "-1")
        {
            $v['slots_quota'] = "A";
        }

        if($v['servers'] == "-1")
        {
            $v['servers'] = "N";
        }
        if($v['servers_quota'] == "-1")
        {
            $v['servers_quota'] = "A";
        }

        $display->machines[$x] = $v;

        $x++;
    }

    $display->Output("admin/machines/managemachines-list.tpl");
}
elseif($_REQUEST['mode'] == "edit")
{
    $display->pagename = $lang['editmachine'];

    $display->fileservers = Machines::ListMachines();
    $display->users = User::ListUsers();

    $machineinfo = Machines::GetMachineInfo($_REQUEST['sid']);
    if(count($machineinfo) == 0)
    {
        $_SESSION['errormessage'] = $lang['machinenotfound'];
        header("Location: index.php");
    }
    else
    {
        if(isset($machineinfo['gamelist']))
        {
            $display->gamelist = $machineinfo['gamelist'];
        }

        $display->ips = $machineinfo['ips'];
        $display->info = $machineinfo['info'];
        $display->DisplayType("admin");
        $display->Output("admin/machines/managemachines-add.tpl");
    }
}
elseif($_REQUEST['mode'] == "add")
{
    if(Machines::Count() >= GSP::getInstance()->GetAllowedServers())
    {
        $_SESSION['errormessage'] = str_replace("%s", GSP::getInstance()->GetAllowedServers(), $lang['machinesexceeded']);
        header("Location: machines.php");
        exit();
    }
    $display->fileservers = Machines::ListMachines();
    $display->users = User::ListUsers();
    $display->pagename = $lang['addmachine'];
    $display->DisplayType("admin");
    $display->Output("admin/machines/managemachines-add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    $params = array("sid" => $_REQUEST['sid']);
    $results = Machines::DeleteMachine($params);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['machineremoved'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nomachineid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['machinehasservices'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['machinenotfound'];
    }
    header("Location: machines.php");
    exit();
}
elseif($_REQUEST['mode'] == "info")
{
    $display->pagename = $lang['machineinformation'];

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT id, debugging FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $display->DisplayType("admin");
        $display->machinedebug = $row['debugging'];
        $display->sid = $_REQUEST['sid'];
        $display->Output("admin/machines/info.tpl");
    }
}
elseif($_REQUEST['mode'] == "verifygames")
{
    $display->DisplayType("ajax");
    $results = Machines::VerifyGames(array("sid" => $_REQUEST['sid'], "forceupdate" => true));
    if($results['error'] == 0)
    {
        $display->gamelist = $results['gamelist'];
        $display->Output("admin/machines/ajax-verifygames.tpl");
    }
    else
    {
        $display->errorcode = $results['error'];
        $display->Output("common/error.tpl");
    }
}
elseif($_REQUEST['mode'] == "sysinfo")
{
    $display->DisplayType("ajax");
    $results = Machines::SystemInfo(array("sid" => $_REQUEST['sid']));
    if($results['error'] == 0)
    {
        $display->os = $results['os'];
        $display->memory = $results['memory'];
        $display->hd = $results['hd'];
        $display->version = $results['version'];
        $display->Output("admin/machines/ajax-sysinfo.tpl");
    }
    else
    {
        $display->errorcode = $results['error'];
        $display->Output("common/error.tpl");
    }
}
elseif($_REQUEST['mode'] == "status")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT game_server, debugging FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        /*if($row['game_server'] == "0")
        {
            echo "N/A";
            exit();
        }*/
        $results = Machines::VerifyConnection($_REQUEST['sid']);
        if($results == 1)
        {
            if($row['debugging'] == "1")
            {
                echo "<font style='color:green'>".$lang['online']."</font> - ".$lang['debugging'];
            }
            else
            {
                echo "<font style='color:green'>".$lang['online']."</font>";
            }
            exit();
        }
        elseif($results == 0)
        {
            if($row['debugging'] == "1")
            {
                echo "<font style='color:red'>".$lang['offline']."</font> - ".$lang['debugging'];
            }
            else
            {
                echo "<font style='color:red'>".$lang['offline']."</font>";
            }
            exit();
        }
        elseif($results == -1)
        {
            echo "<a class='update' href='machines.php?mode=update&sid=".$_REQUEST['sid']."'>".$lang['outdated']."</a>";
            exit();
        }
    }
}
elseif($_REQUEST['mode'] == "verifynew")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT id, main_ip, listenport FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $machinestatus = Machines::VerifyConnection($_REQUEST['sid']);
        if($machinestatus == "0")
        {
            echo $lang['machinecannotconnect'];
            echo "<br />";
            if(!empty($errdesc))
            {
                echo $lang['reason'].": ".$errdesc;
            }
            exit();
        }
        elseif($machinestatus == "-1")
        {
            echo $lang['machineoutdated'];
            exit();
        }
        elseif($machinestatus == "1")
        {
            echo $lang['machinesuccessful'].", <a class='ipstep' href='#'>".$lang['clickherecontinue']."</a>";
            exit();
        }
    }
    else
    {
        echo $lang['machinenotfound'];
        exit();
    }
}
elseif($_REQUEST['mode'] == "addip")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();

        // Get the IPs that are bound to the machine
        $machineips = Machines::GetIPs($row['id']);

        // Get a list of IPs already setup
        $dbips = Machines::ListIPs($row['id']);

        $ipslist = array();
        $x = 0;
        if(is_array($dbips))
        {
            foreach($machineips as $ip)
            {
                if(Strings::search_array($ip['ip'], $dbips, "ip"))
                {
                    $ipslist[$x] = $ip;
                    $x++;
                }
            }
        }
        $display->ips = $ipslist;
        $display->sid = $_REQUEST['sid'];
        $display->DisplayType("ajax");
        $display->Output("admin/machines/ajax-addip.tpl");
    }
    else
    {
        $_SESSION['errormessage'] = $lang['machinenotfound'];
        header("Location: index.php");
    }
}
elseif($_REQUEST['mode'] == "delip")
{
    $del = Machines::DeleteIP($_REQUEST['ipid']);
    if($del['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['ipremoved'];
    }
    elseif($del['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['iphasservices'];
    }

    header("Location: machines.php?mode=edit&sid=".$_REQUEST['sid']."#tab_ips");
    exit();
}
elseif($_REQUEST['mode'] == "update")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $machinestatus = Machines::VerifyConnection($_REQUEST['sid']);
        if($machinestatus == "0")
        {
            $_SESSION['errormessage'] = $lang['machinecannotconnect2'];
        }
        else
        {
            $response = Machines::Update($_REQUEST['sid']);
            sleep(10);
            if($response == true)
            {
                $_SESSION['goodmessage'] = $lang['machineupdating'];
            }
            else
            {
                $_SESSION['errormessage'] = $lang['machineupdatingerror'];
            }
        }
    }
    else
    {
        $_SESSION['errormessage'] = $lang['machinenotfound'];
    }
    exit();
}
elseif($_REQUEST['mode'] == "graphs")
{
    if(!empty($_REQUEST['sid']))
    {
        $display->sid = $_REQUEST['sid'];
        $display->DisplayType("ajax");
        $display->Output("admin/machines/graphs.tpl");
    }
}
elseif($_REQUEST['mode'] == "savegame")
{
    if($_REQUEST['action'] == "enable")
    {
        Games::EnableGame($_REQUEST['gid'], $_REQUEST['sid']);
    }
    else
    {
        Games::DisableGame($_REQUEST['gid'], $_REQUEST['sid']);
    }
    exit();
}
elseif($_REQUEST['mode'] == "viewdebug")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $results = Machines::SendCommand($row['id'], "readconsole:_:\$MAINDIR/debug.txt", true);
        echo "<br /><div style='text-align:left; overflow: scroll; width: 100%; height: 350px;'>".str_replace('&#10;', '<br />', Strings::filter($results, 'special'))."</div>";
    }
    else
    {
        echo $lang['machinenotfound'];
    }
}
elseif($_REQUEST['mode'] == "viewftpdebug")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `machines` WHERE `id`=%i LIMIT 1", array($_REQUEST['sid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        $results = Machines::SendCommand($row['id'], "readconsole:_:\$MAINDIR/ftpdebug.txt", true);
        echo "<br /><div style='text-align:left; overflow: scroll; width: 100%; height: 350px;'>".str_replace('&#10;', '<br />', Strings::filter($results, 'special'))."</div>";
    }
    else
    {
        echo $lang['machinenotfound'];
    }
}
?>