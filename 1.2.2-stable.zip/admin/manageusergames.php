<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{GSP, SafeSQL, Machines, User, Strings, Games, Backup, Cron, FTP, DatabaseManagement};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || in_array($_REQUEST['mode'], array("createdatabase", "deletedatabase", "moveserver", "installgame", "getconfig", "viewconsole", "start", "stop", "restart", "delete", "reinstall", "suspendgame", "unsuspendgame", "installaddon", "installupdate", "backup", "deletebackup", "restorebackup", "saveconfig", "addcron", "deletecron", "rconcommand", "enablemaintenace", "disablemaintenace")))
    {
        die("This feature is disabled in demo mode");
    }
}

// Permission checks for sub-admins
if($_SESSION['mainadmin'] != "1")
{
    if($_REQUEST['mode'] == "editgame" && !in_array("editservice", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if(($_REQUEST['mode'] == "addgame" || $_REQUEST['mode'] == "installgame" || $_REQUEST['mode'] == "gameoptions") && !in_array("addservice", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if($_REQUEST['mode'] == "delete" && !in_array("deleteservice", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if(($_REQUEST['mode'] == "suspendgame" || $_REQUEST['mode'] == "unsuspendgame") && !in_array("suspendservice", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if(($_REQUEST['mode'] == "managegame" || $_REQUEST['mode'] == "gameinfo") && (!in_array("editservice", $_SESSION['permissions']) && !in_array("suspendservice", $_SESSION['permissions']) && !in_array("deleteservice", $_SESSION['permissions']) && !in_array("manageservice", $_SESSION['permissions'])))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if(($_REQUEST['mode'] == "viewconsole" || $_REQUEST['mode'] == "start" || $_REQUEST['mode'] == "stop" || $_REQUEST['mode'] == "restart" || $_REQUEST['mode'] == "installaddon" || $_REQUEST['mode'] == "installupdate" || $_REQUEST['mode'] == "addcron" || $_REQUEST['mode'] == "deletecron" || $_REQUEST['mode'] == "rconcommand" || $_REQUEST['mode'] == "createdatabase" || $_REQUEST['mode'] == "deletedatabase") && !in_array("manageservice", $_SESSION['permissions']))
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
    if($_REQUEST['mode'] == "moveserver" || $_REQUEST['mode'] == "reinstall")
    {
        $_SESSION['errormessage'] = $lang['nopermission'];
        header("Location: index.php");
        exit();
    }
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    /*
     * Edit game
     */
    if($_REQUEST['mode'] == "editgame")
    {
        $params = array('ugid' => $_REQUEST['ugid'],
            'port_main' => $_REQUEST['port_main'],
            'port_query' => $_REQUEST['port_query'],
            'port_rcon' => $_REQUEST['port_rcon'],
            'port_custom1' => $_REQUEST['port_custom1'],
            'port_custom2' => $_REQUEST['port_custom2'],
            'port_custom3' => $_REQUEST['port_custom3'],
            'port_custom4' => $_REQUEST['port_custom4'],
            'private' => $_REQUEST['private'],
            'priority' => $_REQUEST['priority'],
            'affinity' => $_REQUEST['affinity'],
            'maxslots' => $_REQUEST['maxslots'],
            'billingid' => $_REQUEST['billingid'],
            'dedicatedip' => $_REQUEST['dedicatedip'],
            'fastdl' => $_REQUEST['fastdl'],
            'config' => $_REQUEST['config'],
            'restartserver' => $_REQUEST['restartserver'],
            'commandline' => $_REQUEST['commandline']);
        $returnval = Games::EditUserGame($params);
        if($returnval['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['usergamesaved'];
            header("Location: manageusergames.php?mode=managegame&ugid=".$_REQUEST['ugid']);
            exit();
        }
        elseif($returnval['error'] == -1)
        {
            $error = $lang['usergamenotspecified'];
        }
        elseif($returnval['error'] == -2)
        {
            $error = $lang['usergamenotfound'];
        }
        elseif($returnval['error'] == -3)
        {
            $error = $lang['usergamenotfound'];
        }
        elseif($returnval['error'] == -4)
        {
            $error = $lang['badport'];
        }
        elseif($returnval['error'] == -5)
        {
            $error = $lang['serveroffline'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
            $_REQUEST['mode'] = "managegame";
            $display->tab = 3;
        }
    }
    /*
     * Add game
     */
    elseif($_REQUEST['mode'] == "addgame")
    {
        $params = array('uid' => $_REQUEST['uid'],
            'sid' => $_REQUEST['sid'],
            'gid' => $_REQUEST['game'],
            'install' => true,
            'private' => $_REQUEST['private'],
            'priority' => $_REQUEST['priority'],
            'maxslots' => $_REQUEST['maxslots'],
            'config' => $_REQUEST['config'],
            'dedicatedip' => $_REQUEST['dedicatedip'],
            'fastdl' => $_REQUEST['fastdl'],
            'email' => true);
        $results = Games::AddUserGame($params);
        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['usergameinstalling'];
            header("Location: clients.php?mode=summary&uid=".$_REQUEST['uid']);
            exit();
        }
        elseif($results['error'] == -1)
        {
            $error = $lang['missinginformation'];
        }
        elseif($results['error'] == -2)
        {
            $error = $lang['nouserdatabase'];
        }
        elseif($results['error'] == -3)
        {
            $error = $lang['gamenotindatabase'];
        }
        elseif($results['error'] == -7)
        {
            $_SESSION['errormessage'] = $lang['serveraddederror'];
            header("Location: clients.php?mode=summary&uid=".$_REQUEST['uid']);
            exit();
        }
        elseif($results['error'] == -8)
        {
            $error = $lang['machinenotfound'];
        }
        elseif($results['error'] == -10)
        {
            $error = $lang['licensecountrestrict'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
    elseif($_REQUEST['mode'] == "moveserver")
    {
        if(isset($_REQUEST['movefiles']) && $_REQUEST['movefiles'] == "1")
        {
            $params = array("ugid" => $_REQUEST['ugid'], "sid" => $_REQUEST['sid'], "movefile" => true);
        }
        else
        {
            $params = array("ugid" => $_REQUEST['ugid'], "sid" => $_REQUEST['sid']);
        }

        $results = Games::MoveUserGame($params);

        if($results['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['beingmoved'];
        }
        elseif($results['error'] == -1)
        {
            $_SESSION['errormessage'] = $lang['missinginformation'];
        }
        elseif($results['error'] == -2)
        {
            $_SESSION['errormessage'] = $lang['usergamenotfound'];
        }
        elseif($results['error'] == -3)
        {
            $_SESSION['errormessage'] = $lang['gamenotexist'];
        }
        elseif($results['error'] == -4)
        {
            $_SESSION['errormessage'] = $lang['machinenotfound'];
        }
        elseif($results['error'] == -5)
        {
            $_SESSION['errormessage'] = $lang['gamealreadyonip'];
        }
        elseif($results['error'] == -7)
        {
            $_SESSION['errormessage'] = $lang['servermoveinstallerror'];
        }
        elseif($results['error'] == -8)
        {
            $_SESSION['errormessage'] = $lang['machineofflinecantmove'];
        }
        elseif($results['error'] == -9)
        {
            $_SESSION['errormessage'] = $lang['unableremovegamedebug'];
        }
        elseif($results['error'] == -13)
        {
            $_SESSION['errormessage'] = $lang['lockedtask'];
        }
        elseif($results['error'] == -14)
        {
            $_SESSION['errormessage'] = $lang['errorbackingup'];
        }
        header("Location: manageusergames.php?mode=managegame&ugid=".$_REQUEST['ugid']);
        exit();
    }
    elseif($_REQUEST['mode'] == "rconcommand")
    {
        $results = Games::Rcon(array("command" => $_REQUEST['rconcommand'], "password" => $_REQUEST['rconpassword'], "ugid" => $_REQUEST['ugid']));

        if($results['error'] == 0)
        {
            echo "<pre>";
            if(!empty($results['data']))
            {
                echo $results['data'];
            }
            else
            {
                echo $lang['noreply'];
            }
            echo "</pre>";
        }
        if($results['error'] == -1)
        {
            echo $lang['nogameid'];
        }
        elseif($results['error'] == -2)
        {
            echo $lang['commandmissing'];
        }
        elseif($results['error'] == -3)
        {
            echo $lang['gamenotindatabase'];
        }
        elseif($results['error'] == -4)
        {
            echo $lang['noprotocol'];
        }
        elseif($results['error'] == -5)
        {
            echo $lang['noprotocolfound'];
        }
        elseif($results['error'] == -6)
        {
            echo $lang['unknownerror'];
            echo "<pre>";
            echo $results['data'];
            echo "</pre>";
        }
    }
    elseif($_REQUEST['mode'] == "addcron")
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `scheduler` WHERE `ugid`='%i'", array($_REQUEST['ugid'])));
        if($query && $query->num_rows >= 5)
        {
            echo '<div id="error">'.$lang['youcanonlyhave']." 5 ".$lang['scheduledperserver'].'</div>';
            exit();
        }

        if($_REQUEST['action'] != "start" && $_REQUEST['action'] != "restart" && $_REQUEST['action'] != "stop" || $_REQUEST['action'] != "backup")
        {
            header("Location: index.php");
        }

        $results = Cron::Add(array("time" => $_REQUEST['crontime'], "type" => $_REQUEST['action'], "ugid" => $_REQUEST['ugid']));

        if($results['error'] == -1)
        {
             echo '<div id="error">'.$lang['badcrontime'].'</div>';
        }
        elseif($results['error'] == -2)
        {
            echo '<div id="error">'.$lang['noscheduletype'].'</div>';
        }
        elseif($results['error'] == -3)
        {
            echo '<div id="error">'.$lang['nosyscontrolid'].'</div>';
        }
        elseif($results['error'] == -4)
        {
            echo '<div id="error">'.$lang['missingugidoruvid'].'</div>';
        }
        elseif($results['error'] == -5)
        {
            echo '<div id="error">'.$lang['servermonscheduled'].'</div>';
        }
        elseif($results['error'] == 0)
        {
            echo '<div id="good">'.$lang['scheduledtaskadded'].'</div>';
        }
        exit();
    }
    elseif($_REQUEST['mode'] == "createdatabase")
    {
        $results = DatabaseManagement::Add($_REQUEST['ugid'], $_REQUEST['databasename']);
        if($results['error'] == 0)
        {
            echo '<div id="good">'.$lang['databasecreated'].'</div>';
        }
        elseif($results['error'] == -1)
        {
            echo '<div id="error">'.$lang['usergamenotfound'].'</div>';
        }
        elseif($results['error'] == -2)
        {
            echo '<div id="error">'.$lang['databasedisabledforgame'].'</div>';
        }
        elseif($results['error'] == -3)
        {
            echo '<div id="error">'.$lang['databaselimitreached'].'</div>';
        }
        elseif($results['error'] == -4)
        {
            echo '<div id="error">'.$lang['databasealreadyexists'].'</div>';
        }
        elseif($results['error'] == -5)
        {
            echo '<div id="error">'.$lang['errorcreatingdatabase'].' - '.$results['errordetails'].'</div>';
        }
        elseif($results['error'] == -6)
        {
            echo '<div id="error">'.$lang['databaseuserexistserror'].'</div>';
        }
        elseif($results['error'] == -7)
        {
            echo '<div id="error">'.$lang['databaseusererror'].' - '.$results['errordetails'].'</div>';
        }
        elseif($results['error'] == -8)
        {
            echo '<div id="error">'.$lang['missinginformation'].'</div>';
        }
    }
    elseif($_REQUEST['mode'] == "saveconfig")
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
        $row = $query->fetch_assoc();

        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_configs` WHERE `gid`=%i AND `cfid`=%i LIMIT 1", array($row['gid'], $_REQUEST['configid'])));
        $rowconfig = $query->fetch_assoc();

        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games` WHERE `gid`=%i LIMIT 1", array($row['gid'])));
        $rowgame = $query->fetch_assoc();


        $ftp = new ftp($_REQUEST['ugid']);
        if($ftp->loggedOn)
        {
            $ftp->setCurrentDir($ftp->userDir);
            $ftp->setMode(1);

            if(!empty($rowgame['redirectfolder']))
            {
                $rowconfig['directory'] = str_replace($rowgame['redirectfolder'], "", $rowconfig['directory']);
            }

            $rowconfig['directory'] = ltrim($rowconfig['directory'], "/");
            $ftp->setCurrentDir($rowconfig['directory']);

            $temp_file = tempnam($ftp->downloadDir, 'gsp');
            $fp = fopen($temp_file, "w+t");
            if($bytes = !fwrite($fp, $_REQUEST['fileContent'], strlen($_REQUEST['fileContent'])))
            {
                echo '<div id="error">'.$lang['errorupload'].'</div>';
            }
            else
            {
                //Upload the file to the server
                if(!$ftp->put($ftp->currentDir."/".$ftp->filePart($rowconfig['filename']), $temp_file))
                {
                    echo '<div id="error">'.$lang['errorupload'].'</div>';
                }
                else
                {
                    echo '<div id="good">'.$lang['filesaved'].'</div>';
                }
            }
            fclose($fp);
            unlink($temp_file);
            exit;
        }
        else
        {
            echo '<div id="error">'.$lang['errorconnect'].'</div>';
        }
    }
}
if(empty($_REQUEST['mode']))
{
    header("Location: clients.php");
}
elseif($_REQUEST['mode'] == "addgame")
{
    $display->pagename = $lang['addagame'];
    if(empty($_REQUEST['uid']))
    {
        $display->clients = User::ListUsers(array("status" => "1"));
    }
    else
    {
        $display->uid = $_REQUEST['uid'];
        $display->email = User::UIDToUser($_REQUEST['uid']);
    }

    $display->games = Games::ListGames();

    $display->DisplayType("admin");
    $display->Output("admin/manageusergames/add-game.tpl");
}
elseif($_REQUEST['mode'] == "managegame")
{
    $display->pagename = $lang['managegameserver'];

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT *, usergames.fastdl as 'ugfastdl', games.addonmanager FROM `usergames` JOIN `games` ON usergames.gid=games.gid WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
    if($query && $query->num_rows == 1)
    {
        $rowgame = $query->fetch_assoc();
        if($rowgame['locked'] == "1")
        {
            $_SESSION['errormessage'] = $lang['lockedtask'];
            header("Location: index.php");
        }

        if($rowgame['maintenance'] == "1")
        {
            $display->errormessage = $lang['gamemaintenancemodeon'];
        }

        // Get the ip and port
        $rowgame['ip'] = Machines::GetIP($rowgame['ipid'], true);

        $display->sinfo = $rowgame;
        // Get the user information
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` JOIN `users_profile` ON users_profile.uid=users.uid WHERE userlevel=0 AND users.uid='%i' LIMIT 1", array($rowgame['uid'])));
        if($query && $query->num_rows == 1)
        {
            $rowuser = $query->fetch_assoc();
            $rowuser['password'] = User::GetPass($rowuser['uid']);
            $display->cinfo = $rowuser;
        }
        $querylogin = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `events` WHERE `type`='login' AND `userid`='%i' ORDER BY `time` DESC LIMIT 1", array($rowuser['uid'])));
        if($querylogin && $querylogin->num_rows == 1)
        {
            $rowlogin = $querylogin->fetch_assoc();
            $display->lastlogin = $rowlogin['time'];
        }

        // Get the config options
        $configoptions = array();
        $x = 0;
        $queryoptions = GSP::getInstance()->db->query(SafeSQL::query("SELECT ug.*, gc.name, gc.value as `options`, gc.fieldtype FROM `usergames_configoptions` as ug JOIN `games_configoptions` as gc ON ug.optionid=gc.optionid WHERE `ugid`=%i AND gc.type='' ORDER BY `order` ASC", array($_REQUEST['ugid'])));
        while($rowoptions = $queryoptions->fetch_assoc())
        {
            $configoptions[$x]['name'] = $rowoptions['name'];
            $configoptions[$x]['control'] = $rowoptions['control'];
            $configoptions[$x]['optionid'] = $rowoptions['optionid'];
            $configoptions[$x]['fieldtype'] = $rowoptions['fieldtype'];
            $configoptions[$x]['value'] = $rowoptions['value'];
            if($rowoptions['fieldtype'] == "selectbox")
            {
                $tempoptions = explode(",", $rowoptions['options']);
                foreach($tempoptions as $key => $val)
                {
                    if(strpos($val, "=") !== false)
                    {
                        $split = explode("=", $val);
                        $configoptions[$x]['options'][$key]['full'] = $val;
                        $configoptions[$x]['options'][$key]['value'] = $split[1];
                        $configoptions[$x]['options'][$key]['display'] = $split[0];
                    }
                    else
                    {
                        $configoptions[$x]['options'][$key]['full'] = $val;
                        $configoptions[$x]['options'][$key]['value'] = $val;
                        $configoptions[$x]['options'][$key]['display'] = $val;
                    }
                }
            }

            $x++;
        }

        // Replace default options that user might be missing
        $queryoptions = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_configoptions` WHERE `gid`='%i' AND `type`='' ORDER BY `order` ASC", array($rowgame['gid'])));
        while($rowoptions = $queryoptions->fetch_assoc())
        {
            if(Strings::search_array($rowoptions['name'], $configoptions, "name") == -1)
            {
                $configoptions[$x]['name'] = $rowoptions['name'];
                $configoptions[$x]['control'] = $rowoptions['control'];
                $configoptions[$x]['optionid'] = $rowoptions['optionid'];
                $configoptions[$x]['fieldtype'] = $rowoptions['fieldtype'];
                $configoptions[$x]['value'] = $rowoptions['value'];
                if($rowoptions['fieldtype'] == "selectbox")
                {
                    $tempoptions = explode(",", $rowoptions['value']);
                    foreach($tempoptions as $key => $val)
                    {
                        if(strpos($val, "=") !== false)
                        {
                            $split = explode("=", $val);
                            $configoptions[$x]['options'][$key]['full'] = $val;
                            $configoptions[$x]['options'][$key]['value'] = $split[1];
                            $configoptions[$x]['options'][$key]['display'] = $split[0];
                        }
                        else
                        {
                            $configoptions[$x]['options'][$key]['full'] = $val;
                            $configoptions[$x]['options'][$key]['value'] = $val;
                            $configoptions[$x]['options'][$key]['display'] = $val;
                        }
                    }
                }
                $x++;
            }
        }

        if(!empty($configoptions))
        {
            $display->configoptions = $configoptions;
        }

        // Get maxslots settings
        $maxslots = array();
        $queryslots = GSP::getInstance()->db->query(SafeSQL::query("SELECT ug.*, gc.name FROM `usergames_configoptions` as ug JOIN `games_configoptions` as gc ON ug.optionid=gc.optionid WHERE `ugid`=%i AND gc.type='maxslots' LIMIT 1", array($_REQUEST['ugid'])));
        if($queryslots && $queryslots->num_rows == 1)
        {
            $rowslots = $queryslots->fetch_assoc();
            $maxslots['name'] = $rowslots['name'];
            $maxslots['value'] = $rowslots['value'];

            $display->maxslots = $maxslots;
        }

        // Get the updates list->
        $display->updates = Games::ListUpdates($rowgame['gid']);

        // Get the QuickEdit list
        $quickedit = array();
        $x = 0;
        $queryquickedit = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_configs` WHERE `gid`='%i' AND `quickedit`='1'", array($rowgame['gid'])));
        while($rowquickedit = $queryquickedit->fetch_assoc())
        {
            $queryconfigs = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames_configs` WHERE `ugid`='%i' AND `cfid`='%i' LIMIT 1", array($rowgame['ugid'], $rowquickedit['cfid'])));
            if($queryconfigs && $queryconfigs->num_rows == 1)
            {
                $rowconfigs = $queryconfigs->fetch_assoc();
                if($rowconfigs['exist'] == "0")
                {
                    continue;
                }
            }
            $quickedit[$x] = $rowquickedit;
            $x++;
        }
        if(!empty($quickedit))
        {
            $display->quickedit = $quickedit;
        }

        $display->webftp = false;
        $display->ftp = false;
        $display->fastdl = false;


        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT ftpport, cpucores, httpport, main_ip, os, id, backupfile_location FROM `machines` JOIN `iplist` ON machines.id=iplist.sid WHERE iplist.ipid='%i' LIMIT 1", array($rowgame['ipid'])));
        if($query && $query->num_rows == 1)
        {
            $rowmachine = $query->fetch_assoc();
            $display->os = $rowmachine['os'];
            if($rowmachine['cpucores'] != "0" && !empty($rowmachine['cpucores']))
            {
                $x = 0;
                $affinity = array();
                $totalcores = $rowmachine['cpucores'] - 1;
                while($x <= $totalcores)
                {
                    $affinity[$x] = $x;
                    $x++;
                }
                $display->affinity = $affinity;
            }

            if($rowgame['ftp'] == "1" && !empty($rowmachine['ftpport']) && $rowmachine['ftpport'] != "0")
            {
                $display->ftp = true;
                $display->ftpip = $rowgame['ip'];
                $display->ftpport = $rowmachine['ftpport'];
                if(GSP::getInstance()->settings['webftp'] == "1")
                {
                    $display->webftp = true;
                }
            }
            if($rowgame['fastdl'] == "1" && !empty($rowmachine['httpport']) && $rowmachine['httpport'] != "0")
            {
                if($rowgame['ugfastdl'] == "1")
                {
                    $display->fastdlurl = "http://".$rowmachine['main_ip'].":".$rowmachine['httpport']."/".$rowgame['ip']."-".$rowgame['port_main'];
                }
                $display->fastdl = true;
            }
        }

        // Enable backup display if it's available
        $display->backups = false;
        if($rowgame['backups'] == "1" && !empty($rowmachine['backupfile_location']))
        {
            $display->backups = true;
            $backuplist = Backup::ListBackups(array("ugid" => $_REQUEST['ugid']));
            $display->backuplist = $backuplist['data'];
        }

        // Enable database display if it's available
        $display->database = false;
        if($rowgame['database_allowed'] == "1")
        {
            $getdbcredentials = DatabaseManagement::getUserInfoFromUGID($_REQUEST['ugid']);
            if($getdbcredentials['error'] == 0)
            {
                $display->dbuser = $getdbcredentials['user'];
                $display->dbpass = $getdbcredentials['password'];
            }
            $display->database_adminurl = $rowgame['database_adminurl'];
            $display->database = true;
            $databaselist = DatabaseManagement::ListDatabases(array("ugid" => $_REQUEST['ugid']));
            $display->databaselist = $databaselist;
        }

        // Get debugging info if main admin
        if($_SESSION['mainadmin'] == "1")
        {
            $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` JOIN `games` ON games.gid=usergames.gid  WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
            if($query && $query->num_rows == 1)
            {
                $row = $query->fetch_assoc();

                $serverinfo['ip'] = Machines::GetIP($row['ipid']);
                $serverinfo['port'] = $row['port_main'];
                $serverinfo['name'] = $row['name'];
                $serverinfo['ugid'] = $row['ugid'];
                $display->serverinfo = $serverinfo;

                // Get server info
                $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `machines` JOIN `iplist` ON machines.id=iplist.sid WHERE `ipid`='%i' LIMIT 1", array($row['ipid'])));
                if($query && $query->num_rows == 1)
                {
                    $rowserver = $query->fetch_assoc();
                }

                $display->debug['machine'] = $rowserver;

                // Windows
                if($rowserver['os'] == "1")
                {
                    if(!empty($row['windows_startmode']))
                    {
                        $results = Strings::GameReplaceVars(array(
                                    "ugid" => $row['ugid'],
                                    "content" => $row['windows_startmode']));
                        if($results['error'] == 0)
                        {
                            $startmode = $results['content'];
                        }
                    }
                    else
                    {
                        $startmode = "";
                    }

                    $username = "gsp_".$row['uid'];

                    $gamedir = $rowserver['userfile_location']."\\".$username."\\".$serverinfo['ip']."-".$row['port_main'];
                    $display->debug['dir'] = $gamedir;

                    $command[] = "cd ".$gamedir;
                    $command[] = $row['windows_exec']." ".$startmode;
                }
                else // Linux
                {
                    $homedir = $rowserver['userfile_location']."/gsp_".$row['uid'];
                    $usergamedir = $homedir."/".$serverinfo['ip']."-".$row['port_main'];
                    $display->debug['dir'] = $usergamedir;

                    $results = Strings::GameReplaceVars(array(
                                "ugid" => $row['ugid'],
                                "content" => $row['linux_startmode']));
                    if($results['error'] == 0)
                    {
                        $startmode = $results['content'];
                    }

                    $queryscript = GSP::getInstance()->db->query(SafeSQL::query("SELECT content FROM `games_scripts` WHERE `gid`=%i AND `os`='0' AND `legacy`='1' AND `event`='beforestart'", array($row['gid'])));
                    if($queryscript && $queryscript->num_rows > 0)
                    {
                        $rowscript = $queryscript->fetch_assoc();
                        if(!empty($rowscript['content']))
                        {
                            $results = Strings::GameReplaceVars(array(
                                        "ugid" => $row['ugid'],
                                        "content" => $rowscript['content']));
                            if($results['error'] == 0)
                            {
                                $premode = rtrim($results['content'], ";");
                            }
                        }
                    }

                    $command[] = "chsh -s /bin/bash gsp_".$row['uid'];
                    $command[] = "su gsp_".$row['uid'];
                    $command[] = "cd ".$usergamedir;
                    if(isset($premode))
                    {
                        $command[] = $premode;
                    }
                    $command[] = $startmode;
                    $display->debug['finishcommand'] = "chsh -s $(which nologin) gsp_".$row['uid'];
                }
            }
            $display->debug['command'] = $command;
        }

        $cronjobs = Cron::ListJobs(array("ugid" => $_REQUEST['ugid']));
        if($cronjobs['error'] == 0)
        {
            $display->cronjobs = $cronjobs['data'];
        }

        // assign the ugid variable
        $display->ugid = $rowgame['ugid'];

        // Get any news
        if($rowmachine['os'] == "1")
        {
            $gameos = "allwindows";
        }
        else
        {
            $gameos = "alllinux";
        }
        $querynews = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `news` WHERE 
            (`machine`='all' AND (`game`='all' OR `game`='".$gameos."' OR `game`='".$row['gid']."' OR `game`='')) 
            OR (`machine`='".$gameos."' AND (`game`='all' OR `game`='".$gameos."' OR `game`='".$row['gid']."' OR `game`='')) 
            OR (`machine`='' AND (`game`='all' OR `game`='".$gameos."' OR `game`='".$row['gid']."' OR `game`='')) 
            OR (`machine`='".$rowmachine['id']."' AND (`game`='all' OR `game`='".$gameos."' OR `game`='".$row['gid']."' OR `game`='')) 
            ORDER BY `datetime` DESC", array()));
        if($querynews && $querynews->num_rows > 0)
        {
            while($rownews = $querynews->fetch_assoc())
            {
                $news[] = $rownews;
            }
            $display->news = $news;
        }
    }
    else
    {
        $_SESSION['errormessage'] = $lang['nouserdatabase'];
        header("Location: index.php");
        exit();
    }

    $display->DisplayType("admin");
    $display->Output("admin/manageusergames/managegame.tpl");
}
elseif($_REQUEST['mode'] == "gameinfo")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` JOIN `games` ON usergames.gid=games.gid WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
    if($query && $query->num_rows == 1)
    {
        $rowgame = $query->fetch_assoc();

        // Get the ip and port
        $rowgame['ip'] = Machines::GetIP($rowgame['ipid'], true);

        if($rowgame['status'] == 1)
        {
            $results = Games::QueryGame(array('ugid' => $rowgame['ugid'], 'nomap' => false));
            if($results['error'] == 0)
            {
                if($results['status'] == 1)
                {
                    $rowgame['hostname'] = $results['hostname'];
                    $rowgame['map'] = $results['map'];
                    $rowgame['players'] = $results['active']."/".$results['total'];
                }
                else
                {
                    $rowgame['status'] = "3";
                }
            }
        }
        $querymachine = GSP::getInstance()->db->query(SafeSQL::query("SELECT machines.alias FROM `iplist` JOIN `machines` ON machines.id=iplist.sid WHERE `ipid`='%i'", array($rowgame['ipid'])));
        $resultmachine = $querymachine->fetch_assoc();
        $rowgame['machinealias'] = $resultmachine['alias'];

        // Get the disk usage
        if(isset($rowgame['alertdiskusage']) && !empty($rowgame['alertdiskusage']))
        {
            if(isset($rowgame['size']) && !empty($rowgame['size']))
            {
                $rowgame['diskusage'] = Strings::ByteSize($rowgame['size'])." / ".Strings::ByteSize($rowgame['alertdiskusage']);
            }
            else
            {
                $rowgame['diskusage'] = $lang['unknown']."/".Strings::ByteSize($rowgame['alertdiskusage']);
            }
        }
        else
        {
            $rowgame['diskusage'] = "N/A";
        }

        $display->sinfo = $rowgame;

        // Get maxslots settings
        $maxslots = array();
        $queryslots = GSP::getInstance()->db->query(SafeSQL::query("SELECT ug.*, gc.name FROM `usergames_configoptions` as ug JOIN `games_configoptions` as gc ON ug.optionid=gc.optionid WHERE `ugid`=%i AND gc.type='maxslots' LIMIT 1", array($_REQUEST['ugid'])));
        if($queryslots && $queryslots->num_rows == 1)
        {
            $rowslots = $queryslots->fetch_assoc();
            $maxslots['name'] = $rowslots['name'];
            $maxslots['value'] = $rowslots['value'];

            $display->maxslots = $maxslots;
        }

        // assign the ugid variable
        $display->ugid = $rowgame['ugid'];
    }

    $display->DisplayType("ajax");
    $display->Output("admin/manageusergames/managegame-info.tpl");
}
elseif($_REQUEST['mode'] == "gameoptions")
{
    if(!empty($_REQUEST['gid']))
    {
        $querygame = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games` WHERE `gid`=%i LIMIT 1", array($_REQUEST['gid'])));
        if($querygame && $querygame->num_rows == 1)
        {
            $serverlist = Machines::GameLocationIPList(array("gid" => $_REQUEST['gid'], "iplist" => false));
            if(!empty($serverlist))
            {
                $display->machines = $serverlist;
            }
        }
    }
    elseif(!empty($_REQUEST['ugid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            $serverlist = Machines::GameLocationIPList(array("gid" => $_REQUEST['gid'], "iplist" => false, "currentip" => $row['ipid']));
            if(!empty($serverlist))
            {
                $display->machines = $serverlist;
            }
        }
    }

    $querygame = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games` WHERE `gid`=%i LIMIT 1", array($_REQUEST['gid'])));
    if($querygame && $querygame->num_rows == 1)
    {
        $configoptions = array();
        $rowgame = $querygame->fetch_assoc();
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_configoptions` WHERE `gid`=%i AND `type`=''", array($_REQUEST['gid'])));
        if($query && $query->num_rows > 0)
        {
            $x = 0;
            while($row = $query->fetch_assoc())
            {
                $configoptions[$x] = $row;
                if($row['fieldtype'] == "selectbox")
                {
                    $tempoptions = explode(",", $row['value']);
                    foreach($tempoptions as $key => $val)
                    {
                        if(strpos($val, "=") !== false)
                        {
                            $split = explode("=", $val);
                            $configoptions[$x]['options'][$key]['full'] = $val;
                            $configoptions[$x]['options'][$key]['value'] = $split[1];
                            $configoptions[$x]['options'][$key]['display'] = $split[0];
                        }
                        else
                        {
                            $configoptions[$x]['options'][$key]['full'] = $val;
                            $configoptions[$x]['options'][$key]['value'] = $val;
                            $configoptions[$x]['options'][$key]['display'] = $val;
                        }
                    }
                }
                $x++;
            }
            if(count($configoptions) > 0)
            {
                $display->configoptions = $configoptions;
            }
        }
        $maxslots = array();
        $queryslots = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_configoptions` WHERE `gid`=%i AND `type`='maxslots' LIMIT 1", array($_REQUEST['gid'])));
        if($queryslots && $queryslots->num_rows == 1)
        {
            $rowslots = $queryslots->fetch_assoc();
            $maxslots['name'] = $rowslots['name'];
            $maxslots['value'] = $rowslots['value'];

            $display->maxslots = $maxslots;
        }
    }
    $display->fastdl = false;
    if($rowgame['fastdl'] == "1")
    {
        $display->fastdl = true;
    }
    $display->DisplayType("ajax");
    $display->Output("admin/manageusergames/ajax-gameoptions.tpl");
}
elseif($_REQUEST['mode'] == "moveserver")
{
    $display->pagename = $lang['moveserver'];
    if(!empty($_REQUEST['ugid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` JOIN `games` ON games.gid=usergames.gid  WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();

            $serverinfo['ip'] = Machines::GetIP($row['ipid']);
            $serverinfo['port'] = $row['port_main'];
            $serverinfo['name'] = $row['name'];
            $serverinfo['ugid'] = $row['ugid'];
            $display->serverinfo = $serverinfo;

            $serverlist = Machines::GameLocationIPList(array("gid" => $row['gid'], "iplist" => true, "currentip" => $row['ipid'], "dedicatedip" => $row['dedicatedip']));
            $display->machines = $serverlist;

            $display->DisplayType("admin");
            $display->Output("admin/manageusergames/moveserver.tpl");
        }
        else
        {
            $_SESSION['errormessage'] = $lang['gamenotfound'];
            header("Location: index.php");
        }
    }
    else
    {
        $_SESSION['errormessage'] = $lang['gamenotfound'];
        header("Location: index.php");
    }
}
elseif($_REQUEST['mode'] == "installgame")
{
    $results = Games::InstallToUser(array("ugid" => $_REQUEST['ugid'], "email" => true));
    if($results['error'] == 0)
    {
        echo $lang['installing'];
    }
    elseif($results['error'] == -4)
    {
        echo $lang['errorinstalling'];
    }
    elseif($results['error'] == -5)
    {
        echo $lang['serverofflinesh'];
    }
    exit();
}
elseif($_REQUEST['mode'] == "viewconsole")
{
    $results = Games::GetGameConsole($_REQUEST['ugid']);

    if($results['error'] == 0)
    {
        echo str_replace('&#10;', '<br />', Strings::filter($results['data'], 'special'));
    }
    elseif($results['error'] == -1)
    {
        echo $lang['nousergameid'];
    }
    elseif($results['error'] == -2)
    {
        echo $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -3)
    {
        echo $lang['serverofflinesh'];
    }
    elseif($results['error'] == -4)
    {
        echo $lang['consoledisabled'];
    }
}
elseif($_REQUEST['mode'] == "start")
{
    $results = Games::ControlGame(array("ugid" => $_REQUEST['ugid'], "action" => "start"));
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['serverstarted'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['missinginformation'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['unablecompleteaction'];
    }
    elseif($results['error'] == -4)
    {
        $_SESSION['errormessage'] = $lang['cannotstartsuspended'];
    }
    elseif($results['error'] == -5)
    {
        $_SESSION['errormessage'] = $lang['lockedtask'];
    }
}
elseif($_REQUEST['mode'] == "stop")
{
    $results = Games::ControlGame(array("ugid" => $_REQUEST['ugid'], "action" => "stop"));
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['serverstopped'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['missinginformation'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['unablecompleteaction'];
    }
    elseif($results['error'] == -5)
    {
        $_SESSION['errormessage'] = $lang['lockedtask'];
    }
}
elseif($_REQUEST['mode'] == "restart")
{
    $results = Games::ControlGame(array("ugid" => $_REQUEST['ugid'], "action" => "restart"));
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['serverrestarted'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['missinginformation'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['unablecompleteaction'];
    }
    elseif($results['error'] == -4)
    {
        $_SESSION['errormessage'] = $lang['cannotstartsuspended'];
    }
    elseif($results['error'] == -5)
    {
        $_SESSION['errormessage'] = $lang['lockedtask'];
    }
}
elseif($_REQUEST['mode'] == "delete")
{
    if(isset($_REQUEST['forceremove']))
    {
        $forceremove = true;
    }
    else
    {
        $forceremove = false;
    }
    $results = Games::DeleteFromUser($_REQUEST['ugid'], true, $forceremove);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['serverdeleted'];
        exit("clients.php");
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['unableremovegameoffline']." <a class='delete' href='manageusergames.php?mode=delete&ugid=".$_REQUEST['ugid']."&forceremove=true'>".$lang['clickforceremove']."</a>";
    }
    elseif($results['error'] == -4)
    {
        $_SESSION['errormessage'] = $lang['unablecompleteaction'];
    }
    exit("manageusergames.php?mode=managegame&ugid=".$_REQUEST['ugid']);
}
elseif($_REQUEST['mode'] == "reinstall")
{
    $results = Games::DeleteFromUser($_REQUEST['ugid'], false);
    if($results['error'] == 0 || $results['error'] == -4)
    {
        if($results['error'] == -4)
        {
            $deletefailed = true;
        }
        else
        {
            $deletefailed = false;
        }
        $results = Games::InstallToUser(array("ugid" => $_REQUEST['ugid'], "email" => false));
        if($results['error'] == 0)
        {
            if($deletefailed == true)
            {
                $_SESSION['goodmessage'] = $lang['unableremovereinstall'];
            }
            else
            {
                $_SESSION['goodmessage'] = $lang['serverreinstalling'];
            }
        }
        elseif($results['error'] == -1)
        {
            $_SESSION['errormessage'] = $lang['nogameid'];
        }
        elseif($results['error'] == -2)
        {
            $_SESSION['errormessage'] = $lang['gamenotindatabase'];
        }
        elseif($results['error'] == -3)
        {
            $_SESSION['errormessage'] = $lang['gamenotonserver'];
        }
        elseif($results['error'] == -4)
        {
            $_SESSION['errormessage'] = $lang['cannotinstall'];
        }
        elseif($results['error'] == -5)
        {
            $_SESSION['errormessage'] = $lang['reinstalloffline'];
        }
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['reinstalloffline'];
    }
    exit("manageusergames.php?mode=managegame&ugid=".$_REQUEST['ugid']);
}
elseif($_REQUEST['mode'] == "suspendgame")
{
    $results = Games::SuspendServer($_REQUEST['ugid']);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['serversuspended'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
}
elseif($_REQUEST['mode'] == "unsuspendgame")
{
    $results = Games::UnsuspendServer($_REQUEST['ugid']);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['serverunsuspended'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
}
elseif($_REQUEST['mode'] == "enablemaintenance")
{
    $results = Games::EnableMaintenance($_REQUEST['ugid']);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['maintenanceenabled'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
}
elseif($_REQUEST['mode'] == "disablemaintenance")
{
    $results = Games::DisableMaintenance($_REQUEST['ugid']);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['maintenancedisabled'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }

    header("Location: manageusergames.php?mode=managegame&ugid=".$_REQUEST['ugid']);
    exit();
}
elseif($_REQUEST['mode'] == "installaddon")
{
    $results = Games::InstallAddon($_REQUEST['ugid'], $_REQUEST['addonid']);
    if($results['error'] == 0)
    {
        if(!empty($results['message']))
        {
            $_SESSION['goodmessage'] = $results['message'];
        }
        else
        {
            $_SESSION['goodmessage'] = $lang['addoninstalled'];
        }
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['noaddonid'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -4)
    {
        $_SESSION['errormessage'] = $lang['addonnotfound'];
    }
    elseif($results['error'] == -5)
    {
        $_SESSION['errormessage'] = $lang['addonnotforos'];
    }
    elseif($results['error'] == -6)
    {
        $_SESSION['errormessage'] = $lang['usersnotinstalled'];
    }
    elseif($results['error'] == -7)
    {
        $_SESSION['errormessage'] = $lang['addoncannotinstall'];
    }
}
elseif($_REQUEST['mode'] == "installupdate")
{
    $results = Games::InstallUpdate($_REQUEST['ugid'], $_REQUEST['updateid']);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['updatestarted'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nogameid'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['noupdateid'];
    }
    elseif($results['error'] == -3)
    {
        $_SESSION['errormessage'] = $lang['gamenotindatabase'];
    }
    elseif($results['error'] == -4)
    {
        $_SESSION['errormessage'] = $lang['updatenotfound'];
    }
    elseif($results['error'] == -5)
    {
        $_SESSION['errormessage'] = $lang['updatenotforos'];
    }
    elseif($results['error'] == -6)
    {
        $_SESSION['errormessage'] = $lang['usersnotinstalled'];
    }
    exit();
}
elseif($_REQUEST['mode'] == "graphs")
{
    if(!empty($_REQUEST['ugid']))
    {
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` JOIN `games` ON usergames.gid=games.gid WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
        if($query && $query->num_rows == 1)
        {
            $rowgame = $query->fetch_assoc();
            $display->graphs = $rowgame['graphs'];
        }
        $display->ugid = $_REQUEST['ugid'];
        $display->DisplayType("ajax");
        $display->Output("admin/manageusergames/graphs.tpl");
    }
}
elseif($_REQUEST['mode'] == "backup")
{
    $results = Backup::CreateBackup(array("ugid" => $_REQUEST['ugid']));
    if($results['error'] == 0)
    {
        echo '<div id="good">'.$lang['backupstarted'].'</div>';
    }
    elseif($results['error'] == -1)
    {
        echo '<div id="error">'.$lang['nogameid'].'</div>';
    }
    elseif($results['error'] == -2)
    {
        echo '<div id="error">'.$lang['gamenotindatabase'].'</div>';
    }
    elseif($results['error'] == -3)
    {
        echo '<div id="error">'.$lang['usersnotinstalled'].'</div>';
    }
    elseif($results['error'] == -4)
    {
        echo '<div id="error">'.$lang['backupalreadyprogress'].'</div>';
    }
    elseif($results['error'] == -5)
    {
        echo '<div id="error">'.$lang['errorconnecting'].'</div>';
    }
    elseif($results['error'] == -6)
    {
        echo '<div id="error">'.$lang['backupsnotenabled'].'</div>';
    }
    elseif($results['error'] == -7)
    {
        echo '<div id="error">'.$lang['backupsexceedlimit'].'</div>';
    }
}
elseif($_REQUEST['mode'] == "deletebackup")
{
    $results = Backup::DeleteBackup($_REQUEST['backupid']);
    if($results['error'] == 0)
    {
        echo '<div id="good">'.$lang['backupdeleted'].'</div>';
    }
    elseif($results['error'] == -1)
    {
        echo '<div id="error">'.$lang['backupnotfound'].'</div>';
    }
    elseif($results['error'] == -2)
    {
        echo '<div id="error">'.$lang['backupnotfound'].'</div>';
    }
    elseif($results['error'] == -3)
    {
        echo '<div id="error">'.$lang['backupinprogress'].'</div>';
    }
}
elseif($_REQUEST['mode'] == "restorebackup")
{
    $results = Backup::RestoreBackup($_REQUEST['backupid']);
    if($results['error'] == 0)
    {
        echo '<div id="good">'.$lang['backupbeingrestored'].'</div>';
    }
    elseif($results['error'] == -1)
    {
        echo '<div id="error">'.$lang['backupnotfound'].'</div>';
    }
    elseif($results['error'] == -2)
    {
        echo '<div id="error">'.$lang['backupnotfound'].'</div>';
    }
    elseif($results['error'] == -3)
    {
        echo '<div id="error">'.$lang['backupinprogress'].'</div>';
    }
    elseif($results['error'] == -3)
    {
        echo '<div id="error">'.$lang['lockedtask'].'</div>';
    }
}
elseif($_REQUEST['mode'] == "viewbackups")
{
    $backuplist = Backup::ListBackups(array("ugid" => $_REQUEST['ugid']));
    $display->backuplist = $backuplist['data'];

    $display->DisplayType("ajax");
    $display->Output("admin/manageusergames/ajax-backups.tpl");
}
elseif($_REQUEST['mode'] == "deletedatabase")
{
    $results = DatabaseManagement::Remove($_REQUEST['ugid'], $_REQUEST['dbname']);
    if($results['error'] == 0)
    {
        echo '<div id="good">'.$lang['databasedeleted'].'</div>';
    }
    elseif($results['error'] == -1)
    {
        echo '<div id="error">'.$lang['missinginformation'].'</div>';
    }
    elseif($results['error'] == -2)
    {
        echo '<div id="error">'.$lang['databasenotfound'].'</div>';
    }
    elseif($results['error'] == -3)
    {
        echo '<div id="error">'.$lang['databasenotfound'].' - '.$results['errordetails'].'</div>';
    }
}
elseif($_REQUEST['mode'] == "viewdatabases")
{
    $display->databaselist = DatabaseManagement::ListDatabases(array("ugid" => $_REQUEST['ugid']));
    $display->ugid = $_REQUEST['ugid'];

    // Get the phpMyAdmin URL
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT database_adminurl FROM games JOIN usergames ON games.gid=usergames.gid WHERE ugid=%i", array($_REQUEST['ugid'])));
    if($query)
    {
        $row = $query->fetch_assoc();
        $display->database_adminurl = $row['database_adminurl']; 
    }

    $display->DisplayType("ajax");
    $display->Output("admin/manageusergames/ajax-databases.tpl");
}
elseif($_REQUEST['mode'] == "getconfig")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
    $row = $query->fetch_assoc();

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games_configs` WHERE `gid`=%i AND `cfid`=%i LIMIT 1", array($row['gid'], $_REQUEST['configid'])));
    $rowconfig = $query->fetch_assoc();

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `games` WHERE `gid`=%i LIMIT 1", array($row['gid'])));
    $rowgame = $query->fetch_assoc();

    // Connect to the FTP
    $ftp = new ftp($_REQUEST['ugid']);
    if($ftp->loggedOn)
    {
        $ftp->setResumeDownload(false);
        $ftp->setCurrentDir($ftp->userDir);
        $ftp->setMode(1);

        $temp_file = tempnam($ftp->downloadDir, 'gsp');

        if(!empty($rowgame['redirectfolder']))
        {
            $rowconfig['directory'] = str_replace($rowgame['redirectfolder'], "", $rowconfig['directory']);
        }

        $rowconfig['directory'] = ltrim($rowconfig['directory'], "/");
        $ftp->setCurrentDir($rowconfig['directory']);

        if($ftp->get($rowconfig['filename'], $temp_file))
        {
            $content = file_get_contents($temp_file);
            //  $content = stripslashes(htmlspecialchars($content, ENT_QUOTES));
            //  $content = trim($content);
            $content = str_replace("\r\n", "\n", $content);
            $display->ftpmode = $ftp->mode;
            $display->content = $content;
            $display->ugid = $_REQUEST['ugid'];
            $display->configid = $_REQUEST['configid'];
            $display->Output("admin/manageusergames/quickedit.tpl");
            unlink($temp_file);
            exit;
        }
        else
        {
            echo '<div id="error">'.$lang['errordownloading'].'</div>';
        }
    }
    else
    {
        echo '<div id="error">'.$lang['errorconnect'].'</div>';
    }
}
elseif($_REQUEST['mode'] == "checkport")
{
    if($_REQUEST['port'] == "0")
    {
        echo "valid";
    }
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `ugid`=%i", array($_REQUEST['ugid'])));
    $row = $query->fetch_assoc();

    if(in_array($_REQUEST['port'], array($row['port_main'], $row['port_query'], $row['port_rcon'], $row['port_custom1'], $row['port_custom2'], $row['port_custom3'], $row['port_custom4'])))
    {
        echo "alreadyused";
        exit();
    }

    if(Machines::isPortUsed($row['ipid'], $_REQUEST['port']))
    {
        echo "error";
    }
    else
    {
        echo "valid";
    }
}
elseif($_REQUEST['mode'] == "deletecron")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `scheduler` WHERE `id`='%i' AND `ugid`='%i' LIMIT 1", array($_REQUEST['cronid'], $_REQUEST['ugid'])));
    if($query && $query->num_rows == 1)
    {
        $return = Cron::Remove($_REQUEST['cronid']);
        if($return['error'] == -1)
        {
            echo '<div id="error">'.$lang['notaskspecified'].'</div>';
        }
        else
        {
            echo '<div id="good">'.$lang['scheduledtaskdeleted'].'</div>';
        }
    }
    exit();
}
elseif($_REQUEST['mode'] == "viewcrons")
{
    $cronjobs = Cron::ListJobs(array("ugid" => $_REQUEST['ugid']));
    if($cronjobs['error'] == 0)
    {
        $display->cronjobs = $cronjobs['data'];
    }

    $display->DisplayType("ajax");
    $display->Output("admin/manageusergames/ajax-cron.tpl");
}
elseif($_REQUEST['mode'] == "listaddons")
{
    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT usergames.gid, games.addonmanager FROM `usergames` JOIN `games` ON usergames.gid=games.gid WHERE `ugid`=%i LIMIT 1", array($_REQUEST['ugid'])));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        if(!empty($row['addonmanager']) && $row['addonmanager'] != "stock")
        {
            Plugins::getInstance()->triggerPluginEvent($row['addonmanager'], "displayaddons", $row['gid']);
        }
        else
        {
            $display->addons = Games::ListAddons($row['gid']);
            $display->DisplayType("ajax");
            $display->Output("admin/manageusergames/ajax-addonlist.tpl");
        }
    }
}
elseif($_REQUEST['mode'] == "unlock")
{
    $result = Games::UnlockGame($_REQUEST['ugid']);
    if($result['error'] == 0 || $result['error'] == -3)
    {
        $_SESSION['goodmessage'] = $lang['gameserverunlocked'];
    }
    header("Location: manageusergames.php?mode=managegame&ugid=".$_REQUEST['ugid']);
}
?>