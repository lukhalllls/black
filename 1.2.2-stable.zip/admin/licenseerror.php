<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{GSP, SafeSQL};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    die("This feature is disabled in demo mode");
}

if($_REQUEST['action'] == "refresh")
{
    $_SESSION['checkedforupdate'] = true;
    GSP::getInstance()->db->query("UPDATE `settings` SET `value`='' WHERE `name`='licensekeycache' LIMIT 1");
    $_SESSION['goodmessage'] = $lang['keyrefreshed'];
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if($_REQUEST['action'] == "change" && $_SESSION['mainadmin'] == "1")
    {
        GSP::getInstance()->db->query("UPDATE `settings` SET `value`='' WHERE `name`='licensekeycache' LIMIT 1");
        GSP::getInstance()->db->query(SafeSQL::query("UPDATE `settings` SET `value`='%s' WHERE `name`='licensekey' LIMIT 1", array($_POST['licensekey'])));
        $_SESSION['goodmessage'] = $lang['keychanged'];
        header("Location: index.php");
        exit();
    }
}

$display->pagename = $lang['license'];
$display->DisplayType("admin");

if(!empty($_SESSION['licerrormessage']))
{
    $display->error = $_SESSION['licerrormessage'];
    $_SESSION['licerrormessage'] = "";
    $display->AddDisplay("admin/licenseerror/error.tpl");
}

if($_REQUEST['action'] == "change" && $_SESSION['mainadmin'] == "1")
{
    $display->AddDisplay("admin/licenseerror/change.tpl");
}
elseif($_REQUEST['action'] == "info" && $_SESSION['mainadmin'] == "1")
{
    $display->releasetype = GSP::getInstance()->GetReleaseType();
    $display->maxservices = GSP::getInstance()->GetAllowedGameServers();
    $display->maxservers = GSP::getInstance()->GetAllowedServers();
    $display->AddDisplay("admin/licenseerror/info.tpl");
   
}
$display->Output();
?>
