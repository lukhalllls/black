<?php
require_once("../includes/gsp-panel.php");

if(!isset($_REQUEST['module']) || empty($_REQUEST['module']))
{
    $_SESSION['errormessage'] = $lang['noutilspecified'];
    header("Location: index.php");
    exit();
}

if(!file_exists("utilities/".$_REQUEST['module'].".php"))
{
    $_SESSION['errormessage'] = $lang['utilnotexist'];
    header("Location: index.php");
    exit();
}
else
{
    require("utilities/".$_REQUEST['module'].".php");
}

?>