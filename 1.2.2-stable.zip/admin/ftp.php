<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\{GSP, SafeSQL, Strings, ftp};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    die("This feature is disabled in demo mode");
}

if(GSP::getInstance()->settings['webftp'] == false)
{
    echo '<div id="error">'.$lang['webftpdisabled'].'</div>';
    exit();
}

if(empty($_REQUEST['ugid']))
{
    echo '<div id="error">'.$lang['noftpperm'].'</div>';
    exit();
}

$query = GSP::getInstance()->db->query(SafeSQL::query("SELECT ftp FROM `games` JOIN `usergames` ON games.gid=usergames.gid WHERE usergames.ugid=%i LIMIT 1", array($_REQUEST['ugid'])));
if($query && $query->num_rows == 1)
{
    $row = $query->fetch_assoc();
    if($row['ftp'] == "0")
    {
        echo '<div id="error">'.$lang['nogameftp'].'</div>';
        exit();
    }
}
else
{
    echo '<div id="error">'.$lang['invalidgameserver'].'</div>';
    exit();
}

if(!isset($_REQUEST['mode']))
{
    $_REQUEST['mode'] = $ftp->mode;
}

if(isset($_REQUEST['currentDir']))
{
    $_REQUEST['currentDir'] = $_REQUEST['currentDir'];
}
else
{
    $_REQUEST['currentDir'] = "";
}

// Connect to the FTP and set the active/pasv mode
$ftp = new ftp($_REQUEST['ugid']);
$ftp->setMode($_REQUEST['mode']);

// Change into the servers directory
if(!isset($_REQUEST['currentDir']))
{
    $ftp->setCurrentDir($ftp->userDir);

    if($ftp->currentDir == "/")
    {
        echo '<div id="error">'.$lang['nohome'].'</div>';
        exit();
    }
}
else
{
    $ftp->setCurrentDir($_REQUEST['currentDir']);
    if($ftp->currentDir == "/")
    {
        $ftp->setCurrentDir($ftp->userDir);
    }
}

if($ftp->currentDir == "/")
{
    echo '<div id="error">'.$lang['nohome'].'</div>';
    exit();
}

// Set some default values
$ftp->setResumeDownload(false);
//$ftp->setDownloadDir($path."/templates_c/");


if($ftp->loggedOn)
{
    if(isset($_REQUEST['actionType']))
    {
        if($_REQUEST['actionType'] == "upload")
        {
            $smarty->assign("currentdir", $ftp->currentDir);
            $smarty->assign("user", $ftp->user);
            $smarty->assign("password", $ftp->password);
            $smarty->assign("server", $ftp->server);
            $smarty->assign("port", $ftp->port);
            $smarty->display("common/ftp/upload.tpl");
            exit();
        }
        elseif($_REQUEST['actionType'] == "changemode")
        {
            $ftp->setMode($_REQUEST['mode']);
            echo '<div id="good">'.$lang['modechanged'].'</div>';
        }
        elseif($_REQUEST['actionType'] == "cd")
        {
            if(!$ftp->cd($_REQUEST['file']))
            {
                echo '<div id="error">'.$lang['errorcd'].'</div>';
            }
        }
        elseif($_REQUEST['actionType'] == "get")
        {
            $ftp->download($_REQUEST['file']) or die("Unable to download the file");
        }
        elseif($_REQUEST['actionType'] == "deldir")
        {
            if($ftp->deleteDir($_REQUEST['file']))
            {
                echo '<div id="good">'.$_REQUEST['file'].' '.$lang['wasdeleted'].'</div>';
            }
            else
            {
                echo '<div id="error">'.$lang['unabletodelete'].' '.$_REQUEST['file'].'</div>';
            }
        }
        elseif($_REQUEST['actionType'] == "delfile")
        {
            if($ftp->deleteFile($_REQUEST['file']))
            {
                echo '<div id="good">'.$_REQUEST['file'].' '.$lang['wasdeleted'].'</div>';
            }
            else
            {
                echo '<div id="error">'.$lang['unabletodelete'].' '.$_REQUEST['file'].'</div>';
            }
        }
        elseif($_REQUEST['actionType'] == "rename")
        {
            if($ftp->rename($_REQUEST['file'], $_REQUEST['file2']))
            {
                echo '<div id="good">'.$_REQUEST['file'].' '.$lang['to'].' '.$_REQUEST['file2'].'</div>';
            }
            else
            {
                echo '<div id="error">'.$lang['errorrename'].' '.$_REQUEST['file'].' '.$lang['to'].' '.$_REQUEST['file2'].'</div>';
            }
        }
        elseif($_REQUEST['actionType'] == "createdir")
        {
            if($ftp->makeDir($_REQUEST['file']))
            {
                echo '<div id="good">'.$_REQUEST['file'].' '.$lang['dircreated'].'</div>';
            }
            else
            {
                echo '<div id="error">'.$lang['errordircreate'].' '.$_REQUEST['file'].'</div>';
            }
        }
        elseif($_REQUEST['actionType'] == "edit")
        {
            //First download the file to the server
            $temp_file = tempnam($ftp->downloadDir, 'gsp');
            if($ftp->get($_REQUEST['file'], $temp_file) === true)
            {
                $content = file_get_contents($temp_file);
                $content = htmlspecialchars($content, ENT_QUOTES);
                $content = trim($content);
                $content = str_replace("\r\n", "\n", $content);
                $smarty->assign("currentdir", $ftp->currentDir);
                $smarty->assign("ftpmode", $ftp->mode);
                $smarty->assign("content", $content);
                $smarty->assign("file", $_REQUEST['file']);
                $smarty->assign("ugid", $_REQUEST['ugid']);
                $smarty->display("common/ftp/edit.tpl");
            }
            else
            {
                die("Unable to download");
            }
            unlink($temp_file);
            exit();
        }
        elseif($_REQUEST['actionType'] == "saveFile")
        {
            //Write content of fileContent to tempFile
            $_REQUEST['fileContent'] = $_REQUEST['fileContent'];
            $temp_file = tempnam($ftp->downloadDir, 'gsp');
            $fp = fopen($temp_file, "w+t");
            if($bytes = !fwrite($fp, $_REQUEST['fileContent'], strlen($_REQUEST['fileContent'])))
            {
                echo '<div id="error">'.$lang['errorupload'].'</div>';
            }
            else
            {
                //Upload the file to the server
                if(!$ftp->put($ftp->currentDir."/".$ftp->filePart($_REQUEST['file']), $temp_file))
                {
                    echo '<div id="error">'.$lang['errorupload'].'</div>';
                }
                else
                {
                    echo '<div id="good">'.$lang['filesaved'].'</div>';
                }
            }
            unlink($temp_file);
            fclose($fp);
            exit();
        }
    }

    if($ftp->mode == FTP_ASCII)
    {
        $newMode = FTP_BINARY;
    }
    else
    {
        $newMode = FTP_ASCII;
    }

    $smarty->assign("newMode", $newMode);
  //  $smarty->assign("dirpath", $ftp->directoryPath($ftp->currentDir, $ftp->server));
    $smarty->assign("currentdir", $ftp->currentDir);
    $smarty->assign("ftpmode", $ftp->mode);
    $smarty->assign("server", $ftp->server);
    $smarty->assign("port", $ftp->port);
    $smarty->assign("systype", $ftp->systype);
    $smarty->assign("file", $_REQUEST['file']);
    $smarty->assign("ugid", $_REQUEST['ugid']);

    $ftplist = $ftp->ftpRawList();

    if(!empty(GSP::getInstance()->settings['webftpeditable']))
    {
        $editableext = str_replace(" ", "", GSP::getInstance()->settings['webftpeditable']);
        $editableext = explode(",", $editableext);
    }
    else
    {
        $editableext = array();
    }

    if(is_array($ftplist))
    {
        $filelist = array();
        $x = 0;
        // Directories
        foreach($ftplist as $file)
        {
            if(Strings::CheckBlacklist("file", $file["name"]) == false)
            {
                $filelist[$x] = $file;
                if($file["is_dir"] == 1)
                {
                    $filelist[$x]['fileAction'] = "cd";
                    $filelist[$x]['fileName'] = $file["name"];
                    $filelist[$x]['fileSize'] = "";
                    $filelist[$x]['delAction'] = "deldir";
                    $filelist[$x]['description'] = 'Folder';
                    $filelist[$x]['imgfilename'] = 'fa-folder';
                }
                elseif($file["is_link"] == 1)
                {
                    $filelist[$x]['fileAction'] = "cd";
                    $filelist[$x]['fileName'] = $file["target"];
                    $filelist[$x]['fileSize'] = "";
                    $filelist[$x]['delAction'] = "delfile";
                    $filelist[$x]['description'] = 'Symbolic Link';
                    $filelist[$x]['imgfilename'] = 'fa-link';
                }
                elseif($file["is_link"] != 1 && $file["is_dir"] != 1)
                {
                    $filelist[$x]['imgfilename'] = "fa-file";
                    $filelist[$x]['fileName'] = $file["name"];
                    $filedesc = $ftp->fileDescription($file["name"]);
                    if(in_array($filedesc['ext'], $editableext))
                    {
                        $filelist[$x]['fileAction'] = "edit";
                    }
                    else
                    {
                        $filelist[$x]['fileAction'] = "get";
                    }
                    $filelist[$x]['description'] = $filedesc["description"];

                    $filelist[$x]['fileSize'] = Strings::ByteSize($file['size']);

                    $filelist[$x]['delAction'] = "delfile";
                }
                $x++;
            }
        }
        $smarty->assign("filelist", $filelist);
    }
    $smarty->display("common/ftp/main.tpl");
}
else
{
    echo '<div id="error">'.$lang['errorconnect'].'</div>';
    exit();
}
?>
