<?php

require_once("../includes/gsp-panel.php");

use GSPPanel\User;

if($_SESSION['mainadmin'] != "1")
{
    $_SESSION['errormessage'] = $lang['nopermission'];
    header("Location: index.php");
    exit();
}

// Check if demo mode is enabled
if(defined("DEMO"))
{
    if($_SERVER['REQUEST_METHOD'] == 'POST' || $_REQUEST['mode'] == "delete")
    {
        die("This feature is disabled in demo mode");
    }
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    /*
     * Save edit
     */
    if($_REQUEST['mode'] == "edit")
    {
        $params = array('perms' => $_REQUEST['perm'],
            'mainadmin' => $_REQUEST['mainadmin'],
            'email' => $_REQUEST['email'],
            'password' => $_REQUEST['password'],
            'uid' => $_REQUEST['uid'],
            'perm' => $_REQUEST['perms'],
            'status' => $_REQUEST['status'],
            'allowedips' => $_REQUEST['allowedips'],
            'servermon_emails' => $_REQUEST['servermon_emails']);
        $returnval = User::EditAdmin($params);
        if($returnval['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['usersaved'];
            header("Location: administrators.php");
            exit();
        }
        elseif($returnval['error'] == -1)
        {
            $error = $lang['nouserspecified'];
        }
        elseif($returnval['error'] == -2)
        {
            $error = $lang['novalidemail'];
        }
        elseif($returnval['error'] == -3)
        {
            $error = $lang['mainprivledges'];
        }
        elseif($returnval['error'] == -4)
        {
            $error = $lang['invalidemail'];
        }
        elseif($returnval['error'] == -5)
        {
            $error = $lang['usernotexist'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
    
    /*
     * Save add
     */
    elseif($_REQUEST['mode'] == "add")
    {
        $params = array('perms' => $_REQUEST['perm'],
            'mainadmin' => $_REQUEST['mainadmin'],
            'email' => $_REQUEST['email'],
            'password' => $_REQUEST['password'],
            'perm' => $_REQUEST['perms'],
            'status' => $_REQUEST['status'],
            'allowedips' => $_REQUEST['allowedips'],
            'servermon_emails' => $_REQUEST['servermon_emails']);
        $returnval = User::AddAdmin($params);
        if($returnval['error'] == 0)
        {
            $_SESSION['goodmessage'] = $lang['useradded'];
            header("Location: administrators.php");
            exit();
        }
        elseif($returnval['error'] == -1)
        {
            $error = $lang['novalidemail'];
        }
        elseif($returnval['error'] == -2)
        {
            $error = $lang['nopassword'];
        }
        elseif($returnval['error'] == -3)
        {
            $error = $lang['invalidemail'];
        }
        if(!empty($error))
        {
            $display->errormessage = $error;
        }
    }
}
if(empty($_REQUEST['mode']))
{
    // Display a list of administrators
    $display->pagename = $lang['administrators'];
    $display->DisplayType("admin");

    $display->admins = User::ListAdministrators();

    $display->Output("admin/configuration/administrators-list.tpl");
}
elseif($_REQUEST['mode'] == "edit")
{
    $display->pagename = $lang['editadministrator'];

    $info = User::GetAdministratorInfo($_REQUEST['uid']);

    if($info && count($info) != 0)
    {
        $display->info = $info;
        $display->DisplayType("admin");
        $display->Output("admin/configuration/administrators-add.tpl");
    }
    else
    {
        $_SESSION['errormessage'] = $lang['nouserfound'];
        header("Location: index.php");
    }
}
elseif($_REQUEST['mode'] == "add")
{
    $display->pagename = $lang['addadministrator'];
    $display->DisplayType("admin");
    $display->Output("admin/configuration/administrators-add.tpl");
}
elseif($_REQUEST['mode'] == "delete")
{
    $results = User::DeleteAdmin($_REQUEST['uid']);
    if($results['error'] == 0)
    {
        $_SESSION['goodmessage'] = $lang['administratorremoved'];
    }
    elseif($results['error'] == -1)
    {
        $_SESSION['errormessage'] = $lang['nouserdatabase'];
    }
    elseif($results['error'] == -2)
    {
        $_SESSION['errormessage'] = $lang['errormainadmin'];
    }
    header("Location: administrators.php");
    exit();
}
?>