<?php

/*
 * This file is for the WebAPI which allows for internal functions to be
 * called using a POST or GET to this script with the required function variables
 */
$api = true;
require_once("../includes/gsp-panel.php");

use GSPPanel\{API, GSP, SafeSQL, User, Games};

// Check if demo mode is enabled
if(defined("DEMO"))
{
    die("This feature is disabled in demo mode");
}

if(isset($_REQUEST['apiversion']) && !empty($_REQUEST['apiversion']) && $_REQUEST['apiversion'] != "1.0")
{
    API::getInstance()->RunCommand();
}
else
{
    // Use the old version 1.0 API

    if(!isset($_REQUEST['action']) || !isset($_REQUEST['apipass']))
    {
        die("Missing authentication or action to perform");
    }

    if(GSP::getInstance()->settings['webapi'] != "1")
    {
        die("WebAPI is disabled");
    }

    if(empty(GSP::getInstance()->settings['webapi_pass']))
    {
        die("No password specified for the WebAPI");
    }

    if(GSP::getInstance()->settings['webapi_pass'] != $_REQUEST['apipass'])
    {
        die("Invalid WebAPI password");
    }
    unset($_REQUEST['apipass']);

    /*     * ************************
     *  ADD USER
     * *********************** */
    if($_REQUEST['action'] == "adduser")
    {
        $params = array('email' => $_REQUEST['email'],
            'password' => $_REQUEST['password'],
            'status' => $_REQUEST['status'],
            'phone' => $_REQUEST['phone'],
            'firstname' => $_REQUEST['firstname'],
            'lastname' => $_REQUEST['lastname'],
            'address' => $_REQUEST['address'],
            'city' => $_REQUEST['city'],
            'state' => $_REQUEST['state'],
            'zipcode' => $_REQUEST['zipcode'],
            'country' => $_REQUEST['country'],
            'billingid' => $_REQUEST['billingid'],
            'notes' => $_REQUEST['notes']);
        $returnval = User::AddClient($params);
    }
    /*     * ************************
     *  EDIT USER
     * *********************** */
    elseif($_REQUEST['action'] == "edituser")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['uid'] = GetUID($_REQUEST['billingid']);
        }
        $params = array('email' => $_REQUEST['email'],
            'password' => $_REQUEST['password'],
            'status' => $_REQUEST['status'],
            'phone' => $_REQUEST['phone'],
            'firstname' => $_REQUEST['firstname'],
            'lastname' => $_REQUEST['lastname'],
            'address' => $_REQUEST['address'],
            'city' => $_REQUEST['city'],
            'state' => $_REQUEST['state'],
            'zipcode' => $_REQUEST['zipcode'],
            'country' => $_REQUEST['country'],
            'notes' => $_REQUEST['notes'],
            'billingid' => $_REQUEST['billingid'],
            'uid' => $_REQUEST['uid']);
        $returnval = User::EditClient($params);
    }
    /*     * ************************
     *  DELETE USER
     * *********************** */
    elseif($_REQUEST['action'] == "deleteuser")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['uid'] = GetUID($_REQUEST['billingid']);
        }
        $returnval = User::DeleteUser($_REQUEST['uid']);
    }
    /*     * ************************
     *  SUSPEND USER
     * *********************** */
    elseif($_REQUEST['action'] == "suspenduser")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['uid'] = GetUID($_REQUEST['billingid']);
        }
        $returnval = User::SuspendClient($_REQUEST['uid']);
    }
    /*     * ************************
     *  UNSUSPEND USER
     * *********************** */
    elseif($_REQUEST['action'] == "unsuspenduser")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['uid'] = GetUID($_REQUEST['billingid']);
        }
        $returnval = User::UnsuspendClient($_REQUEST['uid']);
    }
    /*     * ************************
     *  GET UID
     * *********************** */
    elseif($_REQUEST['action'] == "getuid")
    {
        echo GetUID($_REQUEST['billingid']);
        exit();
    }
    /*     * ************************
     *  GET SERVICE COUNT
     * *********************** */
    elseif($_REQUEST['action'] == "getservicecount")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['uid'] = GetUID($_REQUEST['billingid']);
        }
        $servicecount = 0;
        $querygames = GSP::getInstance()->db->query(SafeSQL::query("SELECT ugid FROM `usergames` WHERE `uid`='%i'", array($_REQUEST['uid'])));
        if($querygames && $querygames->num_rows > 0)
        {
            $servicecount = $querygames->num_rows;
        }
        echo $servicecount;
        exit();
    }
    /*     * ************************
     *  GET PASSWORD
     * *********************** */
    elseif($_REQUEST['action'] == "getpassword")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['uid'] = GetUID($_REQUEST['billingid']);
        }
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` WHERE `uid`='%i' LIMIT 1", array($_REQUEST['uid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            if($row['userlevel'] == "1")
            {
                die("Permission Denied");
            }
        }
        $returnval = User::GetPass($_REQUEST['uid']);
        echo $returnval;
        exit();
    }
    /*     * ************************
     *  CHANGE PASSWORD
     * *********************** */
    elseif($_REQUEST['action'] == "changepassword")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['uid'] = GetUID($_REQUEST['billingid']);
        }
        $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` WHERE `uid`='%i' LIMIT 1", array($_REQUEST['uid'])));
        if($query && $query->num_rows == 1)
        {
            $row = $query->fetch_assoc();
            if($row['userlevel'] == "1")
            {
                die("Permission Denied");
            }
        }
        $params = array('password' => $_REQUEST['password'],
            'uid' => $_REQUEST['uid']);
        $returnval = User::EditClient($params);
    }
    /*     * ************************
     * ADD USER GAME
     * *********************** */
    elseif($_REQUEST['action'] == "addusergame")
    {
        if(!empty($_REQUEST['config']))
        {
            $_REQUEST['config'] = unserialize(urldecode($_REQUEST['config']));
        }
        $params = array('uid' => $_REQUEST['uid'],
            'sid' => $_REQUEST['sid'],
            'gid' => $_REQUEST['gid'],
            'install' => true,
            'private' => $_REQUEST['private'],
            'priority' => $_REQUEST['priority'],
            'maxslots' => $_REQUEST['maxslots'],
            'config' => $_REQUEST['config'],
            'billingid' => $_REQUEST['billingid'],
            'location' => $_REQUEST['location'],
            'dedicatedip' => $_REQUEST['dedicatedip'],
            'fastdl' => $_REQUEST['fastdl'],
            'email' => true);
        $returnval = Games::AddUserGame($params);
    }
    /*     * ************************
     *  EDIT USER GAME
     * *********************** */
    elseif($_REQUEST['action'] == "editusergame")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['ugid'] = GetUGID($_REQUEST['billingid']);
        }
        if(!empty($_REQUEST['config']))
        {
            $_REQUEST['config'] = unserialize(urldecode($_REQUEST['config']));
        }
        $params = array('ugid' => $_REQUEST['ugid'],
            'private' => $_REQUEST['private'],
            'priority' => $_REQUEST['priority'],
            'maxslots' => $_REQUEST['maxslots'],
            'billingid' => $_REQUEST['billingid'],
            'dedicatedip' => $_REQUEST['dedicatedip'],
            'fastdl' => $_REQUEST['fastdl'],
            'config' => $_REQUEST['config']);
        $returnval = Games::EditUserGame($params);
    }
    /*     * ************************
     *  DELETE USER GAME
     * *********************** */
    elseif($_REQUEST['action'] == "deleteusergame")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['ugid'] = GetUGID($_REQUEST['billingid']);
        }
        $returnval = Games::DeleteFromUser($_REQUEST['ugid'], true);
    }
    /*     * ************************
     *  REINSTALL USER GAME
     * *********************** */
    elseif($_REQUEST['action'] == "reinstallusergame")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['ugid'] = GetUGID($_REQUEST['billingid']);
        }
        $returnval = Games::DeleteFromUser($_REQUEST['ugid'], false);
        if($returnval['error'] == 0 || $returnval['error'] == -4)
        {
            $params = array("ugid" => $_REQUEST['ugid'], "email" => false);
            $returnval = Games::InstallToUser($params);
        }
    }
    /*     * ************************
     *  SUSPEND USER GAME
     * *********************** */
    elseif($_REQUEST['action'] == "suspendusergame")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['ugid'] = GetUGID($_REQUEST['billingid']);
        }
        $returnval = Games::SuspendServer($_REQUEST['ugid']);
    }
    /*     * ************************
     *  UNSUSPEND USER GAME
     * *********************** */
    elseif($_REQUEST['action'] == "unsuspendusergame")
    {
        if(isset($_REQUEST['billingid']))
        {
            $_REQUEST['ugid'] = GetUGID($_REQUEST['billingid']);
        }
        $returnval = Games::UnsuspendServer($_REQUEST['ugid']);
    }

// return the data
    echo urlencode(serialize($returnval));
}

// Functions required to get information from the specified billingid
function GetUID($billingid)
{

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `users` WHERE `billingid`='%s' LIMIT 1", array($billingid)));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        return $row['uid'];
    }
    return 0;
}

function GetUGID($billingid)
{

    $query = GSP::getInstance()->db->query(SafeSQL::query("SELECT * FROM `usergames` WHERE `billingid`='%s' LIMIT 1", array($billingid)));
    if($query && $query->num_rows == 1)
    {
        $row = $query->fetch_assoc();
        return $row['ugid'];
    }
    return 0;
}

?>