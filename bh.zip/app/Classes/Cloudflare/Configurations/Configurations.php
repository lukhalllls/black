<?php
/**
 * Created by PhpStorm.
 * User: junade
 * Date: 19/09/2017
 * Time: 15:23
 */

namespace Pterodactyl\Classes\Cloudflare\Configurations;

interface Configurations
{
    public function getArray(): array;
}
