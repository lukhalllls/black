<?php
/**
 * Created by PhpStorm.
 * User: junade
 * Date: 21/04/2017
 * Time: 07:23
 */

namespace Pterodactyl\Classes\Cloudflare\Adapter;

class ResponseException extends \Exception
{
}
