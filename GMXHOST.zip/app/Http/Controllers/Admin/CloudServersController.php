<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Traits\Controllers\JavascriptInjection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CloudServersController extends Controller
{
    
    use JavascriptInjection;
    private $alert;
    protected $cache;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->middleware("auth");
        $this->alert = $alert;
    }

    public function index(Request $request): View
    {
        $settings = DB::table('cloudsettings')->where('id', '=', (int) 1)->first();

        return view('admin.cloudservers.index', [
            'settings' => $settings
        ]);
    }

    public function update(Request $request)
    {
        $this->validate($request, [
            'io' => 'required',
            'cpu' => 'required',
            'allocation' => 'required',
            'database' => 'required',
            'minram' => 'required',
            'maxram' => 'required',
            'mindisk' => 'required',
            'maxdisk' => 'required',
            'logs' => 'required',
        ]);

        $cpu = trim($request->input('cpu'));
        $allocation = trim($request->input('allocation'));
        $io = trim($request->input('io'));
        $database = trim($request->input('database'));
        $max_ram = trim($request->input('maxram'));
        $min_ram = trim($request->input('minram'));
        $max_disk = trim($request->input('maxdisk'));
        $min_disk = trim($request->input('mindisk'));
        $logs = trim($request->input('logs'));

        DB::table('cloudsettings')->where('id', '=', 1)->update([
            'default_cpu' => $cpu,
            'default_io' => $io,
            'default_allocation' => $allocation,
            'default_database' => $database,
            'min_ram' => $min_ram,
            'max_ram' => $max_ram,
            'min_disk' => $min_disk,
            'max_disk' => $max_disk,
            'logs' => $logs,
        ]);

        $this->alert->success('You have successfully updated the CloudServer settings')->flash();

        return redirect()->route('admin.cloudservers.index');
    }

    public function eggstatus(Request $request)
    {
        $name = trim($request->input('status'));
        $egg = DB::table('cloudeggs')->where('name', '=', $name)->first();

        if($egg->status == 1) {
            DB::table('cloudeggs')->where('name', '=', $name)->update([
                'status' => (int) 0,
            ]);
        
            $this->alert->danger('You disabled the game.')->flash();
        } elseif($egg->status == 0) {
            DB::table('cloudeggs')->where('name', '=', $name)->update([
                'status' => (int) 1,
            ]);
            
            $this->alert->success('You enabled the game.')->flash();
        }

        return redirect()->route('admin.cloudservers.games');
    }

    public function eggcreate(Request $request): View
    {
        $eggs = DB::table('eggs')->get();

        return view('admin.cloudservers.createegg', [
            'eggs' => $eggs
        ]);
    }

    public function eggcreate2(Request $request)
    {
        $this->validate($request, [
            'eggid' => 'required',
            'startup' => 'required',
            'image' => 'required',
            'name' => 'required',
            'img' => 'required',
        ]);

        $eggid = trim($request->input('eggid'));
        $startup = trim($request->input('startup'));
        $image = trim($request->input('image'));
        $name = trim($request->input('name'));
        $img = trim($request->input('img'));

        DB::table('cloudeggs')->insert([
            'eggid' => $eggid,
            'startup' => $startup,
            'image' => $image,
            'description' => 'Not set',
            'name' => $name,
            'img' => $img,
        ]);

        $this->alert->success('You success fully created the egg.')->flash();
        return redirect()->route('admin.cloudservers.games');
    }

    public function eggsettings(Request $request, $id): View
    {
        $id = (int) $id;
        $eggs = DB::table('cloudeggs')->where('id', '=', $id)->get();
        

        return view('admin.cloudservers.settings', [
            'eggs' => $eggs
        ]);
    }

    public function eggsettingsupdate(Request $request, $id)
    {
        $this->validate($request, [
            'eggid' => 'required',
            'startup' => 'required',
            'image' => 'required',
            'name' => 'required',
            'img' => 'required',
        ]);

        $id = (int) $id;
        $eggs = DB::table('cloudeggs')->where('id', '=', $id)->first();
        $eggid = trim($request->input('eggid'));
        $startup = trim($request->input('startup'));
        $image = trim($request->input('image'));
        $name = trim($request->input('name'));
        $img = trim($request->input('img'));

        DB::table('cloudeggs')->where('id', '=', $id)->update([
            'eggid' => $eggid,
            'startup' => $startup,
            'image' => $image,
            'name' => $name,
            'img' => $img,
        ]);

        $this->alert->success('You success fully edited this egg settings.')->flash();
        return redirect()->route('admin.cloudservers.games');
    }

    public function logs(Request $request)
    {
        $logs = DB::table('cloudlogs')->get();

        return view('admin.cloudservers.logs', [
            'logs' => $logs
        ]);
    }

    public function games(Request $request): View
    {
        $eggs = DB::table('cloudeggs')->get();

        return view('admin.cloudservers.games', [
            'eggs' => $eggs
        ]);
    }

    public function changelogs(Request $request): View
    {
        return view('admin.cloudservers.changelogs');
    }

    public function users(Request $request): View
    {
        $users = DB::table('users')->get();

        return view('admin.cloudservers.users', [
            'users' => $users
        ]);
    }

    public function updateuser(Request $request, $id)
    {
        $id = (int) $id;

        $ram = trim($request->input('ram'));
        $disk = trim($request->input('disk'));
        
        if($ram > 0) {
            DB::table('users')->where('id', '=', $id)->update([
                'ram' => $ram,
            ]);
        }

        if($disk > 0) {
            DB::table('users')->where('id', '=', $id)->update([
                'disk' => $disk,
            ]);
        }

        $this->alert->success('You success fully edited this users ram end disk.')->flash();

        return redirect()->route('admin.cloudservers.users');
    }
    
}